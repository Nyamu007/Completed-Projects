# Plan2Struct AI

> AI-powered web application that converts architectural plans into structural drawings with material schedules and bill of quantities

![Plan2Struct AI](https://img.shields.io/badge/Status-Active-green) ![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?logo=typescript&logoColor=white) ![React](https://img.shields.io/badge/React-20232A?logo=react&logoColor=61DAFB) ![Node.js](https://img.shields.io/badge/Node.js-43853D?logo=node.js&logoColor=white) ![Python](https://img.shields.io/badge/Python-3776AB?logo=python&logoColor=white)

## 📋 Overview

Plan2Struct AI is a sophisticated full-stack web application that automates the conversion of architectural plans into structural engineering documents. The system uses computer vision and AI to analyze uploaded architectural drawings and automatically generates:

- **Structural Plans** - Converted architectural drawings with structural elements identified
- **Material Schedules** - Comprehensive lists of required materials with specifications
- **Bar Bending Schedules** - Detailed reinforcement bar schedules for concrete structures
- **Bill of Quantities (BOQ)** - Complete cost estimates and quantity calculations

### Key Features

🏗️ **Multi-Format Support**
- PDF architectural drawings
- Image files (PNG, JPG, JPEG)
- CAD files (DWG, DXF)
- File size limit: 50MB per upload

🤖 **Advanced AI-Powered Analysis**
- **Mask R-CNN deep learning** for precise architectural element detection
- **Computer vision** using OpenCV for fallback processing
- **Multi-format support** - PDF, DWG, DXF, and image analysis
- **Automatic structural element detection** with high accuracy
- **Building code compliance** (Eurocode support)
- **Real-time processing** with progress tracking

📊 **Comprehensive Reporting**
- Interactive material schedules with export capabilities
- Detailed bar bending schedules grouped by element type
- Professional bill of quantities with cost calculations
- Export to PDF, Excel, and CSV formats

🎨 **Modern Interface**
- Responsive dashboard design
- Dark/light theme support
- Multi-stage workflow (upload → processing → results)
- Real-time progress updates

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm
- Python 3.11+
- PostgreSQL database (optional - uses in-memory storage by default)

### Installation

1. **Clone or extract the project**
   ```bash
   # If from zip file
   unzip plan2struct-ai.zip
   cd plan2struct-ai
   
   # Or clone from repository
   git clone <repository-url>
   cd plan2struct-ai
   ```

2. **Install Node.js dependencies**
   ```bash
   npm install
   ```

3. **Setup Python environment for floor plan detection**
   ```bash
   # Navigate to processors directory
   cd server/processors
   
   # Run the setup script (recommended)
   chmod +x setup.sh
   ./setup.sh
   
   # Or install manually
   pip3 install -r requirements.txt
   
   # For advanced Mask R-CNN detection (optional)
   pip3 install tensorflow>=2.10.0 scikit-image imgaug
   ```

4. **Start the development server**
   ```bash
   npm run dev
   ```

5. **Access the application**
   - Open your browser to `http://localhost:5000`
   - The backend API runs on the same port
   - Upload architectural plans and start processing

## 🏗️ Project Architecture

### Frontend (React + TypeScript)
```
client/
├── src/
│   ├── components/           # Reusable UI components
│   │   ├── ui/              # shadcn/ui component library
│   │   ├── header.tsx       # Application header
│   │   ├── sidebar.tsx      # Navigation sidebar
│   │   ├── project-summary.tsx
│   │   ├── material-schedule.tsx
│   │   ├── bar-bending-schedule.tsx
│   │   └── bill-of-quantities.tsx
│   ├── pages/
│   │   ├── dashboard.tsx    # Main application dashboard
│   │   └── not-found.tsx    # 404 error page
│   ├── hooks/               # Custom React hooks
│   ├── lib/                 # Utility functions and query client
│   └── App.tsx              # Main app component with routing
```

### Backend (Express.js + TypeScript)
```
server/
├── services/
│   └── processing-service.ts    # File processing orchestration
├── processors/
│   └── plan-processor.py       # Python-based plan analysis
├── index.ts                    # Express server setup
├── routes.ts                   # API route definitions
├── storage.ts                  # In-memory data storage
└── vite.ts                     # Vite integration for serving frontend
```

### Database Schema (PostgreSQL compatible)
```
shared/
└── schema.ts                   # Drizzle ORM schema definitions
```

## 🔧 Technical Stack

### Core Technologies
- **Frontend**: React 18, TypeScript, Vite
- **Backend**: Express.js, Node.js, TypeScript  
- **Database**: PostgreSQL with Drizzle ORM (in-memory fallback)
- **Processing**: Python 3.11, OpenCV, NumPy
- **Styling**: Tailwind CSS, shadcn/ui components

### Key Dependencies
- **UI Framework**: Radix UI primitives, Lucide icons
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: TanStack Query for server state
- **File Handling**: Multer for multipart uploads
- **Validation**: Zod schemas with type inference

## 📝 Development Guide

### Project Structure Reconstruction

If recreating this project from scratch, follow this order:

1. **Setup Base Configuration**
   ```bash
   # Initialize Node.js project
   npm init -y
   
   # Install core dependencies
   npm install express typescript tsx vite @vitejs/plugin-react
   npm install -D @types/express @types/node
   
   # Setup TypeScript configuration
   # Copy tsconfig.json, vite.config.ts, tailwind.config.ts
   ```

2. **Database Schema Design**
   ```typescript
   // shared/schema.ts - Define all data models first
   export const projects = pgTable('projects', {
     id: text('id').primaryKey(),
     name: text('name').notNull(),
     buildingCode: text('building_code'),
     buildingType: text('building_type'),
     numberOfFloors: integer('number_of_floors'),
     status: text('status'),
     createdAt: timestamp('created_at'),
     updatedAt: timestamp('updated_at')
   });
   ```

3. **Backend API Development**
   ```typescript
   // server/storage.ts - Implement storage interface
   // server/routes.ts - Define REST API endpoints
   // server/index.ts - Setup Express server
   ```

4. **Frontend Component Architecture**
   ```typescript
   // Install UI dependencies
   npm install @radix-ui/react-* lucide-react tailwindcss
   
   // Build component hierarchy:
   // App.tsx -> Dashboard -> [ProjectSummary, MaterialSchedule, etc.]
   ```

5. **Processing Pipeline**
   ```python
   # server/processors/plan-processor.py
   # Implement OpenCV-based plan analysis
   # Connect to Node.js via child_process
   ```

### Key Implementation Patterns

**State Management**
```typescript
// Use TanStack Query for server state
const { data: projects } = useQuery({
  queryKey: ['/api/projects'],
  // Default fetcher configured globally
});

// Mutations with cache invalidation
const createProject = useMutation({
  mutationFn: (data) => apiRequest('/api/projects', 'POST', data),
  onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/projects'] })
});
```

**Form Handling**
```typescript
// React Hook Form with Zod validation
const form = useForm<InsertProject>({
  resolver: zodResolver(insertProjectSchema),
  defaultValues: { name: '', buildingCode: 'Eurocode' }
});
```

**File Upload Processing**
```typescript
// Multer configuration for multiple file types
const upload = multer({
  dest: 'uploads/',
  fileFilter: (req, file, cb) => {
    const allowedTypes = /pdf|png|jpg|jpeg|dwg|dxf/;
    cb(null, allowedTypes.test(file.originalname.toLowerCase()));
  },
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB
});
```

## 🗄️ Database Schema Details

### Core Tables

**Projects**
- `id` (Primary Key) - UUID
- `name` - Project name
- `buildingCode` - Building standard (Eurocode, etc.)
- `buildingType` - Residential, Commercial, etc.
- `numberOfFloors` - Floor count
- `status` - uploaded, processing, completed, failed
- `createdAt`, `updatedAt` - Timestamps

**Structural Elements**
- `id` (Primary Key) - UUID  
- `projectId` (Foreign Key) - References projects
- `elementType` - beam, column, slab, wall, foundation
- `elementId` - Unique identifier within project
- `dimensions` - JSON object with measurements
- `materialGrade` - Concrete/steel grade specifications
- `reinforcement` - JSON object with bar details
- `quantity` - Element quantity
- `unit` - Measurement unit

**Material Schedule**
- `id` (Primary Key) - UUID
- `projectId` (Foreign Key) - References projects  
- `itemCode` - Material identification code
- `description` - Material description
- `unit` - Measurement unit (kg, m3, m2, etc.)
- `quantity` - Required quantity
- `rate` - Unit rate/cost
- `amount` - Total cost (quantity × rate)
- `category` - Material category

## 🔍 Processing Pipeline

### File Analysis Workflow

1. **Upload Stage**
   - File validation and storage
   - Metadata extraction
   - Project creation

2. **Processing Stage**
   - Python script execution via child_process
   - OpenCV-based image analysis
   - Edge detection and contour analysis
   - Structural element identification

3. **Generation Stage**
   - Material requirement calculations
   - Bar bending schedule creation
   - Bill of quantities compilation
   - Cost estimation

4. **Output Stage**
   - Report generation
   - Export capabilities (PDF, Excel, CSV)
   - Data visualization

## 📋 API Endpoints

### Projects
- `GET /api/projects` - List all projects
- `POST /api/projects` - Create new project
- `GET /api/projects/:id` - Get project details
- `PUT /api/projects/:id` - Update project
- `DELETE /api/projects/:id` - Delete project

### File Management
- `POST /api/projects/:id/upload` - Upload architectural files
- `GET /api/projects/:id/files` - List project files
- `DELETE /api/files/:id` - Delete file

### Analysis Results
- `GET /api/projects/:id/structural-elements` - Get structural elements
- `GET /api/projects/:id/material-schedule` - Get material schedule
- `GET /api/projects/:id/bar-bending-schedule` - Get bar schedule
- `GET /api/projects/:id/bill-of-quantities` - Get BOQ

### Processing
- `POST /api/projects/:id/process` - Start processing
- `GET /api/projects/:id/processing-logs` - Get processing status

## 🚀 Deployment

### Environment Variables
```bash
# Database (optional - uses in-memory storage by default)
DATABASE_URL=postgresql://user:password@localhost:5432/plan2struct

# Server Configuration
PORT=5000
NODE_ENV=production
```

### Production Build
```bash
# Build frontend and backend
npm run build

# Start production server
npm start
```

### Replit Deployment
- The project is configured for Replit Deployments
- Automatic builds and hosting
- TLS certificates and custom domains supported
- Uses the existing workflow: `npm run dev`

## 📖 Usage Examples

### Basic Workflow
```typescript
// 1. Create new project
const projectData = {
  name: "Residential Building A",
  buildingCode: "Eurocode",
  buildingType: "Residential",
  numberOfFloors: 3
};

// 2. Upload architectural plans
const formData = new FormData();
formData.append('files', pdfFile);
formData.append('files', dwgFile);

// 3. Start processing
fetch(`/api/projects/${projectId}/process`, { method: 'POST' });

// 4. Monitor progress
// Real-time updates via polling every 2 seconds

// 5. Export results
// Material Schedule, Bar Bending Schedule, BOQ available for download
```

## 🧠 Advanced Floor Detection System

### Overview
The application includes a sophisticated floor plan detection system using deep learning and computer vision:

**Detection Methods:**
1. **Mask R-CNN** - Advanced deep learning for precise element detection
2. **OpenCV** - Computer vision fallback for basic shape detection
3. **Hybrid approach** - Combines both methods for optimal results

### Setup Advanced Detection

```bash
# Quick setup using the provided script
cd server/processors
chmod +x setup.sh
./setup.sh

# Manual setup for Mask R-CNN (optional)
pip3 install tensorflow>=2.10.0
pip3 install scikit-image imgaug
git clone https://github.com/matterport/Mask_RCNN.git
cd Mask_RCNN && python3 setup.py install
```

### Detection Capabilities

**Architectural Elements Detected:**
- Walls and structural elements
- Doors and windows  
- Columns and beams
- Slabs and openings
- Rooms and spaces
- Dimensional annotations

**File Format Support:**
- PDF architectural drawings
- DWG/DXF CAD files
- PNG, JPG, JPEG images
- Multi-page document processing

### Integration Architecture

```python
# server/processors/floor-detection.py
class FloorPlanDetector:
    def detect_elements(self, image_path: str) -> Dict[str, Any]:
        # Try Mask R-CNN first, fallback to OpenCV
        if self.model is not None:
            return self.detect_with_maskrcnn(image)
        return self.detect_with_opencv(image)
    
    def analyze_floor_plan(self, image_path: str, project_id: str):
        # Complete analysis pipeline
        # Returns: structural_elements, material_schedule, 
        #          bar_bending_schedule, bill_of_quantities
```

### Custom Model Training

For enhanced accuracy with specific architectural drawing styles:

```bash
# Prepare training data
# Structure: /training_data/images/ and /training_data/annotations/

# Train custom model (requires labeled data)
python3 train_custom_model.py --dataset=/path/to/training_data
```

## 🏗️ 3D Model Reconstruction Workflow

### Overview
The application features a sophisticated 3D reconstruction workflow that recreates the building model before structural analysis, similar to Dynamo/Grasshopper parametric modeling:

**Reconstruction Process:**
1. **2D Analysis** - Floor plan detection using Mask R-CNN/OpenCV
2. **3D Geometry Creation** - Parametric modeling engine creates 3D elements
3. **Level Generation** - Building levels with proper elevations
4. **Element Extrusion** - Walls, columns, beams extruded to 3D
5. **Visualization** - Interactive 3D model with export capabilities

### Key Features

**Parametric Modeling Engine:**
- **GeometryEngine** - Core 3D geometry creation and manipulation
- **Level creation** - Similar to Revit Level.ByElevationAndName
- **Wall extrusion** - 2D profiles extruded to 3D volumes
- **Structural elements** - Columns, beams, slabs with proper geometry

**3D Visualization:**
- Interactive 3D viewer with multiple view modes
- Wireframe and solid rendering options
- Camera controls and navigation
- Real-time model statistics

**Export Capabilities:**
- **OBJ format** - 3D mesh export for modeling software
- **IFC format** - Building Information Modeling standard
- **JSON format** - Raw model data for custom processing
- **Multiple formats** - Ready for BIM workflows

### Integration Architecture

```bash
# Run 3D reconstruction manually
cd server/processors
python3 3d-reconstruction.py \
  --detection_file project_detections.json \
  --project_id PROJECT_ID \
  --num_floors 3 \
  --output_path model_output.json
```

The 3D reconstruction is automatically integrated into the processing pipeline:
- Triggered after floor plan detection
- Creates building levels and 3D geometry
- Generates visualization data for the web interface
- Produces exportable model formats

## 🛠️ Customization

### Adding New Building Codes
```typescript
// shared/schema.ts
export const buildingCodes = [
  'Eurocode',
  'ACI', 
  'IS Code',
  'BS Code'
] as const;
```

### Extending Material Types
```python
# server/processors/plan-processor.py
MATERIAL_GRADES = {
    'concrete': ['M20', 'M25', 'M30', 'M35'],
    'steel': ['Fe415', 'Fe500', 'Fe550']
}
```

### Custom Export Formats
```typescript
// Add new export handlers in material-schedule.tsx
const handleCustomExport = async () => {
  const response = await fetch(`/api/projects/${projectId}/export/custom`);
  // Handle custom format
};
```

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/new-feature`)
3. Commit changes (`git commit -am 'Add new feature'`)
4. Push to branch (`git push origin feature/new-feature`)
5. Create Pull Request

### Development Setup
```bash
# Install dependencies
npm install

# Start development server with hot reload
npm run dev

# Run TypeScript checks
npm run type-check

# Build for production
npm run build
```

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🔗 Additional Resources

- [React Documentation](https://react.dev/)
- [Express.js Guide](https://expressjs.com/)
- [Drizzle ORM](https://orm.drizzle.team/)
- [shadcn/ui Components](https://ui.shadcn.com/)
- [OpenCV Python](https://opencv-python-tutroals.readthedocs.io/)
- [Tailwind CSS](https://tailwindcss.com/)

---

**Built with ❤️ for structural engineers and architects**