import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { 
  Box, 
  Eye, 
  Download, 
  RotateCcw, 
  ZoomIn, 
  ZoomOut,
  Grid3x3,
  Layers,
  Palette,
  Camera
} from "lucide-react";

interface ThreeDViewerProps {
  projectId: string;
}

interface ModelData {
  project_id: string;
  model_type: string;
  geometry_data: {
    levels: any[];
    walls: any[];
    openings: any[];
    structural_elements: any[];
  };
  bounding_box: {
    min: { x: number; y: number; z: number };
    max: { x: number; y: number; z: number };
  };
  statistics: {
    total_walls: number;
    total_openings: number;
    total_structural_elements: number;
    total_concrete_volume: number;
    average_confidence: number;
  };
  visualization_data: {
    meshes: any[];
    cameras: any[];
  };
  floor_plan_views: any[];
}

export default function ThreeDViewer({ projectId }: ThreeDViewerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [viewMode, setViewMode] = useState<'3d' | 'plan' | 'section'>('3d');
  const [showWireframe, setShowWireframe] = useState(false);
  const [selectedElement, setSelectedElement] = useState<string | null>(null);

  // Query for 3D model data
  const { data: modelData, isLoading, error } = useQuery<ModelData>({
    queryKey: [`/api/projects/${projectId}/3d-model`],
    enabled: !!projectId
  });

  // Initialize 3D viewer
  useEffect(() => {
    if (modelData && canvasRef.current) {
      initializeViewer();
    }
  }, [modelData]);

  const initializeViewer = () => {
    const canvas = canvasRef.current;
    if (!canvas || !modelData) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Simple 2D representation for now (can be upgraded to Three.js later)
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw grid
    drawGrid(ctx, canvas.width, canvas.height);
    
    // Draw model elements
    drawModelElements(ctx);
  };

  const drawGrid = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.strokeStyle = '#f0f0f0';
    ctx.lineWidth = 1;
    
    const gridSize = 50;
    
    // Vertical lines
    for (let x = 0; x <= width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    
    // Horizontal lines
    for (let y = 0; y <= height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
  };

  const drawModelElements = (ctx: CanvasRenderingContext2D) => {
    if (!modelData) return;

    const scale = 0.1; // Scale factor for display
    const offsetX = 50;
    const offsetY = 50;

    // Draw walls
    ctx.fillStyle = '#888888';
    ctx.strokeStyle = '#666666';
    ctx.lineWidth = 2;

    modelData.geometry_data.walls.forEach((wall, index) => {
      if (wall.profile_points && wall.profile_points.length >= 4) {
        ctx.beginPath();
        const firstPoint = wall.profile_points[0];
        ctx.moveTo(
          firstPoint.x * scale + offsetX,
          firstPoint.y * scale + offsetY
        );
        
        wall.profile_points.forEach((point: any) => {
          ctx.lineTo(
            point.x * scale + offsetX,
            point.y * scale + offsetY
          );
        });
        
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Add wall label
        const centerX = wall.profile_points.reduce((sum: number, p: any) => sum + p.x, 0) / wall.profile_points.length;
        const centerY = wall.profile_points.reduce((sum: number, p: any) => sum + p.y, 0) / wall.profile_points.length;
        
        ctx.fillStyle = '#000000';
        ctx.font = '10px Arial';
        ctx.fillText(
          wall.id,
          centerX * scale + offsetX - 15,
          centerY * scale + offsetY
        );
      }
    });

    // Draw structural elements
    modelData.geometry_data.structural_elements.forEach((element) => {
      if (element.type === 'column' && element.center_point) {
        ctx.fillStyle = '#666666';
        const x = element.center_point.x * scale + offsetX;
        const y = element.center_point.y * scale + offsetY;
        const size = Math.max(element.width * scale, 8);
        
        ctx.fillRect(x - size/2, y - size/2, size, size);
        
        // Label
        ctx.fillStyle = '#000000';
        ctx.font = '8px Arial';
        ctx.fillText(element.id, x - 15, y - 10);
      }
    });

    // Draw openings
    ctx.strokeStyle = '#0066cc';
    ctx.lineWidth = 3;
    
    modelData.geometry_data.openings.forEach((opening) => {
      if (opening.corner1 && opening.corner2) {
        const x1 = opening.corner1.x * scale + offsetX;
        const y1 = opening.corner1.y * scale + offsetY;
        const x2 = opening.corner2.x * scale + offsetX;
        const y2 = opening.corner2.y * scale + offsetY;
        
        ctx.beginPath();
        ctx.rect(x1, y1, x2 - x1, y2 - y1);
        ctx.stroke();
        
        // Label
        ctx.fillStyle = '#0066cc';
        ctx.font = '8px Arial';
        ctx.fillText(opening.id, x1, y1 - 5);
      }
    });
  };

  const handleExport = async (format: string) => {
    try {
      const response = await fetch(`/api/projects/${projectId}/export/3d?format=${format}`, {
        method: 'POST'
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${projectId}_model.${format}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  const resetView = () => {
    if (canvasRef.current) {
      initializeViewer();
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Box className="h-5 w-5" />
            3D Model Reconstruction
          </CardTitle>
          <CardDescription>Building 3D model from floor plan...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Progress value={75} />
            <p className="text-sm text-muted-foreground">Reconstructing geometry...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error || !modelData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Box className="h-5 w-5" />
            3D Model Reconstruction
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">No 3D model data available. Please process the floor plan first.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Box className="h-5 w-5" />
                3D Model Reconstruction
              </CardTitle>
              <CardDescription>
                Interactive 3D model reconstructed from floor plan analysis
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={resetView}>
                <RotateCcw className="h-4 w-4 mr-2" />
                Reset View
              </Button>
              <Button variant="outline" size="sm" onClick={() => handleExport('obj')}>
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as any)}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="3d" className="flex items-center gap-2">
                <Box className="h-4 w-4" />
                3D View
              </TabsTrigger>
              <TabsTrigger value="plan" className="flex items-center gap-2">
                <Grid3x3 className="h-4 w-4" />
                Plan View
              </TabsTrigger>
              <TabsTrigger value="section" className="flex items-center gap-2">
                <Layers className="h-4 w-4" />
                Section
              </TabsTrigger>
            </TabsList>

            <TabsContent value="3d" className="space-y-4">
              <div className="flex gap-2 mb-4">
                <Button 
                  variant={showWireframe ? "default" : "outline"} 
                  size="sm"
                  onClick={() => setShowWireframe(!showWireframe)}
                >
                  <Eye className="h-4 w-4 mr-2" />
                  Wireframe
                </Button>
                <Button variant="outline" size="sm">
                  <ZoomIn className="h-4 w-4 mr-2" />
                  Zoom In
                </Button>
                <Button variant="outline" size="sm">
                  <ZoomOut className="h-4 w-4 mr-2" />
                  Zoom Out
                </Button>
                <Button variant="outline" size="sm">
                  <Camera className="h-4 w-4 mr-2" />
                  Camera
                </Button>
              </div>

              <div className="border rounded-lg overflow-hidden">
                <canvas
                  ref={canvasRef}
                  width={800}
                  height={600}
                  className="w-full h-[600px] bg-white"
                  style={{ maxHeight: '600px' }}
                />
              </div>
            </TabsContent>

            <TabsContent value="plan">
              <div className="border rounded-lg p-4 bg-gray-50">
                <p className="text-center text-muted-foreground">Plan view mode</p>
                <canvas
                  width={800}
                  height={400}
                  className="w-full h-[400px] bg-white mt-4 border rounded"
                />
              </div>
            </TabsContent>

            <TabsContent value="section">
              <div className="border rounded-lg p-4 bg-gray-50">
                <p className="text-center text-muted-foreground">Section view mode</p>
                <canvas
                  width={800}
                  height={400}
                  className="w-full h-[400px] bg-white mt-4 border rounded"
                />
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Model Statistics */}
      <Card>
        <CardHeader>
          <CardTitle>Model Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {modelData.statistics.total_walls}
              </div>
              <div className="text-sm text-muted-foreground">Walls</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {modelData.statistics.total_structural_elements}
              </div>
              <div className="text-sm text-muted-foreground">Structural Elements</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">
                {modelData.statistics.total_openings}
              </div>
              <div className="text-sm text-muted-foreground">Openings</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {(modelData.statistics.total_concrete_volume / 1000000).toFixed(2)}m³
              </div>
              <div className="text-sm text-muted-foreground">Concrete Volume</div>
            </div>
          </div>
          
          <Separator className="my-4" />
          
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Detection Confidence</span>
            <Badge variant={modelData.statistics.average_confidence > 0.8 ? "default" : "secondary"}>
              {(modelData.statistics.average_confidence * 100).toFixed(1)}%
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Floor Plan Views */}
      <Card>
        <CardHeader>
          <CardTitle>Floor Plan Views</CardTitle>
          <CardDescription>Generated building levels and views</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {modelData.floor_plan_views.map((view, index) => (
              <div key={view.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <div className="font-medium">{view.name}</div>
                  <div className="text-sm text-muted-foreground">
                    Elevation: {view.elevation}mm
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  <Eye className="h-4 w-4 mr-2" />
                  View
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}