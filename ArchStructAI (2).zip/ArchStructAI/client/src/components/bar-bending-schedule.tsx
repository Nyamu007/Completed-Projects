import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import type { BarBendingSchedule } from "@shared/schema";

interface BarBendingScheduleProps {
  projectId: string;
}

export default function BarBendingSchedule({ projectId }: BarBendingScheduleProps) {
  const { data: schedule = [], isLoading } = useQuery({
    queryKey: [`/api/projects/${projectId}/bar-bending-schedule`],
  });

  const groupByElementType = (schedule: BarBendingSchedule[]) => {
    const grouped = schedule.reduce((acc, item) => {
      if (!acc[item.elementType]) {
        acc[item.elementType] = [];
      }
      acc[item.elementType].push(item);
      return acc;
    }, {} as Record<string, BarBendingSchedule[]>);
    return grouped;
  };

  const getTotalWeight = (items: BarBendingSchedule[]) => {
    return items.reduce((total, item) => total + parseFloat(item.totalWeight), 0);
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {[1, 2].map((i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-6 w-48" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[1, 2, 3].map((j) => (
                  <Skeleton key={j} className="h-12 w-full" />
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const groupedSchedule = schedule ? groupByElementType(schedule) : {};

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {Object.entries(groupedSchedule).map(([elementType, items]) => (
          <Card key={elementType}>
            <CardHeader>
              <CardTitle className="capitalize">
                Bar Bending Schedule - {elementType}s
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Mark</TableHead>
                      <TableHead>Dia</TableHead>
                      <TableHead>Length</TableHead>
                      <TableHead>Nos</TableHead>
                      <TableHead>Weight</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.markNumber}</TableCell>
                        <TableCell>{item.barDiameter}mm</TableCell>
                        <TableCell>{parseFloat(item.barLength).toFixed(1)}m</TableCell>
                        <TableCell>{item.numberOfBars}</TableCell>
                        <TableCell>{parseFloat(item.totalWeight).toFixed(1)} kg</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {schedule && schedule.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Steel Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {Object.entries(groupedSchedule).map(([elementType, items]) => (
                <div key={elementType} className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="text-2xl font-bold text-gray-900">
                    {getTotalWeight(items).toFixed(0)} kg
                  </div>
                  <div className="text-sm text-gray-500 capitalize">{elementType} Steel</div>
                </div>
              ))}
              <div className="bg-primary/10 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-primary">
                  {getTotalWeight(schedule || []).toFixed(0)} kg
                </div>
                <div className="text-sm text-gray-600">Total Steel</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {!schedule || schedule.length === 0 && (
        <Card>
          <CardContent className="text-center py-8 text-gray-500">
            No bar bending schedule data available. The project may still be processing.
          </CardContent>
        </Card>
      )}
    </div>
  );
}
