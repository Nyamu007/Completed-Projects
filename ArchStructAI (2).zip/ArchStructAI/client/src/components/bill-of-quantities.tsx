import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Download, Printer } from "lucide-react";
import type { BillOfQuantities } from "@shared/schema";

interface BillOfQuantitiesProps {
  projectId: string;
}

export default function BillOfQuantities({ projectId }: BillOfQuantitiesProps) {
  const { data: boq = [], isLoading } = useQuery({
    queryKey: [`/api/projects/${projectId}/bill-of-quantities`],
  });

  const handleExport = async () => {
    try {
      const response = await fetch(`/api/projects/${projectId}/export/bill-of-quantities`, {
        credentials: 'include'
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `bill-of-quantities-${projectId}.json`;
        a.click();
        window.URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  const getSubtotal = (boq: BillOfQuantities[]) => {
    return boq.reduce((total, item) => total + parseFloat(item.amount), 0);
  };

  const getGrandTotal = (subtotal: number) => {
    const profit = subtotal * 0.15; // 15% profit
    const tax = (subtotal + profit) * 0.18; // 18% GST
    return subtotal + profit + tax;
  };

  const groupByCategory = (boq: BillOfQuantities[]) => {
    const grouped = boq.reduce((acc, item) => {
      if (!acc[item.category]) {
        acc[item.category] = [];
      }
      acc[item.category].push(item);
      return acc;
    }, {} as Record<string, BillOfQuantities[]>);
    return grouped;
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="p-6 text-center">
                <Skeleton className="h-8 w-24 mx-auto mb-2" />
                <Skeleton className="h-4 w-20 mx-auto" />
              </CardContent>
            </Card>
          ))}
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-48" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const subtotal = getSubtotal(boq || []);
  const grandTotal = getGrandTotal(subtotal);
  const groupedBoq = groupByCategory(boq || []);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-primary">₹{grandTotal.toLocaleString()}</div>
            <div className="text-sm text-gray-500 mt-1">Total Project Cost</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-gray-900">₹{(grandTotal / 1200).toFixed(0)}/sq ft</div>
            <div className="text-sm text-gray-500 mt-1">Cost per Sq Ft</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-gray-900">45 days</div>
            <div className="text-sm text-gray-500 mt-1">Est. Duration</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-2xl font-bold text-success">15%</div>
            <div className="text-sm text-gray-500 mt-1">Cost Savings</div>
          </CardContent>
        </Card>
      </div>

      {/* BoQ Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Bill of Quantities</CardTitle>
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm">
                <Printer className="h-4 w-4 mr-2" />
                Print
              </Button>
              <Button onClick={handleExport} className="bg-primary text-white hover:bg-primary/90">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Category</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Unit</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Rate</TableHead>
                  <TableHead>Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {Object.entries(groupedBoq).map(([category, items]) => (
                  <>
                    <TableRow key={category} className="bg-blue-50">
                      <TableCell colSpan={6} className="font-semibold text-gray-900">
                        {category}
                      </TableCell>
                    </TableRow>
                    {items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell></TableCell>
                        <TableCell>{item.description}</TableCell>
                        <TableCell>{item.unit}</TableCell>
                        <TableCell>{parseFloat(item.quantity).toFixed(2)}</TableCell>
                        <TableCell>₹{parseFloat(item.rate).toLocaleString()}</TableCell>
                        <TableCell>₹{parseFloat(item.amount).toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  </>
                ))}
                <TableRow className="bg-gray-100 font-semibold">
                  <TableCell colSpan={5} className="text-right">Subtotal:</TableCell>
                  <TableCell>₹{subtotal.toLocaleString()}</TableCell>
                </TableRow>
                <TableRow className="bg-gray-100">
                  <TableCell colSpan={5} className="text-right text-gray-600">Contractor Profit (15%):</TableCell>
                  <TableCell>₹{(subtotal * 0.15).toLocaleString()}</TableCell>
                </TableRow>
                <TableRow className="bg-gray-100">
                  <TableCell colSpan={5} className="text-right text-gray-600">VAT/GST (18%):</TableCell>
                  <TableCell>₹{((subtotal * 1.15) * 0.18).toLocaleString()}</TableCell>
                </TableRow>
                <TableRow className="bg-primary/10 font-bold">
                  <TableCell colSpan={5} className="text-right text-primary">Grand Total:</TableCell>
                  <TableCell className="text-primary">₹{grandTotal.toLocaleString()}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>

          {!boq || boq.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No bill of quantities data available. The project may still be processing.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Cost Breakdown and Timeline */}
      {boq && boq.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Cost Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries(groupedBoq).map(([category, items]) => {
                const categoryTotal = getSubtotal(items);
                const percentage = ((categoryTotal / subtotal) * 100).toFixed(0);
                return (
                  <div key={category} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-4 h-4 bg-primary rounded"></div>
                      <span className="text-sm">{category}</span>
                    </div>
                    <Badge variant="secondary">{percentage}%</Badge>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Project Timeline</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-success rounded-full"></div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Foundation</span>
                    <span className="text-xs text-gray-500">Week 1-2</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-warning rounded-full"></div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Columns & Beams</span>
                    <span className="text-xs text-gray-500">Week 3-5</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-gray-300 rounded-full"></div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Slab Work</span>
                    <span className="text-xs text-gray-500">Week 6-7</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
