import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Download } from "lucide-react";
import type { MaterialSchedule } from "@shared/schema";

interface MaterialScheduleProps {
  projectId: string;
}

export default function MaterialSchedule({ projectId }: MaterialScheduleProps) {
  const { data: schedule = [], isLoading } = useQuery({
    queryKey: [`/api/projects/${projectId}/material-schedule`],
  });

  const handleExport = async () => {
    try {
      const response = await fetch(`/api/projects/${projectId}/export/material-schedule`, {
        credentials: 'include'
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `material-schedule-${projectId}.json`;
        a.click();
        window.URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  const getTotalAmount = (schedule: MaterialSchedule[]) => {
    return schedule.reduce((total, item) => total + parseFloat(item.amount || "0"), 0);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Material Schedule</CardTitle>
            <Skeleton className="h-9 w-32" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Material Schedule</CardTitle>
          <Button onClick={handleExport} className="bg-primary text-white hover:bg-primary/90">
            <Download className="h-4 w-4 mr-2" />
            Export Excel
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Item</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Unit</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Rate</TableHead>
                <TableHead>Amount</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {schedule?.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.itemCode}</TableCell>
                  <TableCell>{item.description}</TableCell>
                  <TableCell>{item.unit}</TableCell>
                  <TableCell>{parseFloat(item.quantity).toFixed(2)}</TableCell>
                  <TableCell>₹{parseFloat(item.rate || "0").toLocaleString()}</TableCell>
                  <TableCell>₹{parseFloat(item.amount || "0").toLocaleString()}</TableCell>
                </TableRow>
              ))}
              {schedule && schedule.length > 0 && (
                <TableRow className="bg-gray-50 font-semibold">
                  <TableCell colSpan={5} className="text-right">Total:</TableCell>
                  <TableCell>₹{getTotalAmount(schedule).toLocaleString()}</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {!schedule || schedule.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No material schedule data available. The project may still be processing.
          </div>
        )}
      </CardContent>
    </Card>
  );
}
