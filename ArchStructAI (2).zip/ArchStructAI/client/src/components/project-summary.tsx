import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import type { StructuralElement } from "@shared/schema";

interface ProjectSummaryProps {
  projectId: string;
}

export default function ProjectSummary({ projectId }: ProjectSummaryProps) {
  const { data: elements = [], isLoading } = useQuery({
    queryKey: [`/api/projects/${projectId}/structural-elements`],
  });

  const getSummaryStats = (elements: StructuralElement[]) => {
    const stats = {
      totalArea: 0,
      columns: 0,
      beams: 0,
      slabs: 0,
    };

    elements.forEach((element) => {
      if (element.elementType === "column") stats.columns++;
      if (element.elementType === "beam") stats.beams++;
      if (element.elementType === "slab") {
        stats.slabs++;
        const dimensions = element.dimensions as any;
        if (dimensions?.length && dimensions?.width) {
          stats.totalArea += dimensions.length * dimensions.width;
        }
      }
    });

    return stats;
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Plan Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex justify-between">
                <Skeleton className="h-4 w-20" />
                <Skeleton className="h-4 w-16" />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  const stats = getSummaryStats(elements || []);

  return (
    <div className="space-y-6">
      {/* Plan Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Plan Summary</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between">
            <span className="text-gray-600">Total Area:</span>
            <span className="font-medium">{stats.totalArea.toFixed(1)} m²</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Columns:</span>
            <span className="font-medium">{stats.columns}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Beams:</span>
            <span className="font-medium">{stats.beams}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Slabs:</span>
            <span className="font-medium">{stats.slabs} sections</span>
          </div>
        </CardContent>
      </Card>

      {/* Design Parameters */}
      <Card>
        <CardHeader>
          <CardTitle>Design Parameters</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">Concrete Grade:</span>
            <Badge variant="secondary">M25</Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Steel Grade:</span>
            <Badge variant="secondary">Fe500</Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Live Load:</span>
            <span className="font-medium">3.0 kN/m²</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Dead Load:</span>
            <span className="font-medium">1.5 kN/m²</span>
          </div>
        </CardContent>
      </Card>

      {/* Available Plans */}
      <Card>
        <CardHeader>
          <CardTitle>Available Plans</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-primary rounded-full"></div>
              <span className="font-medium">Ground Floor</span>
            </div>
            <Badge variant="default">Active</Badge>
          </div>
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
              <span className="font-medium">First Floor</span>
            </div>
            <Badge variant="secondary">Available</Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
