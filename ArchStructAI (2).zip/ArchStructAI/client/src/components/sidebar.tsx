import { cn } from "@/lib/utils";
import { 
  Upload, 
  Settings, 
  DraftingCompass, 
  List, 
  FileText,
  Building,
  Home
} from "lucide-react";

interface SidebarProps {
  currentStage: string;
}

const workflowSteps = [
  { id: "upload", label: "Upload Plans", icon: Upload },
  { id: "processing", label: "Processing", icon: Settings },
  { id: "results", label: "Structural Plans", icon: DraftingCompass },
  { id: "schedules", label: "Schedules", icon: List },
  { id: "export", label: "BoQ & Export", icon: FileText },
];

const recentProjects = [
  { name: "Residential Tower A", icon: Building, time: "2 days ago" },
  { name: "Villa Complex", icon: Home, time: "1 week ago" },
];

export default function Sidebar({ currentStage }: SidebarProps) {
  return (
    <aside className="w-64 bg-white shadow-sm border-r border-gray-200 fixed left-0 top-16 bottom-0 overflow-y-auto">
      <div className="p-6">
        <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">
          Workflow
        </h3>
        <nav className="space-y-2">
          {workflowSteps.map((step) => {
            const Icon = step.icon;
            const isActive = currentStage === step.id;
            const isCompleted = ["processing", "results"].includes(currentStage) && 
                              ["upload"].includes(step.id);
            
            return (
              <div
                key={step.id}
                className={cn(
                  "flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors",
                  isActive && "text-primary bg-blue-50",
                  !isActive && !isCompleted && "text-gray-600 hover:text-gray-900 hover:bg-gray-50",
                  isCompleted && "text-success bg-green-50"
                )}
              >
                <Icon className="h-5 w-5" />
                <span className={cn("font-medium", isActive && "font-semibold")}>
                  {step.label}
                </span>
              </div>
            );
          })}
        </nav>
      </div>
      
      <div className="p-6 border-t border-gray-200">
        <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">
          Recent Projects
        </h3>
        <div className="space-y-3">
          {recentProjects.map((project, index) => {
            const Icon = project.icon;
            return (
              <div key={index} className="flex items-center space-x-3">
                <Icon className="h-4 w-4 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-900">{project.name}</p>
                  <p className="text-xs text-gray-500">{project.time}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </aside>
  );
}
