import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ZoomIn, Download, DraftingCompass } from "lucide-react";

interface StructuralPlansProps {
  projectId: string;
}

export default function StructuralPlans({ projectId }: StructuralPlansProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Ground Floor Structural Plan</CardTitle>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm">
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Technical drawing placeholder with grid background */}
        <div className="bg-gray-50 rounded-lg h-96 flex items-center justify-center border-2 border-gray-200 grid-pattern">
          <div className="text-center">
            <DraftingCompass className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 font-medium">Ground Floor Structural Plan</p>
            <p className="text-gray-500 text-sm">Interactive CAD viewer would be integrated here</p>
            <p className="text-gray-500 text-xs mt-2">
              Project ID: {projectId}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
