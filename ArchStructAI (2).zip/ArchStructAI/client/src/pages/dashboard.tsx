import { useState } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import Sidebar from "@/components/sidebar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import FileUpload from "@/components/ui/file-upload";
import ProjectSummary from "@/components/project-summary";
import StructuralPlans from "@/components/structural-plans";
import MaterialSchedule from "@/components/material-schedule";
import BarBendingSchedule from "@/components/bar-bending-schedule";
import BillOfQuantities from "@/components/bill-of-quantities";
import ThreeDViewer from "@/components/3d-viewer";
import { CloudUpload, Play, Settings, Loader2, CheckCircle, Clock, AlertCircle } from "lucide-react";
import type { Project } from "@shared/schema";

export default function Dashboard() {
  const { id: projectId } = useParams();
  const [projectName, setProjectName] = useState("New Project");
  const [buildingCode, setBuildingCode] = useState("Eurocode");
  const [buildingType, setBuildingType] = useState("Residential");
  const [numberOfFloors, setNumberOfFloors] = useState(1);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [activeTab, setActiveTab] = useState("3d-model");

  // Query for specific project if ID is provided
  const { data: project, isLoading: projectLoading } = useQuery({
    queryKey: [`/api/projects/${projectId}`],
    enabled: !!projectId
  });

  // Query for processing logs
  const { data: processingLogs = [] } = useQuery({
    queryKey: [`/api/projects/${projectId}/processing-logs`],
    enabled: !!projectId,
    refetchInterval: currentProject?.status === "processing" ? 2000 : false
  });

  const currentStage = () => {
    if (!currentProject) return "upload";
    if (currentProject.status === "uploaded") return "upload";
    if (currentProject.status === "processing") return "processing";
    if (currentProject.status === "completed") return "results";
    if (currentProject.status === "failed") return "error";
    return "upload";
  };

  const getProgress = () => {
    if (!processingLogs || processingLogs.length === 0) return 0;
    const latestLog = processingLogs[0];
    return latestLog.progress || 0;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-5 w-5 text-success" />;
      case "started":
        return <Loader2 className="h-5 w-5 text-primary animate-spin" />;
      case "failed":
        return <AlertCircle className="h-5 w-5 text-error" />;
      default:
        return <Clock className="h-5 w-5 text-muted-foreground" />;
    }
  };

  if (projectId && projectLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header currentProject={currentProject} />
      
      <div className="flex pt-16">
        <Sidebar currentStage={currentStage()} />
        
        <main className="flex-1 overflow-auto">
          <div className="p-8">
            {/* Upload Section */}
            {currentStage() === "upload" && (
              <div className="space-y-8">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900">Upload Architectural Plans</h1>
                    <p className="text-gray-600 mt-1">Upload your architectural drawings to generate structural plans, schedules, and BoQ</p>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-500">
                    <Settings className="h-4 w-4" />
                    <span>Supports PDF, DWG, DXF, and high-resolution images</span>
                  </div>
                </div>

                <FileUpload 
                  onProjectCreated={setCurrentProject}
                  projectSettings={{
                    name: projectName,
                    buildingCode,
                    buildingType,
                    numberOfFloors
                  }}
                />

                {/* Project Settings */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <Card>
                    <CardContent className="p-6">
                      <Label htmlFor="project-name" className="text-sm font-medium text-gray-700">Project Name</Label>
                      <Input
                        id="project-name"
                        value={projectName}
                        onChange={(e) => setProjectName(e.target.value)}
                        className="mt-2"
                        placeholder="Enter project name"
                      />
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <Label className="text-sm font-medium text-gray-700">Building Code</Label>
                      <Select value={buildingCode} onValueChange={setBuildingCode}>
                        <SelectTrigger className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Eurocode">Eurocode</SelectItem>
                          <SelectItem value="ACI">ACI (American)</SelectItem>
                          <SelectItem value="BS">BS (British)</SelectItem>
                          <SelectItem value="IS">IS (Indian)</SelectItem>
                        </SelectContent>
                      </Select>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <Label className="text-sm font-medium text-gray-700">Building Type</Label>
                      <Select value={buildingType} onValueChange={setBuildingType}>
                        <SelectTrigger className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Residential">Residential</SelectItem>
                          <SelectItem value="Commercial">Commercial</SelectItem>
                          <SelectItem value="Industrial">Industrial</SelectItem>
                          <SelectItem value="Institutional">Institutional</SelectItem>
                        </SelectContent>
                      </Select>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <Label htmlFor="floors" className="text-sm font-medium text-gray-700">Number of Floors</Label>
                      <Input
                        id="floors"
                        type="number"
                        min="1"
                        value={numberOfFloors}
                        onChange={(e) => setNumberOfFloors(parseInt(e.target.value) || 1)}
                        className="mt-2"
                      />
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {/* Processing Section */}
            {currentStage() === "processing" && (
              <Card className="max-w-2xl mx-auto">
                <CardContent className="p-8">
                  <div className="text-center mb-8">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                      <Loader2 className="h-8 w-8 text-primary animate-spin" />
                    </div>
                    <h2 className="text-xl font-bold text-gray-900">Processing Your Plans</h2>
                    <p className="text-gray-600">AI is analyzing your architectural drawings and generating structural elements</p>
                  </div>

                  <div className="space-y-4 mb-8">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Overall Progress</span>
                      <span className="text-sm text-gray-500">{getProgress()}%</span>
                    </div>
                    <Progress value={getProgress()} className="w-full" />
                  </div>

                  {processingLogs && (
                    <div className="space-y-4">
                      {processingLogs.slice(0, 4).map((log, index) => (
                        <div key={log.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            {getStatusIcon(log.status)}
                            <span className="font-medium">{log.message}</span>
                          </div>
                          <Badge variant={log.status === "completed" ? "default" : log.status === "failed" ? "destructive" : "secondary"}>
                            {log.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Results Section */}
            {currentStage() === "results" && projectId && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900">Project Results</h1>
                    <p className="text-gray-600 mt-1">
                      {currentProject?.buildingType} Building - {currentProject?.numberOfFloors} Floor(s) | 
                      Code: {currentProject?.buildingCode}
                    </p>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Button variant="outline">
                      <CloudUpload className="h-4 w-4 mr-2" />
                      Download All
                    </Button>
                    <Button>
                      <Play className="h-4 w-4 mr-2" />
                      Share
                    </Button>
                  </div>
                </div>

                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                  <TabsList className="grid w-full grid-cols-5">
                    <TabsTrigger value="3d-model">3D Model</TabsTrigger>
                    <TabsTrigger value="structural-plans">Structural Plans</TabsTrigger>
                    <TabsTrigger value="material-schedule">Material Schedule</TabsTrigger>
                    <TabsTrigger value="bar-bending">Bar Bending Schedule</TabsTrigger>
                    <TabsTrigger value="boq">Bill of Quantities</TabsTrigger>
                  </TabsList>

                  <TabsContent value="3d-model">
                    <ThreeDViewer projectId={projectId} />
                  </TabsContent>

                  <TabsContent value="structural-plans" className="space-y-6">
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      <div className="lg:col-span-2">
                        <StructuralPlans projectId={projectId} />
                      </div>
                      <div>
                        <ProjectSummary projectId={projectId} />
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="material-schedule">
                    <MaterialSchedule projectId={projectId} />
                  </TabsContent>

                  <TabsContent value="bar-bending">
                    <BarBendingSchedule projectId={projectId} />
                  </TabsContent>

                  <TabsContent value="boq">
                    <BillOfQuantities projectId={projectId} />
                  </TabsContent>
                </Tabs>
              </div>
            )}

            {/* Error Section */}
            {currentStage() === "error" && (
              <Card className="max-w-2xl mx-auto">
                <CardContent className="p-8 text-center">
                  <AlertCircle className="h-16 w-16 text-error mx-auto mb-4" />
                  <h2 className="text-xl font-bold text-gray-900 mb-2">Processing Failed</h2>
                  <p className="text-gray-600 mb-6">
                    There was an error processing your architectural plans. Please check the file format and try again.
                  </p>
                  <Button onClick={() => setCurrentProject(null)}>
                    Try Again
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
