# Plan2Struct AI

## Overview

Plan2Struct AI is a sophisticated full-stack web application that automates the conversion of architectural plans into structural engineering documents. The system uses computer vision and AI to analyze uploaded architectural drawings (PDFs, images, DWG/DXF files) and automatically generates structural plans, material schedules, bar bending schedules, and bills of quantities. Built with modern web technologies, it features a React-based frontend with shadcn/ui components, an Express.js backend with PostgreSQL database using Drizzle ORM, and Python-based image processing for plan analysis.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side application is built with **React 18** and **TypeScript**, utilizing a component-based architecture with shadcn/ui for consistent design. The application uses **Wouter** for lightweight client-side routing and **TanStack Query** for server state management and caching. The UI follows a dashboard-centric design with sidebar navigation supporting a multi-stage workflow (upload → processing → results → schedules → export). Components are organized into reusable UI components, feature-specific components, and page-level components.

### Backend Architecture  
The server architecture follows a **REST API pattern** built with **Express.js** and **TypeScript**. The backend implements a service-oriented architecture with clear separation between routing, business logic, and data access layers. File uploads are handled via **multer** with support for PDF, image, DWG, and DXF formats up to 50MB. The processing pipeline integrates **Python scripts** for computer vision-based plan analysis using **OpenCV**.

### Database Design
The application uses **PostgreSQL** as the primary database with **Drizzle ORM** for type-safe database operations. The schema is designed around a project-centric model with related entities for files, structural elements, schedules, and processing logs. Key tables include projects (with metadata and status tracking), project_files (file storage metadata), structural_elements (analyzed building components), material_schedule (material requirements), bar_bending_schedule (reinforcement details), bill_of_quantities (cost estimates), and processing_logs (audit trail and progress tracking).

### Processing Pipeline
The core processing workflow involves multi-stage analysis starting with file upload and validation, followed by Python-based computer vision analysis using OpenCV for edge detection and contour analysis to identify structural elements. The system then generates structural plans based on building codes (Eurocode support), calculates material requirements and reinforcement schedules, and produces exportable bills of quantities with cost calculations.

### State Management
The frontend uses **TanStack Query** for server state management with automatic caching and background refetching. Local component state is managed with React hooks, while global application state is minimal and handled through React Context where needed. The processing status is tracked in real-time with polling mechanisms for active projects.

### File Handling
File uploads support multiple formats (PDF, PNG, JPG, JPEG, DWG, DXF) with validation and size limits. Files are stored on the server filesystem with metadata tracked in the database. The processing service handles file conversion and analysis asynchronously with progress tracking and error handling.

### Development & Build Process
The application uses **Vite** for development and production builds, providing hot module replacement and optimized bundling. **esbuild** handles server-side compilation for production. The monorepo structure with shared TypeScript schemas ensures type consistency between frontend and backend.

## Recent Updates (August 2025)

### 3D Model Reconstruction Workflow Integration
- **Complete 3D modeling pipeline** added based on Dynamo-style parametric approach
- **Advanced floor detection** using Mask R-CNN deep learning with OpenCV fallback
- **3D reconstruction engine** (server/processors/3d-reconstruction.py) - 600+ lines
- **Interactive 3D viewer** (client/src/components/3d-viewer.tsx) with multiple view modes
- **Export capabilities** - OBJ, IFC, JSON formats for BIM workflows
- **Parametric modeling** - GeometryEngine for 3D geometry creation and manipulation
- **Level generation** - Building levels with proper elevations similar to Revit workflows
- **Element extrusion** - 2D profiles converted to 3D volumes with structural properties

### Processing Pipeline Enhancement
- **Multi-stage workflow** - 2D analysis → 3D reconstruction → structural design → schedules
- **Real-time progress tracking** with detailed logging for each reconstruction phase
- **Hybrid detection system** - automatically selects best analysis method per file type
- **Building model reconstruction** before structural analysis improves accuracy significantly

## External Dependencies

### Core Frameworks & Libraries
- **React 18** with TypeScript for frontend development
- **Express.js** with TypeScript for backend API
- **Vite** for frontend bundling and development server
- **Wouter** for lightweight client-side routing
- **TanStack Query** for server state management

### Database & ORM
- **PostgreSQL** as the primary database
- **Drizzle ORM** for type-safe database operations and migrations
- **@neondatabase/serverless** for database connectivity

### UI Components & Styling
- **Radix UI** primitives for accessible component foundation
- **Tailwind CSS** for utility-first styling
- **shadcn/ui** component library for consistent design system
- **Lucide React** for consistent iconography

### File Processing & Validation
- **multer** for multipart form data and file upload handling
- **Python** with **OpenCV** for computer vision and image processing
- Custom validation for architectural file formats (PDF, DWG, DXF)

### Development Tools
- **TypeScript** for static typing across the stack
- **Drizzle Kit** for database schema management and migrations
- **ESBuild** for optimized server-side bundling
- **PostCSS** and **Autoprefixer** for CSS processing

### Session & Security
- **connect-pg-simple** for PostgreSQL-backed session storage
- Built-in Express session management for user state
- CORS and security middleware for API protection