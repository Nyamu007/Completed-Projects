#!/usr/bin/env python3
"""
3D Floor Plan Reconstruction Module
Reconstructs 3D models from 2D floor plans before structural analysis
Based on Dynamo-style parametric modeling approach
"""

import os
import sys
import json
import argparse
import numpy as np
import cv2
from pathlib import Path
import logging
from typing import Dict, List, Tuple, Any, Optional
import math

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class GeometryEngine:
    """Core geometry engine for 3D reconstruction"""
    
    @staticmethod
    def create_point(x: float, y: float, z: float = 0.0) -> Dict[str, float]:
        """Create a 3D point"""
        return {'x': x, 'y': y, 'z': z}
    
    @staticmethod
    def create_line(start_point: Dict, end_point: Dict) -> Dict[str, Any]:
        """Create a line between two points"""
        return {
            'type': 'line',
            'start': start_point,
            'end': end_point,
            'length': GeometryEngine.distance_3d(start_point, end_point)
        }
    
    @staticmethod
    def create_rectangle(corner1: Dict, corner2: Dict, height: float = 3000) -> Dict[str, Any]:
        """Create a 3D rectangle/wall"""
        return {
            'type': 'rectangle',
            'corner1': corner1,
            'corner2': corner2,
            'height': height,
            'area': abs((corner2['x'] - corner1['x']) * (corner2['y'] - corner1['y'])),
            'volume': abs((corner2['x'] - corner1['x']) * (corner2['y'] - corner1['y']) * height)
        }
    
    @staticmethod
    def distance_3d(p1: Dict, p2: Dict) -> float:
        """Calculate 3D distance between two points"""
        dx = p2['x'] - p1['x']
        dy = p2['y'] - p1['y']
        dz = p2['z'] - p1['z']
        return math.sqrt(dx*dx + dy*dy + dz*dz)
    
    @staticmethod
    def extrude_profile(profile_points: List[Dict], height: float) -> Dict[str, Any]:
        """Extrude a 2D profile to create 3D geometry"""
        return {
            'type': 'extrusion',
            'profile': profile_points,
            'height': height,
            'volume': GeometryEngine.calculate_profile_area(profile_points) * height
        }
    
    @staticmethod
    def calculate_profile_area(points: List[Dict]) -> float:
        """Calculate area of a polygon using shoelace formula"""
        if len(points) < 3:
            return 0.0
        
        area = 0.0
        n = len(points)
        for i in range(n):
            j = (i + 1) % n
            area += points[i]['x'] * points[j]['y']
            area -= points[j]['x'] * points[i]['y']
        
        return abs(area) / 2.0

class FloorPlanReconstructor:
    """Main class for 3D floor plan reconstruction"""
    
    def __init__(self):
        self.geometry_engine = GeometryEngine()
        self.reconstruction_data = {
            'levels': [],
            'walls': [],
            'openings': [],
            'rooms': [],
            'structural_elements': [],
            'geometry': []
        }
        
        # Standard building parameters
        self.default_wall_thickness = 200  # mm
        self.default_floor_height = 3000   # mm
        self.default_slab_thickness = 150  # mm
        
    def load_detection_results(self, detection_file: str) -> Dict[str, Any]:
        """Load results from floor detection analysis"""
        try:
            with open(detection_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load detection results: {e}")
            return {'detections': []}
    
    def create_building_levels(self, num_floors: int, floor_height: float = None) -> List[Dict]:
        """Create building levels similar to Dynamo Level.ByElevationAndName"""
        if floor_height is None:
            floor_height = self.default_floor_height
            
        levels = []
        for i in range(num_floors + 1):  # Include ground level
            elevation = i * floor_height
            level = {
                'name': f'Level {i}' if i > 0 else 'Ground Level',
                'elevation': elevation,
                'id': f'level_{i}',
                'type': 'level'
            }
            levels.append(level)
            
        self.reconstruction_data['levels'] = levels
        logger.info(f"Created {len(levels)} building levels")
        return levels
    
    def reconstruct_walls_from_detections(self, detections: List[Dict]) -> List[Dict]:
        """Reconstruct 3D walls from 2D detections"""
        walls = []
        wall_counter = 1
        
        for detection in detections:
            if detection.get('class') == 'wall':
                bbox = detection.get('bbox', [0, 0, 0, 0])
                confidence = detection.get('confidence', 0.0)
                
                # Convert 2D bbox to 3D wall geometry
                x, y, width, height = bbox
                
                # Create wall geometry points
                p1 = self.geometry_engine.create_point(x, y, 0)
                p2 = self.geometry_engine.create_point(x + width, y, 0)
                p3 = self.geometry_engine.create_point(x + width, y + height, 0)
                p4 = self.geometry_engine.create_point(x, y + height, 0)
                
                # Create 3D wall by extrusion
                wall_profile = [p1, p2, p3, p4]
                wall_geometry = self.geometry_engine.extrude_profile(
                    wall_profile, 
                    self.default_floor_height
                )
                
                wall = {
                    'id': f'WALL-{wall_counter:03d}',
                    'type': 'wall',
                    'profile_points': wall_profile,
                    'thickness': self.default_wall_thickness,
                    'height': self.default_floor_height,
                    'geometry': wall_geometry,
                    'material': 'Concrete',
                    'confidence': confidence,
                    'area': wall_geometry['volume'] / self.default_wall_thickness,
                    'volume': wall_geometry['volume']
                }
                
                walls.append(wall)
                wall_counter += 1
        
        self.reconstruction_data['walls'] = walls
        logger.info(f"Reconstructed {len(walls)} walls from detections")
        return walls
    
    def reconstruct_openings_from_detections(self, detections: List[Dict]) -> List[Dict]:
        """Reconstruct doors and windows from detections"""
        openings = []
        opening_counter = 1
        
        for detection in detections:
            element_class = detection.get('class')
            if element_class in ['door', 'window']:
                bbox = detection.get('bbox', [0, 0, 0, 0])
                confidence = detection.get('confidence', 0.0)
                
                x, y, width, height = bbox
                
                # Create opening geometry
                p1 = self.geometry_engine.create_point(x, y, 0)
                p2 = self.geometry_engine.create_point(x + width, y + height, 0)
                
                opening_height = 2100 if element_class == 'door' else 1200  # Standard heights
                
                opening = {
                    'id': f'{element_class.upper()}-{opening_counter:03d}',
                    'type': element_class,
                    'corner1': p1,
                    'corner2': p2,
                    'width': width,
                    'height': opening_height,
                    'area': width * opening_height,
                    'confidence': confidence
                }
                
                openings.append(opening)
                opening_counter += 1
        
        self.reconstruction_data['openings'] = openings
        logger.info(f"Reconstructed {len(openings)} openings from detections")
        return openings
    
    def reconstruct_structural_elements(self, detections: List[Dict]) -> List[Dict]:
        """Reconstruct structural elements (columns, beams, slabs)"""
        structural_elements = []
        element_counter = 1
        
        for detection in detections:
            element_class = detection.get('class')
            if element_class in ['column', 'beam', 'slab']:
                bbox = detection.get('bbox', [0, 0, 0, 0])
                confidence = detection.get('confidence', 0.0)
                
                x, y, width, height = bbox
                
                if element_class == 'column':
                    # Create column geometry
                    center = self.geometry_engine.create_point(
                        x + width/2, y + height/2, 0
                    )
                    
                    element = {
                        'id': f'COL-{element_counter:03d}',
                        'type': 'column',
                        'center_point': center,
                        'width': width,
                        'depth': height,
                        'height': self.default_floor_height,
                        'cross_sectional_area': width * height,
                        'volume': width * height * self.default_floor_height,
                        'material': 'Concrete M30',
                        'confidence': confidence
                    }
                    
                elif element_class == 'beam':
                    # Create beam geometry
                    start_point = self.geometry_engine.create_point(x, y, self.default_floor_height - 500)
                    end_point = self.geometry_engine.create_point(x + width, y, self.default_floor_height - 500)
                    
                    element = {
                        'id': f'BEAM-{element_counter:03d}',
                        'type': 'beam',
                        'start_point': start_point,
                        'end_point': end_point,
                        'width': 300,  # Standard beam width
                        'depth': 450,  # Standard beam depth
                        'length': width,
                        'cross_sectional_area': 300 * 450,
                        'volume': 300 * 450 * width,
                        'material': 'Concrete M25',
                        'confidence': confidence
                    }
                    
                elif element_class == 'slab':
                    # Create slab geometry
                    corners = [
                        self.geometry_engine.create_point(x, y, self.default_floor_height),
                        self.geometry_engine.create_point(x + width, y, self.default_floor_height),
                        self.geometry_engine.create_point(x + width, y + height, self.default_floor_height),
                        self.geometry_engine.create_point(x, y + height, self.default_floor_height)
                    ]
                    
                    element = {
                        'id': f'SLAB-{element_counter:03d}',
                        'type': 'slab',
                        'corner_points': corners,
                        'length': width,
                        'width': height,
                        'thickness': self.default_slab_thickness,
                        'area': width * height,
                        'volume': width * height * self.default_slab_thickness,
                        'material': 'Concrete M25',
                        'confidence': confidence
                    }
                
                structural_elements.append(element)
                element_counter += 1
        
        self.reconstruction_data['structural_elements'] = structural_elements
        logger.info(f"Reconstructed {len(structural_elements)} structural elements")
        return structural_elements
    
    def create_floor_plan_views(self, levels: List[Dict]) -> List[Dict]:
        """Create floor plan views for each level (similar to Dynamo FloorPlanView.ByLevel)"""
        floor_plan_views = []
        
        for level in levels:
            if level['elevation'] >= 0:  # Only create views for above-ground levels
                view = {
                    'id': f"FloorPlan_{level['id']}",
                    'name': f"Floor Plan - {level['name']}",
                    'level_id': level['id'],
                    'elevation': level['elevation'],
                    'type': 'floor_plan_view',
                    'view_direction': 'top',
                    'cut_plane_elevation': level['elevation'] + 1200  # 1.2m above floor
                }
                floor_plan_views.append(view)
        
        logger.info(f"Created {len(floor_plan_views)} floor plan views")
        return floor_plan_views
    
    def generate_3d_model_data(self, project_id: str) -> Dict[str, Any]:
        """Generate complete 3D model data for visualization"""
        model_data = {
            'project_id': project_id,
            'model_type': '3d_reconstruction',
            'geometry_data': self.reconstruction_data,
            'bounding_box': self.calculate_model_bounds(),
            'statistics': self.calculate_model_statistics(),
            'export_formats': ['ifc', 'obj', 'dae', 'fbx'],
            'visualization_data': self.prepare_visualization_data()
        }
        
        return model_data
    
    def calculate_model_bounds(self) -> Dict[str, Dict[str, float]]:
        """Calculate 3D bounding box of the entire model"""
        all_points = []
        
        # Collect all geometry points
        for wall in self.reconstruction_data.get('walls', []):
            for point in wall.get('profile_points', []):
                all_points.append(point)
        
        for element in self.reconstruction_data.get('structural_elements', []):
            if 'center_point' in element:
                all_points.append(element['center_point'])
            if 'corner_points' in element:
                all_points.extend(element['corner_points'])
        
        if not all_points:
            return {'min': {'x': 0, 'y': 0, 'z': 0}, 'max': {'x': 0, 'y': 0, 'z': 0}}
        
        min_x = min(p['x'] for p in all_points)
        max_x = max(p['x'] for p in all_points)
        min_y = min(p['y'] for p in all_points)
        max_y = max(p['y'] for p in all_points)
        min_z = min(p['z'] for p in all_points)
        max_z = max(p['z'] for p in all_points)
        
        return {
            'min': {'x': min_x, 'y': min_y, 'z': min_z},
            'max': {'x': max_x, 'y': max_y, 'z': max_z}
        }
    
    def calculate_model_statistics(self) -> Dict[str, Any]:
        """Calculate model statistics"""
        stats = {
            'total_walls': len(self.reconstruction_data.get('walls', [])),
            'total_openings': len(self.reconstruction_data.get('openings', [])),
            'total_structural_elements': len(self.reconstruction_data.get('structural_elements', [])),
            'total_levels': len(self.reconstruction_data.get('levels', [])),
            'total_concrete_volume': 0,
            'total_built_area': 0,
            'confidence_scores': []
        }
        
        # Calculate volumes and areas
        for wall in self.reconstruction_data.get('walls', []):
            stats['total_concrete_volume'] += wall.get('volume', 0)
            stats['confidence_scores'].append(wall.get('confidence', 0))
        
        for element in self.reconstruction_data.get('structural_elements', []):
            stats['total_concrete_volume'] += element.get('volume', 0)
            stats['confidence_scores'].append(element.get('confidence', 0))
        
        # Calculate average confidence
        if stats['confidence_scores']:
            stats['average_confidence'] = sum(stats['confidence_scores']) / len(stats['confidence_scores'])
        else:
            stats['average_confidence'] = 0.0
        
        return stats
    
    def prepare_visualization_data(self) -> Dict[str, Any]:
        """Prepare data for 3D visualization"""
        viz_data = {
            'meshes': [],
            'materials': [],
            'cameras': [],
            'lighting': []
        }
        
        # Create mesh data for walls
        for wall in self.reconstruction_data.get('walls', []):
            mesh = {
                'id': wall['id'],
                'type': 'wall_mesh',
                'vertices': self.wall_to_vertices(wall),
                'faces': self.wall_to_faces(wall),
                'material': 'concrete_wall',
                'color': '#888888'
            }
            viz_data['meshes'].append(mesh)
        
        # Create mesh data for structural elements
        for element in self.reconstruction_data.get('structural_elements', []):
            mesh = {
                'id': element['id'],
                'type': f"{element['type']}_mesh",
                'vertices': self.element_to_vertices(element),
                'faces': self.element_to_faces(element),
                'material': f"concrete_{element['type']}",
                'color': self.get_element_color(element['type'])
            }
            viz_data['meshes'].append(mesh)
        
        # Add default camera
        bounds = self.calculate_model_bounds()
        center_x = (bounds['min']['x'] + bounds['max']['x']) / 2
        center_y = (bounds['min']['y'] + bounds['max']['y']) / 2
        
        camera = {
            'position': {
                'x': center_x + 5000,
                'y': center_y + 5000,
                'z': 3000
            },
            'target': {
                'x': center_x,
                'y': center_y,
                'z': 0
            },
            'up': {'x': 0, 'y': 0, 'z': 1}
        }
        viz_data['cameras'].append(camera)
        
        return viz_data
    
    def wall_to_vertices(self, wall: Dict) -> List[List[float]]:
        """Convert wall geometry to vertex array"""
        vertices = []
        profile_points = wall.get('profile_points', [])
        height = wall.get('height', 3000)
        
        # Bottom vertices
        for point in profile_points:
            vertices.append([point['x'], point['y'], point['z']])
        
        # Top vertices
        for point in profile_points:
            vertices.append([point['x'], point['y'], point['z'] + height])
        
        return vertices
    
    def wall_to_faces(self, wall: Dict) -> List[List[int]]:
        """Convert wall geometry to face indices"""
        profile_count = len(wall.get('profile_points', []))
        faces = []
        
        # Side faces
        for i in range(profile_count):
            next_i = (i + 1) % profile_count
            # Triangle 1
            faces.append([i, next_i, i + profile_count])
            # Triangle 2  
            faces.append([next_i, next_i + profile_count, i + profile_count])
        
        return faces
    
    def element_to_vertices(self, element: Dict) -> List[List[float]]:
        """Convert structural element to vertex array"""
        vertices = []
        element_type = element.get('type')
        
        if element_type == 'column':
            center = element['center_point']
            width = element['width']
            depth = element['depth']
            height = element['height']
            
            # Generate box vertices for column
            half_w = width / 2
            half_d = depth / 2
            
            # Bottom vertices
            vertices.extend([
                [center['x'] - half_w, center['y'] - half_d, center['z']],
                [center['x'] + half_w, center['y'] - half_d, center['z']],
                [center['x'] + half_w, center['y'] + half_d, center['z']],
                [center['x'] - half_w, center['y'] + half_d, center['z']]
            ])
            
            # Top vertices
            vertices.extend([
                [center['x'] - half_w, center['y'] - half_d, center['z'] + height],
                [center['x'] + half_w, center['y'] - half_d, center['z'] + height],
                [center['x'] + half_w, center['y'] + half_d, center['z'] + height],
                [center['x'] - half_w, center['y'] + half_d, center['z'] + height]
            ])
        
        return vertices
    
    def element_to_faces(self, element: Dict) -> List[List[int]]:
        """Convert structural element to face indices"""
        element_type = element.get('type')
        
        if element_type == 'column':
            # Standard box faces
            return [
                [0, 1, 2], [0, 2, 3],  # Bottom
                [4, 7, 6], [4, 6, 5],  # Top
                [0, 4, 5], [0, 5, 1],  # Front
                [2, 6, 7], [2, 7, 3],  # Back
                [1, 5, 6], [1, 6, 2],  # Right
                [0, 3, 7], [0, 7, 4]   # Left
            ]
        
        return []
    
    def get_element_color(self, element_type: str) -> str:
        """Get color for element type"""
        colors = {
            'wall': '#888888',
            'column': '#666666',
            'beam': '#777777',
            'slab': '#999999'
        }
        return colors.get(element_type, '#888888')
    
    def reconstruct_complete_model(self, detection_file: str, project_id: str, num_floors: int = 1) -> Dict[str, Any]:
        """Complete 3D reconstruction workflow"""
        logger.info(f"Starting 3D reconstruction for project {project_id}")
        
        # Load detection results
        detection_data = self.load_detection_results(detection_file)
        detections = detection_data.get('detections', [])
        
        if not detections:
            logger.warning("No detections found, creating minimal model")
            detections = []
        
        # Create building levels
        levels = self.create_building_levels(num_floors)
        
        # Reconstruct 3D geometry
        walls = self.reconstruct_walls_from_detections(detections)
        openings = self.reconstruct_openings_from_detections(detections)
        structural_elements = self.reconstruct_structural_elements(detections)
        
        # Create views
        floor_plan_views = self.create_floor_plan_views(levels)
        
        # Generate complete model data
        model_data = self.generate_3d_model_data(project_id)
        
        # Add view data
        model_data['floor_plan_views'] = floor_plan_views
        
        logger.info(f"3D reconstruction completed for project {project_id}")
        return model_data


def main():
    """Main execution function"""
    parser = argparse.ArgumentParser(description='3D Floor Plan Reconstruction')
    parser.add_argument('--detection_file', required=True, help='Path to detection results JSON')
    parser.add_argument('--project_id', required=True, help='Project ID')
    parser.add_argument('--num_floors', type=int, default=1, help='Number of floors')
    parser.add_argument('--output_path', help='Path to save reconstruction results')
    
    args = parser.parse_args()
    
    try:
        # Initialize reconstructor
        reconstructor = FloorPlanReconstructor()
        
        # Perform 3D reconstruction
        results = reconstructor.reconstruct_complete_model(
            args.detection_file, 
            args.project_id, 
            args.num_floors
        )
        
        # Output results
        if args.output_path:
            with open(args.output_path, 'w') as f:
                json.dump(results, f, indent=2)
            logger.info(f"3D reconstruction results saved to {args.output_path}")
        else:
            print(json.dumps(results, indent=2))
            
        return 0
        
    except Exception as e:
        logger.error(f"3D reconstruction failed: {e}")
        error_result = {
            'project_id': args.project_id,
            'reconstruction_status': 'failed',
            'error': str(e)
        }
        
        if args.output_path:
            with open(args.output_path, 'w') as f:
                json.dump(error_result, f, indent=2)
        else:
            print(json.dumps(error_result, indent=2))
            
        return 1


if __name__ == '__main__':
    sys.exit(main())