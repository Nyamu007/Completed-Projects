#!/usr/bin/env python3
"""
Advanced Floor Plan Detection using Mask R-CNN
Integrated version of the floor detection system for Plan2Struct AI
"""

import os
import sys
import json
import argparse
import numpy as np
import cv2
from pathlib import Path
import logging
from typing import Dict, List, Tuple, Any

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FloorPlanDetector:
    """
    Advanced floor plan detector using Mask R-CNN for architectural element detection
    """
    
    def __init__(self, model_path: str = None):
        """Initialize the floor plan detector"""
        self.model_path = model_path
        self.model = None
        self.class_names = [
            'BG', 'wall', 'door', 'window', 'column', 'beam', 
            'slab', 'stair', 'room', 'opening', 'dimension'
        ]
        
        # Detection confidence thresholds
        self.confidence_threshold = 0.7
        self.nms_threshold = 0.4
        
    def setup_model(self):
        """Setup the Mask R-CNN model for detection"""
        try:
            # Try to import Mask R-CNN dependencies
            import mrcnn.config
            import mrcnn.utils
            import mrcnn.model as modellib
            from mrcnn import visualize
            
            logger.info("Mask R-CNN dependencies loaded successfully")
            
            # Configuration for floor plan detection
            class FloorPlanConfig(mrcnn.config.Config):
                NAME = "floorplan"
                IMAGES_PER_GPU = 1
                NUM_CLASSES = len(self.class_names)
                DETECTION_MIN_CONFIDENCE = self.confidence_threshold
                
            self.config = FloorPlanConfig()
            
            # Create model in inference mode
            self.model = modellib.MaskRCNN(
                mode="inference", 
                config=self.config, 
                model_dir=os.path.dirname(self.model_path) if self.model_path else "./models"
            )
            
            # Load trained weights if available
            if self.model_path and os.path.exists(self.model_path):
                self.model.load_weights(self.model_path, by_name=True)
                logger.info(f"Loaded model weights from {self.model_path}")
            else:
                logger.warning("No trained model weights found, using basic OpenCV detection")
                self.model = None
                
        except ImportError as e:
            logger.warning(f"Mask R-CNN not available: {e}. Falling back to OpenCV detection")
            self.model = None
    
    def preprocess_image(self, image_path: str) -> np.ndarray:
        """Preprocess the floor plan image"""
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image from {image_path}")
            
        # Convert to RGB for Mask R-CNN
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Resize if too large (optional)
        height, width = image_rgb.shape[:2]
        if max(height, width) > 2048:
            scale = 2048 / max(height, width)
            new_width = int(width * scale)
            new_height = int(height * scale)
            image_rgb = cv2.resize(image_rgb, (new_width, new_height))
            
        return image_rgb
    
    def detect_with_maskrcnn(self, image: np.ndarray) -> Dict[str, Any]:
        """Detect architectural elements using Mask R-CNN"""
        if self.model is None:
            raise RuntimeError("Mask R-CNN model not available")
            
        # Run detection
        results = self.model.detect([image], verbose=1)
        r = results[0]
        
        # Extract detection results
        detections = []
        for i in range(len(r['class_ids'])):
            class_id = r['class_ids'][i]
            class_name = self.class_names[class_id]
            score = r['scores'][i]
            bbox = r['rois'][i]
            mask = r['masks'][:, :, i]
            
            # Convert bbox to standard format [x, y, width, height]
            y1, x1, y2, x2 = bbox
            detection = {
                'class': class_name,
                'confidence': float(score),
                'bbox': [int(x1), int(y1), int(x2-x1), int(y2-y1)],
                'mask': mask.tolist() if mask.size < 10000 else None,  # Include mask if not too large
                'area': int(np.sum(mask))
            }
            detections.append(detection)
            
        return {
            'detections': detections,
            'method': 'mask_rcnn',
            'image_shape': image.shape
        }
    
    def detect_with_opencv(self, image: np.ndarray) -> Dict[str, Any]:
        """Fallback detection using OpenCV for basic shape detection"""
        logger.info("Using OpenCV fallback detection")
        
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        
        # Edge detection
        edges = cv2.Canny(gray, 50, 150, apertureSize=3)
        
        # Find contours
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        detections = []
        for contour in contours:
            # Filter small contours
            area = cv2.contourArea(contour)
            if area < 100:
                continue
                
            # Get bounding rectangle
            x, y, w, h = cv2.boundingRect(contour)
            
            # Classify based on aspect ratio and area
            aspect_ratio = w / h if h > 0 else 1
            element_type = self.classify_element(area, aspect_ratio, w, h)
            
            detection = {
                'class': element_type,
                'confidence': 0.6,  # Default confidence for OpenCV detection
                'bbox': [x, y, w, h],
                'area': int(area),
                'aspect_ratio': round(aspect_ratio, 2)
            }
            detections.append(detection)
            
        return {
            'detections': detections,
            'method': 'opencv',
            'image_shape': image.shape
        }
    
    def classify_element(self, area: float, aspect_ratio: float, width: int, height: int) -> str:
        """Classify architectural element based on geometric properties"""
        # Simple heuristic classification
        if aspect_ratio > 5 or aspect_ratio < 0.2:
            return 'wall'
        elif area > 50000:
            return 'room'
        elif 0.8 <= aspect_ratio <= 1.2 and area > 1000:
            return 'column'
        elif aspect_ratio > 2 and width > 50:
            return 'beam'
        elif area < 500:
            return 'opening'
        else:
            return 'wall'
    
    def detect_elements(self, image_path: str) -> Dict[str, Any]:
        """Main detection method"""
        try:
            # Preprocess image
            image = self.preprocess_image(image_path)
            
            # Try Mask R-CNN detection first
            if self.model is not None:
                try:
                    results = self.detect_with_maskrcnn(image)
                    logger.info(f"Detected {len(results['detections'])} elements using Mask R-CNN")
                    return results
                except Exception as e:
                    logger.error(f"Mask R-CNN detection failed: {e}")
            
            # Fallback to OpenCV detection
            results = self.detect_with_opencv(image)
            logger.info(f"Detected {len(results['detections'])} elements using OpenCV")
            return results
            
        except Exception as e:
            logger.error(f"Detection failed: {e}")
            return {
                'detections': [],
                'method': 'error',
                'error': str(e),
                'image_shape': None
            }
    
    def analyze_floor_plan(self, image_path: str, project_id: str) -> Dict[str, Any]:
        """Complete floor plan analysis"""
        logger.info(f"Starting floor plan analysis for project {project_id}")
        
        # Detect architectural elements
        detection_results = self.detect_elements(image_path)
        
        # Group detections by type
        elements_by_type = {}
        for detection in detection_results.get('detections', []):
            element_type = detection['class']
            if element_type not in elements_by_type:
                elements_by_type[element_type] = []
            elements_by_type[element_type].append(detection)
        
        # Calculate statistics
        total_elements = len(detection_results.get('detections', []))
        element_counts = {k: len(v) for k, v in elements_by_type.items()}
        
        # Generate structural analysis
        structural_elements = self.generate_structural_elements(elements_by_type, project_id)
        
        # Calculate material requirements
        material_schedule = self.calculate_materials(structural_elements)
        
        # Generate bar bending schedule
        bar_schedule = self.generate_bar_schedule(structural_elements)
        
        # Calculate quantities and costs
        boq = self.calculate_boq(material_schedule, bar_schedule)
        
        analysis_results = {
            'project_id': project_id,
            'detection_method': detection_results.get('method', 'unknown'),
            'total_elements_detected': total_elements,
            'element_counts': element_counts,
            'structural_elements': structural_elements,
            'material_schedule': material_schedule,
            'bar_bending_schedule': bar_schedule,
            'bill_of_quantities': boq,
            'processing_status': 'completed'
        }
        
        logger.info(f"Floor plan analysis completed for project {project_id}")
        return analysis_results
    
    def generate_structural_elements(self, elements_by_type: Dict, project_id: str) -> List[Dict]:
        """Generate structural elements from detected elements"""
        structural_elements = []
        element_counter = 1
        
        for element_type, detections in elements_by_type.items():
            for detection in detections:
                bbox = detection.get('bbox', [0, 0, 0, 0])
                
                element = {
                    'project_id': project_id,
                    'element_type': element_type,
                    'element_id': f"{element_type.upper()}-{element_counter:03d}",
                    'dimensions': {
                        'length': bbox[2],  # width
                        'width': bbox[3],   # height
                        'height': 3000 if element_type in ['wall', 'column'] else 250  # default heights in mm
                    },
                    'material_grade': self.get_material_grade(element_type),
                    'reinforcement': self.get_reinforcement_details(element_type, bbox),
                    'quantity': 1,
                    'unit': self.get_unit(element_type)
                }
                structural_elements.append(element)
                element_counter += 1
                
        return structural_elements
    
    def get_material_grade(self, element_type: str) -> str:
        """Get appropriate material grade for element type"""
        material_grades = {
            'wall': 'M25',
            'column': 'M30',
            'beam': 'M25',
            'slab': 'M25',
            'foundation': 'M20'
        }
        return material_grades.get(element_type, 'M25')
    
    def get_reinforcement_details(self, element_type: str, bbox: List[int]) -> Dict:
        """Get reinforcement details based on element type and size"""
        area = bbox[2] * bbox[3] if len(bbox) >= 4 else 1000
        
        if element_type == 'column':
            return {
                'main_bars': '8-16mm',
                'stirrups': '8mm @ 150mm c/c',
                'steel_grade': 'Fe415'
            }
        elif element_type == 'beam':
            return {
                'main_bars': '4-20mm + 2-16mm',
                'stirrups': '8mm @ 100mm c/c',
                'steel_grade': 'Fe415'
            }
        elif element_type == 'slab':
            return {
                'main_bars': '10mm @ 150mm c/c',
                'distribution_bars': '8mm @ 200mm c/c',
                'steel_grade': 'Fe415'
            }
        else:
            return {
                'reinforcement': 'As per structural drawing',
                'steel_grade': 'Fe415'
            }
    
    def get_unit(self, element_type: str) -> str:
        """Get appropriate unit for element type"""
        units = {
            'wall': 'm2',
            'column': 'nos',
            'beam': 'rm',
            'slab': 'm2',
            'door': 'nos',
            'window': 'nos'
        }
        return units.get(element_type, 'nos')
    
    def calculate_materials(self, structural_elements: List[Dict]) -> List[Dict]:
        """Calculate material requirements"""
        materials = []
        item_counter = 1
        
        # Material rates (example values)
        material_rates = {
            'concrete_m20': 4500,  # per m3
            'concrete_m25': 4800,
            'concrete_m30': 5100,
            'steel_fe415': 65,     # per kg
            'formwork': 180        # per m2
        }
        
        for element in structural_elements:
            element_type = element['element_type']
            dimensions = element['dimensions']
            material_grade = element['material_grade']
            
            # Calculate concrete volume
            if element_type in ['wall', 'column', 'beam', 'slab']:
                length = dimensions.get('length', 0) / 1000  # convert to meters
                width = dimensions.get('width', 0) / 1000
                height = dimensions.get('height', 0) / 1000
                
                volume = length * width * height
                
                if volume > 0:
                    concrete_key = f'concrete_{material_grade.lower()}'
                    rate = material_rates.get(concrete_key, 4800)
                    
                    material = {
                        'project_id': element['project_id'],
                        'item_code': f'MAT-{item_counter:03d}',
                        'description': f'{material_grade} Concrete for {element_type}',
                        'unit': 'm3',
                        'quantity': round(volume, 3),
                        'rate': rate,
                        'amount': round(volume * rate, 2),
                        'category': 'concrete'
                    }
                    materials.append(material)
                    item_counter += 1
        
        return materials
    
    def generate_bar_schedule(self, structural_elements: List[Dict]) -> List[Dict]:
        """Generate bar bending schedule"""
        bar_schedule = []
        bar_counter = 1
        
        for element in structural_elements:
            if element['element_type'] in ['column', 'beam', 'slab']:
                reinforcement = element.get('reinforcement', {})
                
                # Main reinforcement
                if 'main_bars' in reinforcement:
                    bar_item = {
                        'project_id': element['project_id'],
                        'bar_mark': f'B{bar_counter}',
                        'element_id': element['element_id'],
                        'element_type': element['element_type'],
                        'bar_diameter': '16',  # example
                        'bar_length': 3000,    # example in mm
                        'quantity': 8,         # example
                        'total_length': 24000,
                        'weight_per_meter': 1.58,  # kg/m for 16mm bar
                        'total_weight': 37.92,
                        'bar_shape': 'Straight',
                        'steel_grade': reinforcement.get('steel_grade', 'Fe415')
                    }
                    bar_schedule.append(bar_item)
                    bar_counter += 1
        
        return bar_schedule
    
    def calculate_boq(self, material_schedule: List[Dict], bar_schedule: List[Dict]) -> List[Dict]:
        """Calculate Bill of Quantities"""
        boq = []
        item_counter = 1
        
        # Add concrete items
        for material in material_schedule:
            boq_item = {
                'project_id': material['project_id'],
                'item_code': material['item_code'],
                'description': material['description'],
                'unit': material['unit'],
                'quantity': material['quantity'],
                'rate': material['rate'],
                'amount': material['amount'],
                'category': material['category']
            }
            boq.append(boq_item)
        
        # Add steel items
        steel_total_weight = sum(item.get('total_weight', 0) for item in bar_schedule)
        if steel_total_weight > 0:
            steel_rate = 65  # per kg
            boq_item = {
                'project_id': bar_schedule[0]['project_id'] if bar_schedule else '',
                'item_code': f'BOQ-{len(boq)+1:03d}',
                'description': 'Reinforcement Steel Fe415',
                'unit': 'kg',
                'quantity': round(steel_total_weight, 2),
                'rate': steel_rate,
                'amount': round(steel_total_weight * steel_rate, 2),
                'category': 'steel'
            }
            boq.append(boq_item)
        
        return boq


def main():
    """Main execution function"""
    parser = argparse.ArgumentParser(description='Advanced Floor Plan Detection')
    parser.add_argument('--image_path', required=True, help='Path to the floor plan image')
    parser.add_argument('--project_id', required=True, help='Project ID')
    parser.add_argument('--model_path', help='Path to trained model weights')
    parser.add_argument('--output_path', help='Path to save analysis results')
    
    args = parser.parse_args()
    
    try:
        # Initialize detector
        detector = FloorPlanDetector(model_path=args.model_path)
        detector.setup_model()
        
        # Perform analysis
        results = detector.analyze_floor_plan(args.image_path, args.project_id)
        
        # Output results
        if args.output_path:
            with open(args.output_path, 'w') as f:
                json.dump(results, f, indent=2)
            logger.info(f"Results saved to {args.output_path}")
        else:
            print(json.dumps(results, indent=2))
            
        return 0
        
    except Exception as e:
        logger.error(f"Processing failed: {e}")
        error_result = {
            'project_id': args.project_id,
            'processing_status': 'failed',
            'error': str(e)
        }
        
        if args.output_path:
            with open(args.output_path, 'w') as f:
                json.dump(error_result, f, indent=2)
        else:
            print(json.dumps(error_result, indent=2))
            
        return 1


if __name__ == '__main__':
    sys.exit(main())