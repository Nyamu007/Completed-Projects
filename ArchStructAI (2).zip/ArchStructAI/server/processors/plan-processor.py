import sys
import json
import cv2
import numpy as np
import os
from pathlib import Path

def process_architectural_plan(file_path, building_code):
    """
    Process architectural plan using OpenCV for basic element detection
    This is a simplified version - production would use more sophisticated AI models
    """
    try:
        # Read the image
        if file_path.lower().endswith('.pdf'):
            # For PDF files, you'd need pdf2image or similar
            # For now, return mock data for PDFs
            return generate_mock_elements(building_code)
        
        # Read image file
        image = cv2.imread(file_path)
        if image is None:
            raise ValueError(f"Could not read image file: {file_path}")
        
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Apply edge detection
        edges = cv2.Canny(gray, 50, 150, apertureSize=3)
        
        # Find contours (potential structural elements)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Analyze contours to identify structural elements
        elements = analyze_contours(contours, building_code)
        
        return {
            "status": "success",
            "elements": elements,
            "image_dimensions": {
                "width": image.shape[1],
                "height": image.shape[0]
            }
        }
        
    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "elements": []
        }

def analyze_contours(contours, building_code):
    """
    Analyze contours to identify potential structural elements
    This is a simplified approach - production would use trained ML models
    """
    elements = []
    
    for i, contour in enumerate(contours):
        # Calculate contour properties
        area = cv2.contourArea(contour)
        perimeter = cv2.arcLength(contour, True)
        
        # Skip very small contours
        if area < 1000:
            continue
            
        # Approximate contour to polygon
        epsilon = 0.02 * perimeter
        approx = cv2.approxPolyDP(contour, epsilon, True)
        
        # Get bounding rectangle
        x, y, w, h = cv2.boundingRect(contour)
        aspect_ratio = float(w) / h
        
        # Classify based on shape characteristics
        element_type = classify_element(area, aspect_ratio, len(approx))
        
        if element_type:
            # Calculate dimensions (convert pixels to meters - this would need calibration)
            scale_factor = 0.01  # Assume 1 pixel = 1cm for now
            
            element = {
                "id": f"{element_type}_{i+1}",
                "type": element_type,
                "dimensions": {
                    "length": round(w * scale_factor, 2),
                    "width": round(h * scale_factor, 2),
                    "area": round(area * scale_factor * scale_factor, 2)
                },
                "materialGrade": get_material_grade(element_type, building_code),
                "reinforcement": get_reinforcement_details(element_type, w * scale_factor, h * scale_factor),
                "quantity": 1,
                "unit": "nos" if element_type in ["column", "beam"] else "m²"
            }
            elements.append(element)
    
    return elements

def classify_element(area, aspect_ratio, vertices):
    """
    Classify structural element based on geometric properties
    """
    if vertices == 4:  # Rectangular shapes
        if aspect_ratio > 3:  # Long and narrow
            return "beam"
        elif aspect_ratio < 0.33:  # Tall and narrow
            return "column"  
        elif 0.8 <= aspect_ratio <= 1.2:  # Square-ish
            return "column"
        else:  # Rectangular
            return "slab"
    elif vertices > 4:  # Irregular shapes
        if area > 10000:  # Large area
            return "slab"
    
    return None

def get_material_grade(element_type, building_code):
    """
    Get appropriate material grade based on element type and building code
    """
    if building_code == "Eurocode":
        grades = {"concrete": "C25/30", "steel": "S500"}
    elif building_code == "ACI":
        grades = {"concrete": "f'c=25MPa", "steel": "fy=420MPa"}
    elif building_code == "BS":
        grades = {"concrete": "C25", "steel": "Fe500"}
    else:  # IS Code
        grades = {"concrete": "M25", "steel": "Fe500"}
    
    if element_type in ["column", "beam", "slab"]:
        return grades["concrete"]
    else:
        return grades["steel"]

def get_reinforcement_details(element_type, length, width):
    """
    Generate reinforcement details based on element type and dimensions
    """
    if element_type == "beam":
        return {
            "main_bars": {"diameter": 16, "count": 4},
            "stirrups": {"diameter": 8, "spacing": 150},
            "length": length,
            "bendingDetails": {"top": 2, "bottom": 2}
        }
    elif element_type == "column":
        return {
            "main_bars": {"diameter": 20, "count": 8},
            "ties": {"diameter": 8, "spacing": 150},
            "length": 3.2,  # Assume standard floor height
            "bendingDetails": {"vertical": 8}
        }
    elif element_type == "slab":
        return {
            "main_bars": {"diameter": 12, "spacing": 150},
            "distribution_bars": {"diameter": 10, "spacing": 200},
            "area": length * width,
            "bendingDetails": {"both_ways": True}
        }
    
    return {}

def generate_mock_elements(building_code):
    """
    Generate mock structural elements for demonstration
    This would be replaced with actual AI/CV processing
    """
    return {
        "status": "success",
        "elements": [
            {
                "id": "column_1",
                "type": "column",
                "dimensions": {"length": 0.3, "width": 0.3, "height": 3.2},
                "materialGrade": get_material_grade("column", building_code),
                "reinforcement": get_reinforcement_details("column", 0.3, 0.3),
                "quantity": 1,
                "unit": "nos"
            },
            {
                "id": "beam_1", 
                "type": "beam",
                "dimensions": {"length": 4.8, "width": 0.3, "depth": 0.45},
                "materialGrade": get_material_grade("beam", building_code),
                "reinforcement": get_reinforcement_details("beam", 4.8, 0.3),
                "quantity": 1,
                "unit": "nos"
            },
            {
                "id": "slab_1",
                "type": "slab", 
                "dimensions": {"length": 4.8, "width": 3.6, "thickness": 0.15},
                "materialGrade": get_material_grade("slab", building_code),
                "reinforcement": get_reinforcement_details("slab", 4.8, 3.6),
                "quantity": 17.28,
                "unit": "m²"
            }
        ]
    }

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(json.dumps({"status": "error", "message": "Usage: python plan-processor.py <file_path> <building_code>"}))
        sys.exit(1)
    
    file_path = sys.argv[1]
    building_code = sys.argv[2]
    
    result = process_architectural_plan(file_path, building_code)
    print(json.dumps(result))
