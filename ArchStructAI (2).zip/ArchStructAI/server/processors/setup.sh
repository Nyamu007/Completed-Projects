#!/bin/bash

# Setup script for advanced floor plan detection
echo "Setting up advanced floor plan detection environment..."

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is required but not installed. Please install Python 3.11+"
    exit 1
fi

# Check if pip is available
if ! command -v pip3 &> /dev/null; then
    echo "pip3 is required but not installed. Please install pip3"
    exit 1
fi

# Install basic requirements
echo "Installing basic Python dependencies..."
pip3 install -r requirements.txt

echo "Basic setup completed successfully!"

# Optional: Setup for advanced Mask R-CNN detection
read -p "Do you want to set up advanced Mask R-CNN detection? (requires ~2GB download) [y/N]: " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Setting up advanced detection capabilities..."
    
    # Install TensorFlow
    pip3 install tensorflow>=2.10.0
    
    # Install additional dependencies for Mask R-CNN
    pip3 install scikit-image>=0.19.0
    pip3 install imgaug>=0.4.0
    
    # Clone Mask R-CNN repository if not exists
    if [ ! -d "Mask_RCNN" ]; then
        echo "Cloning Mask R-CNN repository..."
        git clone https://github.com/matterport/Mask_RCNN.git
        cd Mask_RCNN
        python3 setup.py install
        cd ..
    fi
    
    echo "Advanced setup completed!"
    echo "Note: You will need to provide trained model weights for architectural element detection."
    echo "The system will fallback to OpenCV-based detection if no trained models are available."
else
    echo "Skipping advanced setup. Using OpenCV-based detection only."
fi

echo "Setup complete! The floor detection system is ready to use."