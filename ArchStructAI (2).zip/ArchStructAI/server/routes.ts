import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProjectSchema, insertProjectFileSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";
import { processingService } from "./services/processing-service";

const upload = multer({ 
  dest: 'uploads/',
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.pdf', '.png', '.jpg', '.jpeg', '.dwg', '.dxf'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, images, DWG, and DXF files are allowed.'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all projects
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  // Get project by ID
  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  // Create new project
  app.post("/api/projects", async (req, res) => {
    try {
      const validatedData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(validatedData);
      res.status(201).json(project);
    } catch (error) {
      res.status(400).json({ message: "Invalid project data", error });
    }
  });

  // Upload files for project
  app.post("/api/projects/:projectId/upload", upload.array('files', 10), async (req, res) => {
    try {
      const projectId = req.params.projectId;
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) {
        return res.status(400).json({ message: "No files uploaded" });
      }

      const uploadedFiles = [];
      
      for (const file of files) {
        // Create uploads directory if it doesn't exist
        const uploadsDir = path.join(process.cwd(), 'uploads', projectId);
        if (!fs.existsSync(uploadsDir)) {
          fs.mkdirSync(uploadsDir, { recursive: true });
        }

        // Move file to project-specific directory
        const newPath = path.join(uploadsDir, file.originalname);
        fs.renameSync(file.path, newPath);

        const projectFile = await storage.createProjectFile({
          projectId,
          fileName: file.originalname,
          fileType: file.mimetype,
          filePath: newPath,
          fileSize: file.size,
        });

        uploadedFiles.push(projectFile);
      }

      // Update project status and start processing
      await storage.updateProject(projectId, { status: "processing" });
      
      // Start processing in background
      processingService.processProject(projectId).catch(console.error);

      res.json({ 
        message: "Files uploaded successfully", 
        files: uploadedFiles 
      });
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ message: "Failed to upload files" });
    }
  });

  // Get project files
  app.get("/api/projects/:projectId/files", async (req, res) => {
    try {
      const files = await storage.getProjectFiles(req.params.projectId);
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project files" });
    }
  });

  // Get structural elements
  app.get("/api/projects/:projectId/structural-elements", async (req, res) => {
    try {
      const elements = await storage.getStructuralElements(req.params.projectId);
      res.json(elements);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch structural elements" });
    }
  });

  // Get material schedule
  app.get("/api/projects/:projectId/material-schedule", async (req, res) => {
    try {
      const schedule = await storage.getMaterialSchedule(req.params.projectId);
      res.json(schedule);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch material schedule" });
    }
  });

  // Get bar bending schedule
  app.get("/api/projects/:projectId/bar-bending-schedule", async (req, res) => {
    try {
      const schedule = await storage.getBarBendingSchedule(req.params.projectId);
      res.json(schedule);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bar bending schedule" });
    }
  });

  // Get bill of quantities
  app.get("/api/projects/:projectId/bill-of-quantities", async (req, res) => {
    try {
      const boq = await storage.getBillOfQuantities(req.params.projectId);
      res.json(boq);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bill of quantities" });
    }
  });

  // Get processing logs
  app.get("/api/projects/:projectId/processing-logs", async (req, res) => {
    try {
      const logs = await storage.getProcessingLogs(req.params.projectId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch processing logs" });
    }
  });

  // Export project data
  app.get("/api/projects/:projectId/export/:type", async (req, res) => {
    try {
      const { projectId, type } = req.params;
      
      let data;
      let filename;
      
      switch (type) {
        case 'material-schedule':
          data = await storage.getMaterialSchedule(projectId);
          filename = `material-schedule-${projectId}.json`;
          break;
        case 'bar-bending-schedule':
          data = await storage.getBarBendingSchedule(projectId);
          filename = `bar-bending-schedule-${projectId}.json`;
          break;
        case 'bill-of-quantities':
          data = await storage.getBillOfQuantities(projectId);
          filename = `bill-of-quantities-${projectId}.json`;
          break;
        default:
          return res.status(400).json({ message: "Invalid export type" });
      }

      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to export data" });
    }
  });

  // Get 3D model data for a project
  app.get("/api/projects/:projectId/3d-model", async (req, res) => {
    try {
      const modelPath = path.join(process.cwd(), "uploads", `${req.params.projectId}_3d_model.json`);
      
      if (fs.existsSync(modelPath)) {
        const modelData = JSON.parse(fs.readFileSync(modelPath, 'utf8'));
        res.json(modelData);
      } else {
        res.status(404).json({ message: "3D model not found" });
      }
    } catch (error) {
      console.error("Error fetching 3D model:", error);
      res.status(500).json({ message: "Failed to fetch 3D model" });
    }
  });

  // Export 3D model in various formats
  app.post("/api/projects/:projectId/export/3d", async (req, res) => {
    try {
      const format = req.query.format as string || 'obj';
      const modelPath = path.join(process.cwd(), "uploads", `${req.params.projectId}_3d_model.json`);
      
      if (!fs.existsSync(modelPath)) {
        return res.status(404).json({ message: "3D model not found" });
      }

      const modelData = JSON.parse(fs.readFileSync(modelPath, 'utf8'));
      
      // Generate export based on format
      let exportData: string;
      let contentType: string;
      let fileName: string;

      switch (format.toLowerCase()) {
        case 'obj':
          exportData = generateOBJExport(modelData);
          contentType = 'text/plain';
          fileName = `${req.params.projectId}_model.obj`;
          break;
        case 'ifc':
          exportData = generateIFCExport(modelData);
          contentType = 'text/plain';
          fileName = `${req.params.projectId}_model.ifc`;
          break;
        default:
          exportData = JSON.stringify(modelData, null, 2);
          contentType = 'application/json';
          fileName = `${req.params.projectId}_model.json`;
      }

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.send(exportData);
      
    } catch (error) {
      console.error("Error exporting 3D model:", error);
      res.status(500).json({ message: "Failed to export 3D model" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper function to generate OBJ format export
function generateOBJExport(modelData: any): string {
  let objContent = "# Plan2Struct AI - 3D Model Export\n";
  objContent += "# Generated from floor plan analysis\n\n";
  
  let vertexIndex = 1;
  
  // Export walls
  if (modelData.geometry_data && modelData.geometry_data.walls) {
    objContent += "# Walls\n";
    modelData.geometry_data.walls.forEach((wall: any) => {
      if (wall.profile_points) {
        objContent += `o ${wall.id}\n`;
        
        // Add vertices
        wall.profile_points.forEach((point: any) => {
          objContent += `v ${point.x / 1000} ${point.y / 1000} ${point.z / 1000}\n`;
        });
        
        // Add top vertices
        wall.profile_points.forEach((point: any) => {
          objContent += `v ${point.x / 1000} ${point.y / 1000} ${(point.z + wall.height) / 1000}\n`;
        });
        
        vertexIndex += wall.profile_points.length * 2;
        objContent += "\n";
      }
    });
  }
  
  return objContent;
}

// Helper function to generate IFC format export
function generateIFCExport(modelData: any): string {
  let ifcContent = "ISO-10303-21;\n";
  ifcContent += "HEADER;\n";
  ifcContent += "FILE_DESCRIPTION(('Plan2Struct AI Generated Model'),'2;1');\n";
  ifcContent += "FILE_NAME('model.ifc','','','Plan2Struct AI','','','');\n";
  ifcContent += "FILE_SCHEMA(('IFC4'));\n";
  ifcContent += "ENDSEC;\n\n";
  ifcContent += "DATA;\n";
  ifcContent += "/* Basic IFC structure - simplified for demonstration */\n";
  ifcContent += "ENDSEC;\n";
  ifcContent += "END-ISO-10303-21;\n";
  
  return ifcContent;
}
