import { storage } from "../storage";
import { spawn } from "child_process";
import path from "path";
import fs from "fs";

class ProcessingService {
  async processProject(projectId: string): Promise<void> {
    try {
      // Log processing start
      await storage.createProcessingLog({
        projectId,
        stage: "analysis",
        status: "started",
        message: "Starting architectural plan analysis",
        progress: 0
      });

      const project = await storage.getProject(projectId);
      if (!project) {
        throw new Error("Project not found");
      }

      const files = await storage.getProjectFiles(projectId);
      if (files.length === 0) {
        throw new Error("No files found for processing");
      }

      // Process each file with Python script
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const progress = Math.round(((i + 1) / files.length) * 50); // First 50% for analysis

        await storage.createProcessingLog({
          projectId,
          stage: "analysis",
          status: "started",
          message: `Analyzing file: ${file.fileName}`,
          progress
        });

        await this.processFile(projectId, file.filePath, project.buildingCode);
      }

      // 3D Reconstruction phase
      await storage.createProcessingLog({
        projectId,
        stage: "reconstruction",
        status: "started",
        message: "Starting 3D model reconstruction",
        progress: 40
      });

      await this.perform3DReconstruction(projectId, files[0].filePath, project.numberOfFloors || 1);

      // Generate structural plans
      await storage.createProcessingLog({
        projectId,
        stage: "generation",
        status: "started",
        message: "Generating structural plans",
        progress: 60
      });

      await this.generateStructuralPlans(projectId, project.buildingType, project.numberOfFloors);

      // Generate schedules
      await storage.createProcessingLog({
        projectId,
        stage: "generation",
        status: "started",
        message: "Generating material schedules",
        progress: 80
      });

      await this.generateSchedules(projectId);

      // Complete processing
      await storage.updateProject(projectId, { status: "completed" });
      
      await storage.createProcessingLog({
        projectId,
        stage: "completion",
        status: "completed",
        message: "Project processing completed successfully",
        progress: 100
      });

    } catch (error) {
      console.error("Processing error:", error);
      
      await storage.updateProject(projectId, { status: "failed" });
      
      await storage.createProcessingLog({
        projectId,
        stage: "analysis",
        status: "failed",
        message: `Processing failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        progress: 0
      });
    }
  }

  private async processFile(projectId: string, filePath: string, buildingCode: string): Promise<void> {
    return new Promise((resolve, reject) => {
      // Determine which processor to use based on file extension
      const fileExt = path.extname(filePath).toLowerCase();
      let pythonScript: string;
      let args: string[];
      
      if (['.pdf', '.dwg', '.dxf'].includes(fileExt) || filePath.includes('floor') || filePath.includes('plan')) {
        // Use advanced floor detection for architectural files
        pythonScript = path.join(process.cwd(), "server", "processors", "floor-detection.py");
        args = ["--image_path", filePath, "--project_id", projectId];
      } else {
        // Use basic plan processor for simple images
        pythonScript = path.join(process.cwd(), "server", "processors", "plan-processor.py");
        args = [filePath, buildingCode];
      }

      const python = spawn("python3", [pythonScript, ...args]);

      let output = "";
      let error = "";

      python.stdout.on("data", (data) => {
        output += data.toString();
      });

      python.stderr.on("data", (data) => {
        error += data.toString();
      });

      python.on("close", (code) => {
        if (code === 0) {
          try {
            // Parse the output from Python script
            const result = JSON.parse(output);
            this.saveAdvancedAnalysisResults(projectId, result);
            resolve();
          } catch (parseError) {
            reject(new Error(`Failed to parse processing results: ${parseError}`));
          }
        } else {
          reject(new Error(`Python script failed with code ${code}: ${error}`));
        }
      });

      python.on("error", (err) => {
        reject(new Error(`Failed to start Python script: ${err.message}`));
      });
    });
  }

  private async saveDetectedElements(projectId: string, result: any): Promise<void> {
    // Save detected structural elements
    if (result.elements) {
      for (const element of result.elements) {
        await storage.createStructuralElement({
          projectId,
          elementType: element.type,
          elementId: element.id,
          dimensions: element.dimensions,
          materialGrade: element.materialGrade,
          reinforcement: element.reinforcement,
          quantity: element.quantity,
          unit: element.unit
        });
      }
    }
  }

  private async saveAdvancedAnalysisResults(projectId: string, result: any): Promise<void> {
    try {
      // Save structural elements from advanced detection
      if (result.structural_elements) {
        for (const element of result.structural_elements) {
          await storage.createStructuralElement({
            projectId: element.project_id,
            elementType: element.element_type,
            elementId: element.element_id,
            dimensions: element.dimensions,
            materialGrade: element.material_grade,
            reinforcement: element.reinforcement,
            quantity: element.quantity,
            unit: element.unit
          });
        }
      }

      // Save material schedule
      if (result.material_schedule) {
        for (const material of result.material_schedule) {
          await storage.createMaterialScheduleItem({
            projectId: material.project_id,
            itemCode: material.item_code,
            description: material.description,
            unit: material.unit,
            quantity: material.quantity,
            rate: material.rate,
            amount: material.amount,
            category: material.category
          });
        }
      }

      // Save bar bending schedule
      if (result.bar_bending_schedule) {
        for (const barItem of result.bar_bending_schedule) {
          await storage.createBarBendingScheduleItem({
            projectId: barItem.project_id,
            barMark: barItem.bar_mark,
            elementId: barItem.element_id,
            elementType: barItem.element_type,
            barDiameter: barItem.bar_diameter,
            barLength: barItem.bar_length,
            quantity: barItem.quantity,
            totalLength: barItem.total_length,
            weightPerMeter: barItem.weight_per_meter,
            totalWeight: barItem.total_weight,
            barShape: barItem.bar_shape,
            steelGrade: barItem.steel_grade
          });
        }
      }

      // Save bill of quantities
      if (result.bill_of_quantities) {
        for (const boqItem of result.bill_of_quantities) {
          await storage.createBillOfQuantitiesItem({
            projectId: boqItem.project_id,
            itemCode: boqItem.item_code,
            description: boqItem.description,
            unit: boqItem.unit,
            quantity: boqItem.quantity,
            rate: boqItem.rate,
            amount: boqItem.amount,
            category: boqItem.category
          });
        }
      }

      console.log(`Advanced analysis results saved for project ${projectId}`);
      
    } catch (error) {
      console.error('Error saving advanced analysis results:', error);
      throw error;
    }
  }

  private async perform3DReconstruction(projectId: string, filePath: string, numberOfFloors: number): Promise<void> {
    return new Promise((resolve, reject) => {
      // First create detection results file for 3D reconstruction
      const detectionFile = path.join(process.cwd(), "uploads", `${projectId}_detections.json`);
      const outputPath = path.join(process.cwd(), "uploads", `${projectId}_3d_model.json`);
      
      // Run 3D reconstruction script
      const reconstructionScript = path.join(process.cwd(), "server", "processors", "3d-reconstruction.py");
      const python = spawn("python3", [
        reconstructionScript,
        "--detection_file", detectionFile,
        "--project_id", projectId,
        "--num_floors", numberOfFloors.toString(),
        "--output_path", outputPath
      ]);

      let output = "";
      let error = "";

      python.stdout.on("data", (data) => {
        output += data.toString();
      });

      python.stderr.on("data", (data) => {
        error += data.toString();
      });

      python.on("close", (code) => {
        if (code === 0) {
          try {
            // Store 3D model data
            if (fs.existsSync(outputPath)) {
              const modelData = JSON.parse(fs.readFileSync(outputPath, 'utf8'));
              this.store3DModelData(projectId, modelData);
            }
            resolve();
          } catch (parseError) {
            reject(new Error(`Failed to parse 3D reconstruction results: ${parseError}`));
          }
        } else {
          reject(new Error(`3D reconstruction failed with code ${code}: ${error}`));
        }
      });

      python.on("error", (err) => {
        reject(new Error(`Failed to start 3D reconstruction: ${err.message}`));
      });
    });
  }

  private async store3DModelData(projectId: string, modelData: any): Promise<void> {
    // For now, we'll store the 3D model data in a simple way
    // In a real application, this would go to a proper 3D model database
    const modelPath = path.join(process.cwd(), "uploads", `${projectId}_3d_model.json`);
    fs.writeFileSync(modelPath, JSON.stringify(modelData, null, 2));
    console.log(`3D model data stored for project ${projectId}`);
  }

  private async generateStructuralPlans(projectId: string, buildingType: string, numberOfFloors: number): Promise<void> {
    // This would integrate with CAD libraries or structural design software
    // For now, we'll simulate the process
    
    const elements = await storage.getStructuralElements(projectId);
    
    // Generate basic structural plan data based on detected elements
    // This is where you'd integrate with actual structural design algorithms
    
    console.log(`Generated structural plans for ${buildingType} with ${numberOfFloors} floors`);
    console.log(`Found ${elements.length} structural elements`);
  }

  private async generateSchedules(projectId: string): Promise<void> {
    const elements = await storage.getStructuralElements(projectId);
    
    // Generate material schedule
    const materialMap = new Map<string, { quantity: number; unit: string; rate: number }>();
    
    elements.forEach(element => {
      const key = `${element.materialGrade}-${element.unit}`;
      const existing = materialMap.get(key) || { quantity: 0, unit: element.unit, rate: 0 };
      existing.quantity += parseFloat(element.quantity || "0");
      
      // Set standard rates based on material type
      if (element.materialGrade?.includes("M25")) {
        existing.rate = 4500; // Rate for M25 concrete
      } else if (element.materialGrade?.includes("Fe500")) {
        existing.rate = 65; // Rate for Fe500 steel
      }
      
      materialMap.set(key, existing);
    });

    let itemOrder = 1;
    for (const [material, data] of materialMap) {
      const [grade, unit] = material.split("-");
      const amount = data.quantity * data.rate;
      
      await storage.createMaterialScheduleItem({
        projectId,
        itemCode: `MAT-${itemOrder.toString().padStart(3, "0")}`,
        description: grade,
        unit: data.unit,
        quantity: data.quantity.toString(),
        rate: data.rate.toString(),
        amount: amount.toString(),
        category: grade.includes("M") ? "concrete" : "steel"
      });

      // Generate BoQ items
      await storage.createBillOfQuantitiesItem({
        projectId,
        category: grade.includes("M") ? "CONCRETE WORK" : "STEEL WORK",
        description: grade,
        unit: data.unit,
        quantity: data.quantity.toString(),
        rate: data.rate.toString(),
        amount: amount.toString(),
        itemOrder
      });

      itemOrder++;
    }

    // Generate bar bending schedule for steel elements
    const steelElements = elements.filter(e => e.elementType === "beam" || e.elementType === "column");
    
    steelElements.forEach(async (element, index) => {
      if (element.reinforcement) {
        const reinforcement = element.reinforcement as any;
        await storage.createBarBendingScheduleItem({
          projectId,
          elementType: element.elementType,
          markNumber: `${element.elementType.charAt(0).toUpperCase()}${index + 1}`,
          barDiameter: reinforcement.diameter || 16,
          barLength: reinforcement.length || 4.8,
          numberOfBars: reinforcement.count || 4,
          totalWeight: ((reinforcement.diameter || 16) ** 2 * (reinforcement.length || 4.8) * (reinforcement.count || 4) * 0.00617).toString(),
          bendingDetails: reinforcement.bendingDetails || {}
        });
      }
    });
  }
}

export const processingService = new ProcessingService();
