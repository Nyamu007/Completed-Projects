import { 
  type Project, 
  type InsertProject,
  type ProjectFile,
  type InsertProjectFile,
  type StructuralElement,
  type InsertStructuralElement,
  type MaterialSchedule,
  type InsertMaterialSchedule,
  type BarBendingSchedule,
  type InsertBarBendingSchedule,
  type BillOfQuantities,
  type InsertBillOfQuantities,
  type ProcessingLog,
  type InsertProcessingLog
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Projects
  getProject(id: string): Promise<Project | undefined>;
  getProjects(): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, updates: Partial<Project>): Promise<Project | undefined>;
  
  // Project Files
  getProjectFiles(projectId: string): Promise<ProjectFile[]>;
  createProjectFile(projectFile: InsertProjectFile): Promise<ProjectFile>;
  
  // Structural Elements
  getStructuralElements(projectId: string): Promise<StructuralElement[]>;
  createStructuralElement(element: InsertStructuralElement): Promise<StructuralElement>;
  
  // Material Schedule
  getMaterialSchedule(projectId: string): Promise<MaterialSchedule[]>;
  createMaterialScheduleItem(item: InsertMaterialSchedule): Promise<MaterialSchedule>;
  
  // Bar Bending Schedule
  getBarBendingSchedule(projectId: string): Promise<BarBendingSchedule[]>;
  createBarBendingScheduleItem(item: InsertBarBendingSchedule): Promise<BarBendingSchedule>;
  
  // Bill of Quantities
  getBillOfQuantities(projectId: string): Promise<BillOfQuantities[]>;
  createBillOfQuantitiesItem(item: InsertBillOfQuantities): Promise<BillOfQuantities>;
  
  // Processing Logs
  getProcessingLogs(projectId: string): Promise<ProcessingLog[]>;
  createProcessingLog(log: InsertProcessingLog): Promise<ProcessingLog>;
}

export class MemStorage implements IStorage {
  private projects: Map<string, Project>;
  private projectFiles: Map<string, ProjectFile>;
  private structuralElements: Map<string, StructuralElement>;
  private materialSchedule: Map<string, MaterialSchedule>;
  private barBendingSchedule: Map<string, BarBendingSchedule>;
  private billOfQuantities: Map<string, BillOfQuantities>;
  private processingLogs: Map<string, ProcessingLog>;

  constructor() {
    this.projects = new Map();
    this.projectFiles = new Map();
    this.structuralElements = new Map();
    this.materialSchedule = new Map();
    this.barBendingSchedule = new Map();
    this.billOfQuantities = new Map();
    this.processingLogs = new Map();
  }

  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values()).sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = randomUUID();
    const now = new Date();
    const project: Project = { 
      id, 
      name: insertProject.name,
      buildingCode: insertProject.buildingCode || "Eurocode",
      buildingType: insertProject.buildingType || "Residential", 
      numberOfFloors: insertProject.numberOfFloors || 1,
      status: "uploaded",
      createdAt: now,
      updatedAt: now
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: string, updates: Partial<Project>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    
    const updatedProject = { 
      ...project, 
      ...updates, 
      updatedAt: new Date() 
    };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async getProjectFiles(projectId: string): Promise<ProjectFile[]> {
    return Array.from(this.projectFiles.values()).filter(
      file => file.projectId === projectId
    );
  }

  async createProjectFile(insertProjectFile: InsertProjectFile): Promise<ProjectFile> {
    const id = randomUUID();
    const projectFile: ProjectFile = { 
      ...insertProjectFile, 
      id, 
      uploadedAt: new Date() 
    };
    this.projectFiles.set(id, projectFile);
    return projectFile;
  }

  async getStructuralElements(projectId: string): Promise<StructuralElement[]> {
    return Array.from(this.structuralElements.values()).filter(
      element => element.projectId === projectId
    );
  }

  async createStructuralElement(insertElement: InsertStructuralElement): Promise<StructuralElement> {
    const id = randomUUID();
    const element: StructuralElement = { 
      id,
      projectId: insertElement.projectId,
      elementType: insertElement.elementType,
      elementId: insertElement.elementId,
      dimensions: insertElement.dimensions || {},
      materialGrade: insertElement.materialGrade || null,
      reinforcement: insertElement.reinforcement || {},
      quantity: insertElement.quantity || null,
      unit: insertElement.unit
    };
    this.structuralElements.set(id, element);
    return element;
  }

  async getMaterialSchedule(projectId: string): Promise<MaterialSchedule[]> {
    return Array.from(this.materialSchedule.values()).filter(
      item => item.projectId === projectId
    );
  }

  async createMaterialScheduleItem(insertItem: InsertMaterialSchedule): Promise<MaterialSchedule> {
    const id = randomUUID();
    const item: MaterialSchedule = { 
      id,
      projectId: insertItem.projectId,
      itemCode: insertItem.itemCode,
      description: insertItem.description,
      unit: insertItem.unit,
      quantity: insertItem.quantity,
      rate: insertItem.rate || null,
      amount: insertItem.amount || null,
      category: insertItem.category
    };
    this.materialSchedule.set(id, item);
    return item;
  }

  async getBarBendingSchedule(projectId: string): Promise<BarBendingSchedule[]> {
    return Array.from(this.barBendingSchedule.values()).filter(
      item => item.projectId === projectId
    );
  }

  async createBarBendingScheduleItem(insertItem: InsertBarBendingSchedule): Promise<BarBendingSchedule> {
    const id = randomUUID();
    const item: BarBendingSchedule = { ...insertItem, id };
    this.barBendingSchedule.set(id, item);
    return item;
  }

  async getBillOfQuantities(projectId: string): Promise<BillOfQuantities[]> {
    return Array.from(this.billOfQuantities.values()).filter(
      item => item.projectId === projectId
    ).sort((a, b) => (a.itemOrder || 0) - (b.itemOrder || 0));
  }

  async createBillOfQuantitiesItem(insertItem: InsertBillOfQuantities): Promise<BillOfQuantities> {
    const id = randomUUID();
    const item: BillOfQuantities = { ...insertItem, id };
    this.billOfQuantities.set(id, item);
    return item;
  }

  async getProcessingLogs(projectId: string): Promise<ProcessingLog[]> {
    return Array.from(this.processingLogs.values()).filter(
      log => log.projectId === projectId
    ).sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }

  async createProcessingLog(insertLog: InsertProcessingLog): Promise<ProcessingLog> {
    const id = randomUUID();
    const log: ProcessingLog = { 
      ...insertLog, 
      id, 
      createdAt: new Date() 
    };
    this.processingLogs.set(id, log);
    return log;
  }
}

export const storage = new MemStorage();
