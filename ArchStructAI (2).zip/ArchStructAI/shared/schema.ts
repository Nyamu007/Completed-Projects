import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  buildingCode: text("building_code").notNull().default("Eurocode"),
  buildingType: text("building_type").notNull().default("Residential"),
  numberOfFloors: integer("number_of_floors").notNull().default(1),
  status: text("status").notNull().default("uploaded"), // uploaded, processing, completed, failed
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const projectFiles = pgTable("project_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  fileName: text("file_name").notNull(),
  fileType: text("file_type").notNull(),
  filePath: text("file_path").notNull(),
  fileSize: integer("file_size").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

export const structuralElements = pgTable("structural_elements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  elementType: text("element_type").notNull(), // column, beam, slab, foundation
  elementId: text("element_id").notNull(),
  dimensions: jsonb("dimensions"), // { length, width, height, diameter }
  materialGrade: text("material_grade"),
  reinforcement: jsonb("reinforcement"), // bar details
  quantity: decimal("quantity", { precision: 10, scale: 3 }),
  unit: text("unit").notNull(),
});

export const materialSchedule = pgTable("material_schedule", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  itemCode: text("item_code").notNull(),
  description: text("description").notNull(),
  unit: text("unit").notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 3 }).notNull(),
  rate: decimal("rate", { precision: 10, scale: 2 }),
  amount: decimal("amount", { precision: 12, scale: 2 }),
  category: text("category").notNull(), // concrete, steel, formwork
});

export const barBendingSchedule = pgTable("bar_bending_schedule", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  elementType: text("element_type").notNull(),
  markNumber: text("mark_number").notNull(),
  barDiameter: integer("bar_diameter").notNull(),
  barLength: decimal("bar_length", { precision: 8, scale: 3 }).notNull(),
  numberOfBars: integer("number_of_bars").notNull(),
  totalWeight: decimal("total_weight", { precision: 10, scale: 3 }).notNull(),
  bendingDetails: jsonb("bending_details"),
});

export const billOfQuantities = pgTable("bill_of_quantities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  category: text("category").notNull(),
  description: text("description").notNull(),
  unit: text("unit").notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 3 }).notNull(),
  rate: decimal("rate", { precision: 10, scale: 2 }).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  itemOrder: integer("item_order").default(0),
});

export const processingLogs = pgTable("processing_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  stage: text("stage").notNull(), // upload, analysis, generation, completion
  status: text("status").notNull(), // started, completed, failed
  message: text("message"),
  progress: integer("progress").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertProjectSchema = createInsertSchema(projects).pick({
  name: true,
  buildingCode: true,
  buildingType: true,
  numberOfFloors: true,
}).extend({
  buildingCode: z.string().default("Eurocode"),
  buildingType: z.string().default("Residential"),
  numberOfFloors: z.number().min(1).default(1),
});

export const insertProjectFileSchema = createInsertSchema(projectFiles).pick({
  projectId: true,
  fileName: true,
  fileType: true,
  filePath: true,
  fileSize: true,
});

export const insertStructuralElementSchema = createInsertSchema(structuralElements).pick({
  projectId: true,
  elementType: true,
  elementId: true,
  dimensions: true,
  materialGrade: true,
  reinforcement: true,
  quantity: true,
  unit: true,
});

export const insertMaterialScheduleSchema = createInsertSchema(materialSchedule).pick({
  projectId: true,
  itemCode: true,
  description: true,
  unit: true,
  quantity: true,
  rate: true,
  amount: true,
  category: true,
});

export const insertBarBendingScheduleSchema = createInsertSchema(barBendingSchedule).pick({
  projectId: true,
  elementType: true,
  markNumber: true,
  barDiameter: true,
  barLength: true,
  numberOfBars: true,
  totalWeight: true,
  bendingDetails: true,
});

export const insertBillOfQuantitiesSchema = createInsertSchema(billOfQuantities).pick({
  projectId: true,
  category: true,
  description: true,
  unit: true,
  quantity: true,
  rate: true,
  amount: true,
  itemOrder: true,
});

export const insertProcessingLogSchema = createInsertSchema(processingLogs).pick({
  projectId: true,
  stage: true,
  status: true,
  message: true,
  progress: true,
});

// Types
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export type InsertProjectFile = z.infer<typeof insertProjectFileSchema>;
export type ProjectFile = typeof projectFiles.$inferSelect;

export type InsertStructuralElement = z.infer<typeof insertStructuralElementSchema>;
export type StructuralElement = typeof structuralElements.$inferSelect;

export type InsertMaterialSchedule = z.infer<typeof insertMaterialScheduleSchema>;
export type MaterialSchedule = typeof materialSchedule.$inferSelect;

export type InsertBarBendingSchedule = z.infer<typeof insertBarBendingScheduleSchema>;
export type BarBendingSchedule = typeof barBendingSchedule.$inferSelect;

export type InsertBillOfQuantities = z.infer<typeof insertBillOfQuantitiesSchema>;
export type BillOfQuantities = typeof billOfQuantities.$inferSelect;

export type InsertProcessingLog = z.infer<typeof insertProcessingLogSchema>;
export type ProcessingLog = typeof processingLogs.$inferSelect;
