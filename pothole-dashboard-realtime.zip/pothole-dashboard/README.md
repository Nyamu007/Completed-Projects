# Pothole Detection Dashboard

A comprehensive web application that integrates YOLOv12 pothole detection with interactive map visualization, clustering analysis, and hotspot identification.

## Features

### 🗺️ Interactive Map Visualization
- Real-time pothole markers with severity-based color coding
- Leaflet.js powered interactive maps
- Clickable markers with detailed pothole information
- Responsive design for desktop and mobile

### 📊 Advanced Analytics
- **Clustering Analysis**: DBSCAN and K-Means algorithms for grouping potholes
- **Hotspot Detection**: Grid-based density analysis to identify problem areas
- **Statistical Reports**: Comprehensive analysis with confidence metrics
- **Filtering**: Date range and severity level filtering

### 🎯 Detection Integration
- YOLOv12 model integration for real-time pothole detection
- CSV data import/export functionality
- Coordinate-based data storage with severity metrics
- Confidence scoring for detection quality

### 🔧 Technical Stack
- **Backend**: Flask with SQLite database
- **Frontend**: HTML5, CSS3, JavaScript with Leaflet.js
- **ML**: YOLOv12, scikit-learn for clustering
- **Data**: Pandas for analysis, CSV import/export
- **Reports**: Downloadable CSV and XLSX analysis reports

## Installation & Setup

### Prerequisites
- Python 3.11+
- pip package manager
- YOLOv12 model file (.pt format)

### 1. Environment Setup
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Required Dependencies
The application requires these Python packages:
```
flask
flask-cors
flask-sqlalchemy
ultralytics
opencv-python
pillow
numpy
pandas
scikit-learn
openpyxl
requests
```

### 3. Project Structure
```
pothole-dashboard/
├── src/
│   ├── main.py                 # Flask application entry point
│   ├── models/
│   │   ├── pothole.py         # Pothole data model
│   │   └── user.py            # Database configuration
│   ├── routes/
│   │   ├── pothole.py         # Pothole API endpoints
│   │   └── clustering.py      # Clustering and analysis APIs
│   ├── detection/
│   │   └── enhanced_detector.py # YOLOv12 integration
│   └── static/
│       ├── index.html         # Dashboard interface
│       └── dashboard.js       # Frontend JavaScript
├── venv/                      # Virtual environment
├── requirements.txt           # Python dependencies
└── README.md                  # This file
```

## Usage Guide

### 1. Starting the Application
```bash
# Navigate to project directory
cd pothole-dashboard

# Activate virtual environment
source venv/bin/activate  # or venv\Scripts\activate on Windows

# Start the Flask server
python src/main.py
```

The application will be available at `http://localhost:5000`

### 2. Data Import
To import your existing pothole data:

#### CSV Format
Your CSV file should contain these columns:
- `latitude`: GPS latitude coordinate
- `longitude`: GPS longitude coordinate  
- `severity`: Numeric severity score
- `confidence`: Detection confidence (0.0-1.0)
- `timestamp`: Detection timestamp
- `width`: Bounding box width
- `height`: Bounding box height

#### Import Methods
1. **API Endpoint**: POST to `/api/potholes/import-csv`
2. **Manual Upload**: Place CSV in project directory and use import function

### 3. YOLOv12 Integration

#### Model Setup
1. Place your YOLOv12 model file (`.pt`) in the project directory
2. Update the model path in `src/detection/enhanced_detector.py`
3. Ensure the model is trained for pothole detection

#### Detection Workflow
1. **Real-time Detection**: Use webcam input for live detection
2. **Batch Processing**: Process images from directory
3. **API Integration**: Send images via POST requests

### 4. Dashboard Features

#### Map Controls
- **Zoom**: Use mouse wheel or +/- buttons
- **Pan**: Click and drag to move around
- **Markers**: Click on pothole markers for details

#### Filtering Options
- **Severity Level**: Filter by Low (<5000), Medium (5000-15000), High (>15000)
- **Date Range**: Select start and end dates
- **Apply/Clear**: Use buttons to apply or reset filters

#### Advanced Features
- **Enable Clustering**: Groups nearby potholes using machine learning
- **Show Hotspots**: Displays grid-based density analysis
- **Analysis Report**: Comprehensive statistical analysis with download options
  - **Download CSV**: Export analysis report as CSV file
  - **Download XLSX**: Export analysis report as Excel file with multiple sheets
- **Clear All Data**: Reset database (use with caution)

### 5. Report Downloads

The dashboard provides comprehensive analysis reports that can be downloaded in two formats:

#### CSV Format
- Single file with summary statistics at the top
- Detailed pothole data below
- Includes calculated fields like severity categories and risk levels
- Compatible with Excel, Google Sheets, and data analysis tools

#### XLSX Format (Excel)
- **Pothole Data Sheet**: Complete dataset with all fields
- **Summary Statistics Sheet**: Key metrics and statistics
- **Severity Distribution Sheet**: Breakdown by severity categories
- **Geographic Analysis Sheet**: Spatial analysis and coverage metrics

#### Report Contents
Both formats include:
- **Overview Statistics**: Total count, averages, ranges
- **Severity Analysis**: Distribution across Low/Medium/High categories
- **Geographic Coverage**: Center points, coverage area, boundaries
- **Detection Quality**: Confidence metrics and ranges
- **Risk Assessment**: Combined severity and confidence scoring
- **Temporal Analysis**: Date ranges and detection patterns

### 5. API Endpoints

#### Pothole Management
- `GET /api/potholes` - Retrieve all potholes
- `POST /api/potholes` - Add new pothole
- `GET /api/potholes/stats` - Get statistics
- `POST /api/potholes/import-csv` - Import CSV data
- `DELETE /api/potholes/clear` - Clear all data

#### Clustering & Analysis
- `GET /api/potholes/clusters` - Get clustered data
- `GET /api/potholes/cluster-analysis` - Detailed analysis
- `GET /api/potholes/hotspots` - Hotspot detection

#### Detection
- `POST /api/potholes/detect` - Process image for potholes

## Configuration

### Database Configuration
The application uses SQLite by default. To change database:
1. Update `SQLALCHEMY_DATABASE_URI` in `src/main.py`
2. Install appropriate database drivers

### Model Configuration
Update detection parameters in `src/detection/enhanced_detector.py`:
- Model path
- Confidence threshold
- NMS threshold
- Input image size

### Map Configuration
Customize map settings in `src/static/dashboard.js`:
- Default center coordinates
- Zoom levels
- Tile layer provider
- Clustering parameters

## Deployment

### Local Development
```bash
python src/main.py
```

### Production Deployment
1. Use a production WSGI server (e.g., Gunicorn)
2. Configure environment variables
3. Set up reverse proxy (e.g., Nginx)
4. Enable HTTPS

Example with Gunicorn:
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
```

## Troubleshooting

### Common Issues

#### 1. Model Loading Errors
- Ensure YOLOv12 model file exists and path is correct
- Check model compatibility with ultralytics version
- Verify model was trained for pothole detection

#### 2. Database Errors
- Check file permissions for SQLite database
- Ensure database directory exists
- Verify SQLAlchemy configuration

#### 3. Import Errors
- Validate CSV format and column names
- Check for missing or invalid coordinate data
- Ensure timestamp format is correct

#### 4. Map Display Issues
- Check internet connection for tile loading
- Verify Leaflet.js CDN availability
- Check browser console for JavaScript errors

### Performance Optimization

#### Large Datasets
- Implement pagination for large datasets
- Use database indexing for coordinates
- Consider data aggregation for visualization

#### Memory Usage
- Monitor memory usage during clustering
- Implement batch processing for large datasets
- Use appropriate clustering parameters

## Development

### Adding New Features
1. Create new route in appropriate blueprint
2. Add corresponding frontend functionality
3. Update API documentation
4. Add tests for new features

### Database Migrations
When modifying models:
1. Update model definitions
2. Create migration scripts if needed
3. Test with sample data

### Frontend Customization
- Modify `src/static/index.html` for layout changes
- Update `src/static/dashboard.js` for functionality
- Add custom CSS for styling

## Security Considerations

### Data Protection
- Implement authentication for production use
- Validate all input data
- Use HTTPS in production
- Secure database access

### API Security
- Implement rate limiting
- Add input validation
- Use CORS appropriately
- Monitor for suspicious activity

## Support

### Documentation
- API documentation available at `/api/docs` (if enabled)
- Code comments throughout the application
- Example data provided for testing

### Monitoring
- Check Flask logs for errors
- Monitor database performance
- Track API response times
- Monitor memory usage during clustering

## License

This project is proprietary software. All rights reserved.

## Version History

### v1.0.0
- Initial release with basic pothole detection
- Map visualization with Leaflet.js
- CSV import/export functionality
- Basic filtering and statistics

### v2.0.0 (Current)
- Advanced clustering algorithms (DBSCAN, K-Means)
- Hotspot detection and analysis
- Comprehensive statistical reporting
- Enhanced UI with modern design
- Real-time detection integration
- Improved performance and scalability

