from flask import Flask, render_template, request, Response, jsonify, send_file, url_for, redirect
from werkzeug.utils import secure_filename
import cv2
import numpy as np
import os
import time
import json
from datetime import datetime
import torch
import subprocess
from detect import run_detection, PotholeDetector

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['OUTPUT_FOLDER'] = 'runs/detect'

# Create required directories
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)
os.makedirs('logs', exist_ok=True)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'mp4'}
detector = None

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

class VideoCamera:
    def __init__(self):
        self.video = cv2.VideoCapture(0)
        if not self.video.isOpened():
            raise ValueError("Could not open webcam")
        
        self.video.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.video.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        self.video.set(cv2.CAP_PROP_FPS, 30)
        self.detector = PotholeDetector()
        
        # Create named window
        cv2.namedWindow('Pothole Detection', cv2.WINDOW_NORMAL)

    def __del__(self):
        if self.video.isOpened():
            self.video.release()
        cv2.destroyAllWindows()

    def get_frame(self):
        success, frame = self.video.read()
        if not success:
            return None

        # Process frame with detector
        processed_frame = self.detector.process_frame(frame)
        
        # Display frame in window
        cv2.imshow('Pothole Detection', processed_frame)
        cv2.waitKey(1)
        
        # Convert to JPEG for web stream
        _, jpeg = cv2.imencode('.jpg', processed_frame)
        return jpeg.tobytes()

video_camera = None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload')
def upload():
    return render_template('upload.html')

@app.route('/opencam', methods=['GET'])
def opencam():
    try:
        run_detection(source=0)
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/return-files', methods=['GET'])
def return_file():
    obj = request.args.get('obj')
    loc = os.path.join("runs/detect", obj)
    try:
        return send_file(loc, attachment_filename=obj)
    except Exception as e:
        return str(e)

@app.route('/video_feed')
def video_feed():
    def gen(camera):
        while True:
            frame = camera.get_frame()
            if frame is not None:
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')
            time.sleep(0.033)

    if not video_camera:
        return "Camera not initialized", 500

    return Response(
        gen(video_camera),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )

@app.route('/start_webcam')
def start_webcam():
    global video_camera
    if not video_camera:
        try:
            video_camera = VideoCamera()
            return jsonify({'status': 'success'})
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    return jsonify({'status': 'already running'})

@app.route('/stop_webcam')
def stop_webcam():
    global video_camera
    if video_camera:
        video_camera.__del__()
        video_camera = None
    return jsonify({'status': 'success'})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)