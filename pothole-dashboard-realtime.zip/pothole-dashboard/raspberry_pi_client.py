#!/usr/bin/env python3
"""
Raspberry Pi Pothole Detection Client
=====================================

This script demonstrates how to send pothole detection data from a Raspberry Pi
to the real-time dashboard. It can be integrated with YOLOv12 detection code.

Requirements:
- requests library: pip install requests
- GPS module (optional, for real coordinates)
- Camera module for YOLOv12 detection

Usage:
    python raspberry_pi_client.py --server-url http://your-dashboard-url:5000
"""

import requests
import json
import time
import random
import argparse
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class PotholeDetectionClient:
    def __init__(self, server_url, device_id=None):
        """
        Initialize the pothole detection client
        
        Args:
            server_url (str): URL of the dashboard server
            device_id (str): Unique identifier for this Raspberry Pi device
        """
        self.server_url = server_url.rstrip('/')
        self.device_id = device_id or f"rpi_{int(time.time())}"
        self.session = requests.Session()
        
        # Test connection
        self.test_connection()
    
    def test_connection(self):
        """Test connection to the dashboard server"""
        try:
            response = self.session.get(f"{self.server_url}/api/realtime/status", timeout=5)
            if response.status_code == 200:
                logger.info(f"✅ Connected to dashboard server: {self.server_url}")
                status_data = response.json()
                logger.info(f"Server status: {status_data}")
            else:
                logger.warning(f"⚠️ Server responded with status {response.status_code}")
        except requests.exceptions.RequestException as e:
            logger.error(f"❌ Failed to connect to server: {e}")
            raise
    
    def send_detection(self, latitude, longitude, severity, confidence, width, height, image_path=None):
        """
        Send a single pothole detection to the dashboard
        
        Args:
            latitude (float): GPS latitude coordinate
            longitude (float): GPS longitude coordinate  
            severity (float): Pothole severity score
            confidence (float): Detection confidence (0.0 to 1.0)
            width (float): Bounding box width in pixels
            height (float): Bounding box height in pixels
            image_path (str, optional): Path to the detection image
        
        Returns:
            dict: Server response
        """
        detection_data = {
            'device_id': self.device_id,
            'timestamp': datetime.now().isoformat(),
            'latitude': latitude,
            'longitude': longitude,
            'severity': severity,
            'confidence': confidence,
            'width': width,
            'height': height
        }
        
        if image_path:
            detection_data['image_path'] = image_path
        
        try:
            response = self.session.post(
                f"{self.server_url}/api/realtime/raspberry-pi/detect",
                json=detection_data,
                timeout=10
            )
            
            if response.status_code == 201:
                result = response.json()
                logger.info(f"✅ Detection sent successfully: ID {result.get('pothole_id')}")
                logger.info(f"📡 Notified {result.get('clients_notified', 0)} connected clients")
                return result
            else:
                logger.error(f"❌ Failed to send detection: {response.status_code} - {response.text}")
                return None
                
        except requests.exceptions.RequestException as e:
            logger.error(f"❌ Network error sending detection: {e}")
            return None
    
    def send_batch_detections(self, detections):
        """
        Send multiple pothole detections in a batch
        
        Args:
            detections (list): List of detection dictionaries
        
        Returns:
            dict: Server response
        """
        batch_data = {
            'device_id': self.device_id,
            'detections': detections
        }
        
        try:
            response = self.session.post(
                f"{self.server_url}/api/realtime/raspberry-pi/batch",
                json=batch_data,
                timeout=30
            )
            
            if response.status_code == 201:
                result = response.json()
                logger.info(f"✅ Batch sent successfully: {result.get('processed_count')} detections")
                logger.info(f"📡 Notified {result.get('clients_notified', 0)} connected clients")
                return result
            else:
                logger.error(f"❌ Failed to send batch: {response.status_code} - {response.text}")
                return None
                
        except requests.exceptions.RequestException as e:
            logger.error(f"❌ Network error sending batch: {e}")
            return None

class MockGPSModule:
    """Mock GPS module for testing purposes"""
    
    def __init__(self, center_lat=40.7128, center_lng=-74.0060, radius=0.01):
        self.center_lat = center_lat
        self.center_lng = center_lng
        self.radius = radius
    
    def get_coordinates(self):
        """Generate random coordinates around the center point"""
        lat_offset = (random.random() - 0.5) * 2 * self.radius
        lng_offset = (random.random() - 0.5) * 2 * self.radius
        
        return (
            self.center_lat + lat_offset,
            self.center_lng + lng_offset
        )

class MockYOLODetector:
    """Mock YOLO detector for testing purposes"""
    
    def detect_potholes(self, image_frame=None):
        """
        Simulate pothole detection
        
        Returns:
            list: List of detection results
        """
        # Simulate random number of detections (0-3)
        num_detections = random.randint(0, 3)
        detections = []
        
        for _ in range(num_detections):
            detection = {
                'severity': random.uniform(1000, 50000),
                'confidence': random.uniform(0.3, 0.95),
                'width': random.uniform(50, 400),
                'height': random.uniform(30, 200),
                'bbox': {
                    'x': random.randint(0, 640),
                    'y': random.randint(0, 480),
                    'w': random.randint(50, 200),
                    'h': random.randint(30, 150)
                }
            }
            detections.append(detection)
        
        return detections

def simulate_real_time_detection(client, duration_minutes=5):
    """
    Simulate real-time pothole detection for testing
    
    Args:
        client (PotholeDetectionClient): The client instance
        duration_minutes (int): How long to run the simulation
    """
    logger.info(f"🚀 Starting {duration_minutes}-minute simulation...")
    
    gps = MockGPSModule()
    detector = MockYOLODetector()
    
    start_time = time.time()
    end_time = start_time + (duration_minutes * 60)
    detection_count = 0
    
    try:
        while time.time() < end_time:
            # Get current location
            latitude, longitude = gps.get_coordinates()
            
            # Detect potholes
            detections = detector.detect_potholes()
            
            # Send each detection
            for detection in detections:
                success = client.send_detection(
                    latitude=latitude,
                    longitude=longitude,
                    severity=detection['severity'],
                    confidence=detection['confidence'],
                    width=detection['width'],
                    height=detection['height']
                )
                
                if success:
                    detection_count += 1
                    logger.info(f"📍 Detection #{detection_count} sent from ({latitude:.6f}, {longitude:.6f})")
            
            # Wait before next detection cycle
            time.sleep(random.uniform(2, 8))  # Random interval between 2-8 seconds
            
    except KeyboardInterrupt:
        logger.info("🛑 Simulation stopped by user")
    
    logger.info(f"✅ Simulation completed. Total detections sent: {detection_count}")

def main():
    parser = argparse.ArgumentParser(description='Raspberry Pi Pothole Detection Client')
    parser.add_argument('--server-url', required=True, help='Dashboard server URL')
    parser.add_argument('--device-id', help='Unique device identifier')
    parser.add_argument('--simulate', action='store_true', help='Run simulation mode')
    parser.add_argument('--duration', type=int, default=5, help='Simulation duration in minutes')
    parser.add_argument('--test', action='store_true', help='Send a single test detection')
    
    args = parser.parse_args()
    
    try:
        # Initialize client
        client = PotholeDetectionClient(args.server_url, args.device_id)
        
        if args.test:
            # Send a single test detection
            logger.info("🧪 Sending test detection...")
            result = client.send_detection(
                latitude=40.7128,
                longitude=-74.0060,
                severity=15000.0,
                confidence=0.85,
                width=150.0,
                height=80.0
            )
            if result:
                logger.info("✅ Test detection sent successfully!")
            else:
                logger.error("❌ Test detection failed!")
                
        elif args.simulate:
            # Run simulation
            simulate_real_time_detection(client, args.duration)
        else:
            logger.info("ℹ️ Client initialized. Use --test or --simulate to send data.")
            logger.info("ℹ️ Example: python raspberry_pi_client.py --server-url http://localhost:5000 --test")
            
    except Exception as e:
        logger.error(f"💥 Fatal error: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main())

