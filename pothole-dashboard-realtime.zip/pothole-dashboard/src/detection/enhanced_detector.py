import cv2
import torch
import numpy as np
from datetime import datetime
import requests
import json
import os

class EnhancedPotholeDetector:
    def __init__(self, weights='model.safetensors', imgsz=640, conf_thres=0.25, api_base_url='http://localhost:5000/api'):
        self.weights = weights
        self.imgsz = imgsz
        self.conf_thres = conf_thres
        self.api_base_url = api_base_url
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = self.load_model()
        
        # GPS coordinates (in a real implementation, this would come from a GPS module)
        self.current_lat = 40.7128  # Default to NYC coordinates
        self.current_lon = -74.0060
        
    def load_model(self):
        """Load the YOLOv12 model"""
        try:
            if self.weights.endswith('.safetensors'):
                # For safetensors format, we might need to use a different loading method
                # This is a placeholder - actual implementation depends on the model format
                model = torch.jit.load(self.weights)
            else:
                model = torch.jit.load(self.weights)
            
            model.to(self.device)
            model.eval()
            return model
        except Exception as e:
            print(f"Error loading model: {e}")
            return None

    def calculate_severity(self, bbox, confidence):
        """Calculate severity index based on bounding box size and confidence"""
        width = bbox[2] - bbox[0]
        height = bbox[3] - bbox[1]
        area = width * height
        
        # Severity calculation (can be adjusted based on requirements)
        severity = area * confidence
        return severity

    def update_gps_coordinates(self, lat, lon):
        """Update current GPS coordinates"""
        self.current_lat = lat
        self.current_lon = lon

    def process_frame(self, frame):
        """Process a single frame and detect potholes"""
        if self.model is None:
            return frame, []
        
        detections = []
        
        # Preprocess frame
        img = cv2.resize(frame, (self.imgsz, self.imgsz))
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img_tensor = torch.from_numpy(img_rgb.transpose((2, 0, 1))).float().div(255.0).unsqueeze(0)
        img_tensor = img_tensor.to(self.device)

        try:
            # Inference
            with torch.no_grad():
                pred = self.model(img_tensor)
            
            # Process predictions
            if isinstance(pred, (list, tuple)):
                pred = pred[0]
            
            # Scale factor for converting back to original frame size
            scale_x = frame.shape[1] / self.imgsz
            scale_y = frame.shape[0] / self.imgsz
            
            # Process each detection
            for det in pred:
                if len(det) >= 6 and float(det[4]) > self.conf_thres:
                    # Scale coordinates back to original frame size
                    x1 = int(float(det[0]) * scale_x)
                    y1 = int(float(det[1]) * scale_y)
                    x2 = int(float(det[2]) * scale_x)
                    y2 = int(float(det[3]) * scale_y)
                    conf = float(det[4])
                    
                    # Calculate additional metrics
                    width = x2 - x1
                    height = y2 - y1
                    center_x = x1 + width // 2
                    center_y = y1 + height // 2
                    severity = self.calculate_severity([x1, y1, x2, y2], conf)
                    
                    # Create detection data
                    detection_data = {
                        'x1': x1,
                        'y1': y1,
                        'x2': x2,
                        'y2': y2,
                        'width': width,
                        'height': height,
                        'center_x': center_x,
                        'center_y': center_y,
                        'confidence': conf,
                        'severity': severity,
                        'latitude': self.current_lat + (center_x / 100000),  # Add small offset for demo
                        'longitude': self.current_lon + (center_y / 100000)
                    }
                    
                    detections.append(detection_data)
                    
                    # Draw bounding box
                    color = self.get_severity_color(severity)
                    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                    
                    # Draw label
                    label = f'Pothole: {conf:.2f} | Severity: {severity:.0f}'
                    label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 2)[0]
                    cv2.rectangle(frame, (x1, y1 - label_size[1] - 10), 
                                (x1 + label_size[0], y1), color, -1)
                    cv2.putText(frame, label, (x1, y1 - 5), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

        except Exception as e:
            print(f"Error during inference: {e}")
        
        return frame, detections

    def get_severity_color(self, severity):
        """Get color based on severity level"""
        if severity < 5000:
            return (0, 255, 0)  # Green for low severity
        elif severity < 15000:
            return (0, 255, 255)  # Yellow for medium severity
        else:
            return (0, 0, 255)  # Red for high severity

    def save_detection_to_api(self, detection_data):
        """Save detection data to the API"""
        try:
            response = requests.post(f"{self.api_base_url}/potholes", json=detection_data)
            if response.status_code == 201:
                print(f"Detection saved successfully: {response.json()['id']}")
            else:
                print(f"Failed to save detection: {response.text}")
        except Exception as e:
            print(f"Error saving detection to API: {e}")

    def run_webcam_with_api(self):
        """Run webcam detection with API integration"""
        cap = cv2.VideoCapture(0)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        cap.set(cv2.CAP_PROP_FPS, 30)
        
        frame_count = 0
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            # Process frame
            processed_frame, detections = self.process_frame(frame)
            
            # Save detections to API (limit to avoid spam)
            if detections and frame_count % 30 == 0:  # Save every 30 frames
                for detection in detections:
                    detection['frame_number'] = frame_count
                    self.save_detection_to_api(detection)
            
            # Display frame
            cv2.imshow('Enhanced Pothole Detection', processed_frame)
            
            frame_count += 1
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()

class VideoCamera:
    """Enhanced video camera class for web streaming"""
    def __init__(self, api_base_url='http://localhost:5000/api'):
        self.video = cv2.VideoCapture(0)
        if not self.video.isOpened():
            raise ValueError("Could not open webcam")
        
        self.video.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.video.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        self.video.set(cv2.CAP_PROP_FPS, 30)
        
        self.detector = EnhancedPotholeDetector(api_base_url=api_base_url)
        self.frame_count = 0
        
        # Create named window
        cv2.namedWindow('Enhanced Pothole Detection', cv2.WINDOW_NORMAL)

    def __del__(self):
        if self.video.isOpened():
            self.video.release()
        cv2.destroyAllWindows()

    def get_frame(self):
        """Get processed frame for web streaming"""
        success, frame = self.video.read()
        if not success:
            return None

        # Process frame with enhanced detector
        processed_frame, detections = self.detector.process_frame(frame)
        
        # Save detections to API periodically
        if detections and self.frame_count % 60 == 0:  # Save every 60 frames
            for detection in detections:
                detection['frame_number'] = self.frame_count
                self.detector.save_detection_to_api(detection)
        
        # Display frame in window
        cv2.imshow('Enhanced Pothole Detection', processed_frame)
        cv2.waitKey(1)
        
        self.frame_count += 1
        
        # Convert to JPEG for web stream
        _, jpeg = cv2.imencode('.jpg', processed_frame)
        return jpeg.tobytes()

    def update_gps(self, lat, lon):
        """Update GPS coordinates"""
        self.detector.update_gps_coordinates(lat, lon)

