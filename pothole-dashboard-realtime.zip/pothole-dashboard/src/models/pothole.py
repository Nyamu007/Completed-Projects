from src.models.user import db
from datetime import datetime

class Pothole(db.Model):
    __tablename__ = 'potholes'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    severity = db.Column(db.Float, nullable=False)
    confidence = db.Column(db.Float, nullable=False)
    frame_number = db.Column(db.Integer, nullable=True)
    x1 = db.Column(db.Float, nullable=False)
    y1 = db.Column(db.Float, nullable=False)
    x2 = db.Column(db.Float, nullable=False)
    y2 = db.Column(db.Float, nullable=False)
    width = db.Column(db.Float, nullable=False)
    height = db.Column(db.Float, nullable=False)
    center_x = db.Column(db.Float, nullable=False)
    center_y = db.Column(db.Float, nullable=False)
    
    def to_dict(self):
        return {
            'id': self.id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'severity': self.severity,
            'confidence': self.confidence,
            'frame_number': self.frame_number,
            'x1': self.x1,
            'y1': self.y1,
            'x2': self.x2,
            'y2': self.y2,
            'width': self.width,
            'height': self.height,
            'center_x': self.center_x,
            'center_y': self.center_y
        }
    
    @classmethod
    def from_csv_row(cls, row):
        """Create a Pothole instance from a CSV row"""
        return cls(
            frame_number=float(row['frame_number']) if row['frame_number'] else None,
            x1=float(row['x1']),
            y1=float(row['y1']),
            x2=float(row['x2']),
            y2=float(row['y2']),
            width=float(row['width']),
            height=float(row['height']),
            center_x=float(row['center_x']),
            center_y=float(row['center_y']),
            confidence=float(row['confidence']),
            severity=float(row['severity_index']),
            # For now, we'll use dummy coordinates - these should be replaced with real GPS data
            latitude=40.7128 + (float(row['center_x']) / 10000),  # Dummy latitude around NYC
            longitude=-74.0060 + (float(row['center_y']) / 10000)  # Dummy longitude around NYC
        )

