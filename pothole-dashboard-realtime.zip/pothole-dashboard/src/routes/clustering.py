from flask import Blueprint, jsonify, request
from src.models.pothole import Pothole
from src.models.user import db
from sklearn.cluster import DBSCAN, KMeans
from sklearn.preprocessing import StandardScaler
import numpy as np
import pandas as pd
from datetime import datetime

clustering_bp = Blueprint('clustering', __name__)

@clustering_bp.route('/potholes/clusters', methods=['GET'])
def get_pothole_clusters():
    """Get clustered pothole data using DBSCAN or K-Means"""
    try:
        # Get query parameters
        algorithm = request.args.get('algorithm', 'dbscan').lower()
        eps = float(request.args.get('eps', 0.001))  # For DBSCAN
        min_samples = int(request.args.get('min_samples', 5))  # For DBSCAN
        n_clusters = int(request.args.get('n_clusters', 8))  # For K-Means
        include_severity = request.args.get('include_severity', 'true').lower() == 'true'
        
        # Get all potholes with coordinates
        potholes = Pothole.query.filter(
            Pothole.latitude.isnot(None),
            Pothole.longitude.isnot(None)
        ).all()
        
        if len(potholes) < 2:
            return jsonify({
                'clusters': [],
                'algorithm': algorithm,
                'total_potholes': len(potholes),
                'message': 'Not enough data points for clustering'
            })
        
        # Prepare data for clustering
        data = []
        pothole_data = []
        
        for pothole in potholes:
            if include_severity:
                # Include latitude, longitude, and normalized severity
                data.append([
                    pothole.latitude,
                    pothole.longitude,
                    pothole.severity / 100000  # Normalize severity to similar scale as coordinates
                ])
            else:
                # Only use latitude and longitude
                data.append([pothole.latitude, pothole.longitude])
            
            pothole_data.append(pothole.to_dict())
        
        data = np.array(data)
        
        # Standardize the data
        scaler = StandardScaler()
        data_scaled = scaler.fit_transform(data)
        
        # Perform clustering
        if algorithm == 'kmeans':
            clusterer = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
            cluster_labels = clusterer.fit_predict(data_scaled)
        else:  # DBSCAN
            clusterer = DBSCAN(eps=eps, min_samples=min_samples)
            cluster_labels = clusterer.fit_predict(data_scaled)
        
        # Process results
        clusters = {}
        noise_points = []
        
        for i, (pothole, label) in enumerate(zip(pothole_data, cluster_labels)):
            pothole['cluster_id'] = int(label)
            
            if label == -1:  # Noise point (only for DBSCAN)
                noise_points.append(pothole)
            else:
                if label not in clusters:
                    clusters[label] = {
                        'cluster_id': int(label),
                        'potholes': [],
                        'center_lat': 0,
                        'center_lng': 0,
                        'avg_severity': 0,
                        'total_potholes': 0,
                        'severity_distribution': {'low': 0, 'medium': 0, 'high': 0}
                    }
                
                clusters[label]['potholes'].append(pothole)
        
        # Calculate cluster statistics
        cluster_list = []
        for cluster_id, cluster in clusters.items():
            potholes_in_cluster = cluster['potholes']
            
            # Calculate center coordinates
            center_lat = np.mean([p['latitude'] for p in potholes_in_cluster])
            center_lng = np.mean([p['longitude'] for p in potholes_in_cluster])
            
            # Calculate average severity
            avg_severity = np.mean([p['severity'] for p in potholes_in_cluster])
            
            # Calculate severity distribution
            severity_dist = {'low': 0, 'medium': 0, 'high': 0}
            for p in potholes_in_cluster:
                if p['severity'] < 5000:
                    severity_dist['low'] += 1
                elif p['severity'] < 15000:
                    severity_dist['medium'] += 1
                else:
                    severity_dist['high'] += 1
            
            cluster['center_lat'] = center_lat
            cluster['center_lng'] = center_lng
            cluster['avg_severity'] = avg_severity
            cluster['total_potholes'] = len(potholes_in_cluster)
            cluster['severity_distribution'] = severity_dist
            
            cluster_list.append(cluster)
        
        # Sort clusters by number of potholes (descending)
        cluster_list.sort(key=lambda x: x['total_potholes'], reverse=True)
        
        return jsonify({
            'clusters': cluster_list,
            'noise_points': noise_points,
            'algorithm': algorithm,
            'parameters': {
                'eps': eps if algorithm == 'dbscan' else None,
                'min_samples': min_samples if algorithm == 'dbscan' else None,
                'n_clusters': n_clusters if algorithm == 'kmeans' else None,
                'include_severity': include_severity
            },
            'total_potholes': len(potholes),
            'total_clusters': len(cluster_list),
            'noise_points_count': len(noise_points)
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@clustering_bp.route('/potholes/cluster-analysis', methods=['GET'])
def get_cluster_analysis():
    """Get detailed analysis of pothole clusters"""
    try:
        # Get clustering results
        algorithm = request.args.get('algorithm', 'dbscan').lower()
        
        # Get all potholes with coordinates
        potholes = Pothole.query.filter(
            Pothole.latitude.isnot(None),
            Pothole.longitude.isnot(None)
        ).all()
        
        if len(potholes) < 2:
            return jsonify({
                'analysis': {},
                'message': 'Not enough data points for analysis'
            })
        
        # Convert to DataFrame for easier analysis
        df = pd.DataFrame([p.to_dict() for p in potholes])
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Basic statistics
        total_potholes = len(df)
        avg_severity = df['severity'].mean()
        severity_std = df['severity'].std()
        
        # Severity distribution
        severity_distribution = {
            'low': len(df[df['severity'] < 5000]),
            'medium': len(df[(df['severity'] >= 5000) & (df['severity'] < 15000)]),
            'high': len(df[df['severity'] >= 15000])
        }
        
        # Temporal analysis
        df['date'] = df['timestamp'].dt.date
        daily_counts = df.groupby('date').size().to_dict()
        
        # Convert date keys to strings for JSON serialization
        daily_counts = {str(k): v for k, v in daily_counts.items()}
        
        # Confidence analysis
        confidence_stats = {
            'mean': df['confidence'].mean(),
            'std': df['confidence'].std(),
            'min': df['confidence'].min(),
            'max': df['confidence'].max()
        }
        
        # Geographic spread analysis
        lat_range = df['latitude'].max() - df['latitude'].min()
        lng_range = df['longitude'].max() - df['longitude'].min()
        
        geographic_stats = {
            'latitude_range': lat_range,
            'longitude_range': lng_range,
            'center_lat': df['latitude'].mean(),
            'center_lng': df['longitude'].mean(),
            'bounding_box': {
                'north': df['latitude'].max(),
                'south': df['latitude'].min(),
                'east': df['longitude'].max(),
                'west': df['longitude'].min()
            }
        }
        
        # Correlation analysis
        correlation_matrix = df[['latitude', 'longitude', 'severity', 'confidence']].corr().to_dict()
        
        analysis = {
            'total_potholes': total_potholes,
            'severity_stats': {
                'mean': avg_severity,
                'std': severity_std,
                'min': df['severity'].min(),
                'max': df['severity'].max()
            },
            'severity_distribution': severity_distribution,
            'confidence_stats': confidence_stats,
            'geographic_stats': geographic_stats,
            'temporal_analysis': {
                'daily_counts': daily_counts,
                'date_range': {
                    'start': str(df['timestamp'].min().date()),
                    'end': str(df['timestamp'].max().date())
                }
            },
            'correlation_matrix': correlation_matrix
        }
        
        return jsonify({
            'analysis': analysis,
            'algorithm': algorithm,
            'timestamp': datetime.utcnow().isoformat()
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@clustering_bp.route('/potholes/hotspots', methods=['GET'])
def get_pothole_hotspots():
    """Identify pothole hotspots using density-based analysis"""
    try:
        # Get parameters
        grid_size = float(request.args.get('grid_size', 0.001))  # Grid cell size in degrees
        min_density = int(request.args.get('min_density', 3))  # Minimum potholes per cell
        
        # Get all potholes with coordinates
        potholes = Pothole.query.filter(
            Pothole.latitude.isnot(None),
            Pothole.longitude.isnot(None)
        ).all()
        
        if len(potholes) < min_density:
            return jsonify({
                'hotspots': [],
                'message': 'Not enough data points for hotspot analysis'
            })
        
        # Create grid and count potholes in each cell
        df = pd.DataFrame([p.to_dict() for p in potholes])
        
        # Create grid coordinates
        df['grid_lat'] = (df['latitude'] / grid_size).round() * grid_size
        df['grid_lng'] = (df['longitude'] / grid_size).round() * grid_size
        
        # Group by grid cell and calculate statistics
        grid_stats = df.groupby(['grid_lat', 'grid_lng']).agg({
            'id': 'count',
            'severity': ['mean', 'max', 'std'],
            'confidence': 'mean',
            'latitude': 'mean',
            'longitude': 'mean'
        }).reset_index()
        
        # Flatten column names
        grid_stats.columns = [
            'grid_lat', 'grid_lng', 'pothole_count', 'avg_severity', 
            'max_severity', 'severity_std', 'avg_confidence', 'center_lat', 'center_lng'
        ]
        
        # Filter for hotspots (cells with minimum density)
        hotspots = grid_stats[grid_stats['pothole_count'] >= min_density]
        
        # Sort by pothole count (descending)
        hotspots = hotspots.sort_values('pothole_count', ascending=False)
        
        # Convert to list of dictionaries
        hotspot_list = []
        for _, row in hotspots.iterrows():
            hotspot = {
                'center_lat': row['center_lat'],
                'center_lng': row['center_lng'],
                'pothole_count': int(row['pothole_count']),
                'avg_severity': row['avg_severity'],
                'max_severity': row['max_severity'],
                'severity_std': row['severity_std'] if pd.notna(row['severity_std']) else 0,
                'avg_confidence': row['avg_confidence'],
                'grid_bounds': {
                    'north': row['grid_lat'] + grid_size/2,
                    'south': row['grid_lat'] - grid_size/2,
                    'east': row['grid_lng'] + grid_size/2,
                    'west': row['grid_lng'] - grid_size/2
                },
                'risk_score': row['pothole_count'] * row['avg_severity'] / 10000  # Composite risk score
            }
            hotspot_list.append(hotspot)
        
        return jsonify({
            'hotspots': hotspot_list,
            'parameters': {
                'grid_size': grid_size,
                'min_density': min_density
            },
            'total_hotspots': len(hotspot_list),
            'total_potholes_analyzed': len(potholes)
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

