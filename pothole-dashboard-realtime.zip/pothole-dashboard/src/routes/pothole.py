from flask import Blueprint, jsonify, request
from src.models.pothole import Pothole
from src.models.user import db
from datetime import datetime
import csv
import os

pothole_bp = Blueprint('pothole', __name__)

@pothole_bp.route('/potholes', methods=['GET'])
def get_potholes():
    """Get all potholes with optional filtering"""
    try:
        # Get query parameters for filtering
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        min_severity = request.args.get('min_severity', type=float)
        max_severity = request.args.get('max_severity', type=float)
        
        # Build query
        query = Pothole.query
        
        if start_date:
            start_dt = datetime.fromisoformat(start_date)
            query = query.filter(Pothole.timestamp >= start_dt)
            
        if end_date:
            end_dt = datetime.fromisoformat(end_date)
            query = query.filter(Pothole.timestamp <= end_dt)
            
        if min_severity is not None:
            query = query.filter(Pothole.severity >= min_severity)
            
        if max_severity is not None:
            query = query.filter(Pothole.severity <= max_severity)
        
        potholes = query.all()
        return jsonify([pothole.to_dict() for pothole in potholes])
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@pothole_bp.route('/potholes/stats', methods=['GET'])
def get_pothole_stats():
    """Get statistics about potholes"""
    try:
        total_count = Pothole.query.count()
        
        if total_count == 0:
            return jsonify({
                'total_count': 0,
                'avg_severity': 0,
                'max_severity': 0,
                'min_severity': 0
            })
        
        # Calculate statistics
        avg_severity = db.session.query(db.func.avg(Pothole.severity)).scalar()
        max_severity = db.session.query(db.func.max(Pothole.severity)).scalar()
        min_severity = db.session.query(db.func.min(Pothole.severity)).scalar()
        
        return jsonify({
            'total_count': total_count,
            'avg_severity': round(avg_severity, 2) if avg_severity else 0,
            'max_severity': max_severity if max_severity else 0,
            'min_severity': min_severity if min_severity else 0
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@pothole_bp.route('/potholes/import-csv', methods=['POST'])
def import_csv_data():
    """Import pothole data from CSV file"""
    try:
        csv_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'pothole_data.csv')
        
        if not os.path.exists(csv_path):
            return jsonify({'error': 'CSV file not found'}), 404
        
        imported_count = 0
        
        with open(csv_path, 'r') as file:
            csv_reader = csv.DictReader(file)
            
            for row in csv_reader:
                # Skip rows with missing confidence data
                if not row.get('confidence'):
                    continue
                    
                pothole = Pothole.from_csv_row(row)
                db.session.add(pothole)
                imported_count += 1
        
        db.session.commit()
        
        return jsonify({
            'message': f'Successfully imported {imported_count} pothole records',
            'imported_count': imported_count
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@pothole_bp.route('/potholes/clear', methods=['DELETE'])
def clear_potholes():
    """Clear all pothole data"""
    try:
        deleted_count = Pothole.query.delete()
        db.session.commit()
        
        return jsonify({
            'message': f'Successfully deleted {deleted_count} pothole records',
            'deleted_count': deleted_count
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@pothole_bp.route('/potholes', methods=['POST'])
def add_pothole():
    """Add a new pothole detection"""
    try:
        data = request.get_json()
        
        pothole = Pothole(
            latitude=data.get('latitude'),
            longitude=data.get('longitude'),
            severity=data['severity'],
            confidence=data['confidence'],
            frame_number=data.get('frame_number'),
            x1=data['x1'],
            y1=data['y1'],
            x2=data['x2'],
            y2=data['y2'],
            width=data['width'],
            height=data['height'],
            center_x=data['center_x'],
            center_y=data['center_y']
        )
        
        db.session.add(pothole)
        db.session.commit()
        
        return jsonify(pothole.to_dict()), 201
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

