from flask import Blueprint, request, jsonify
from flask_socketio import emit
from datetime import datetime
import json
from ..models.pothole import Pothole
from ..models.user import db

realtime_bp = Blueprint('realtime', __name__)

# Store connected clients
connected_clients = set()

def init_socketio(socketio):
    """Initialize SocketIO event handlers"""
    
    @socketio.on('connect')
    def handle_connect():
        """Handle client connection"""
        print(f'Client connected: {request.sid}')
        connected_clients.add(request.sid)
        emit('status', {'message': 'Connected to real-time updates'})
    
    @socketio.on('disconnect')
    def handle_disconnect():
        """Handle client disconnection"""
        print(f'Client disconnected: {request.sid}')
        connected_clients.discard(request.sid)
    
    @socketio.on('subscribe_updates')
    def handle_subscribe(data):
        """Handle subscription to specific update types"""
        print(f'Client {request.sid} subscribed to: {data}')
        emit('subscription_confirmed', data)

def broadcast_pothole_update(pothole_data, update_type='new_detection'):
    """Broadcast pothole update to all connected clients"""
    from src.main import socketio
    
    socketio.emit('pothole_update', {
        'type': update_type,
        'data': pothole_data,
        'timestamp': datetime.now().isoformat()
    })

@realtime_bp.route('/api/realtime/raspberry-pi/detect', methods=['POST'])
def receive_raspberry_pi_detection():
    """Receive pothole detection data from Raspberry Pi"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['latitude', 'longitude', 'severity', 'confidence', 'width', 'height']
        if not all(field in data for field in required_fields):
            return jsonify({'error': 'Missing required fields'}), 400
        
        # Create new pothole record
        pothole = Pothole(
            timestamp=datetime.now(),
            latitude=float(data['latitude']),
            longitude=float(data['longitude']),
            severity=float(data['severity']),
            confidence=float(data['confidence']),
            width=float(data['width']),
            height=float(data['height']),
            # Calculate bounding box coordinates from width/height
            x1=0.0,  # Default values - should be provided by client
            y1=0.0,
            x2=float(data['width']),
            y2=float(data['height']),
            center_x=float(data['width']) / 2,
            center_y=float(data['height']) / 2,
            frame_number=data.get('frame_number', 0)
        )
        
        db.session.add(pothole)
        db.session.commit()
        
        # Prepare data for broadcast
        pothole_data = {
            'id': pothole.id,
            'timestamp': pothole.timestamp.isoformat(),
            'latitude': pothole.latitude,
            'longitude': pothole.longitude,
            'severity': pothole.severity,
            'confidence': pothole.confidence,
            'width': pothole.width,
            'height': pothole.height,
            'device_id': data.get('device_id', 'unknown'),
            'image_path': data.get('image_path', None)
        }
        
        # Broadcast to all connected clients
        broadcast_pothole_update(pothole_data, 'new_detection')
        
        return jsonify({
            'message': 'Detection received and broadcasted',
            'pothole_id': pothole.id,
            'clients_notified': len(connected_clients)
        }), 201
        
    except Exception as e:
        return jsonify({'error': f'Failed to process detection: {str(e)}'}), 500

@realtime_bp.route('/api/realtime/raspberry-pi/batch', methods=['POST'])
def receive_raspberry_pi_batch():
    """Receive batch of pothole detections from Raspberry Pi"""
    try:
        data = request.get_json()
        detections = data.get('detections', [])
        
        if not detections:
            return jsonify({'error': 'No detections provided'}), 400
        
        processed_count = 0
        pothole_data_list = []
        
        for detection in detections:
            try:
                # Validate required fields
                required_fields = ['latitude', 'longitude', 'severity', 'confidence', 'width', 'height']
                if not all(field in detection for field in required_fields):
                    continue
                
                # Create new pothole record
                pothole = Pothole(
                    timestamp=datetime.fromisoformat(detection.get('timestamp', datetime.now().isoformat())),
                    latitude=float(detection['latitude']),
                    longitude=float(detection['longitude']),
                    severity=float(detection['severity']),
                    confidence=float(detection['confidence']),
                    width=float(detection['width']),
                    height=float(detection['height']),
                    # Calculate bounding box coordinates from width/height
                    x1=0.0,  # Default values - should be provided by client
                    y1=0.0,
                    x2=float(detection['width']),
                    y2=float(detection['height']),
                    center_x=float(detection['width']) / 2,
                    center_y=float(detection['height']) / 2,
                    frame_number=detection.get('frame_number', 0)
                )
                
                db.session.add(pothole)
                db.session.flush()  # Get the ID without committing
                
                pothole_data = {
                    'id': pothole.id,
                    'timestamp': pothole.timestamp.isoformat(),
                    'latitude': pothole.latitude,
                    'longitude': pothole.longitude,
                    'severity': pothole.severity,
                    'confidence': pothole.confidence,
                    'width': pothole.width,
                    'height': pothole.height,
                    'device_id': detection.get('device_id', 'unknown'),
                    'image_path': detection.get('image_path', None)
                }
                
                pothole_data_list.append(pothole_data)
                processed_count += 1
                
            except Exception as e:
                print(f"Error processing detection: {e}")
                continue
        
        # Commit all changes
        db.session.commit()
        
        # Broadcast batch update
        if pothole_data_list:
            broadcast_pothole_update(pothole_data_list, 'batch_detection')
        
        return jsonify({
            'message': f'Batch processed: {processed_count}/{len(detections)} detections',
            'processed_count': processed_count,
            'clients_notified': len(connected_clients)
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Failed to process batch: {str(e)}'}), 500

@realtime_bp.route('/api/realtime/status', methods=['GET'])
def get_realtime_status():
    """Get real-time system status"""
    return jsonify({
        'connected_clients': len(connected_clients),
        'websocket_enabled': True,
        'last_update': datetime.now().isoformat()
    })

@realtime_bp.route('/api/realtime/test', methods=['POST'])
def test_realtime_update():
    """Test endpoint to simulate real-time updates"""
    try:
        # Create a test pothole detection
        test_data = {
            'id': 'test_' + str(datetime.now().timestamp()),
            'timestamp': datetime.now().isoformat(),
            'latitude': 40.7128 + (0.01 * (0.5 - __import__('random').random())),
            'longitude': -74.0060 + (0.01 * (0.5 - __import__('random').random())),
            'severity': __import__('random').randint(1000, 50000),
            'confidence': __import__('random').uniform(0.3, 0.9),
            'width': __import__('random').randint(50, 300),
            'height': __import__('random').randint(30, 150),
            'device_id': 'test_device',
            'image_path': None
        }
        
        # Broadcast test update
        broadcast_pothole_update(test_data, 'test_detection')
        
        return jsonify({
            'message': 'Test update broadcasted',
            'data': test_data,
            'clients_notified': len(connected_clients)
        })
        
    except Exception as e:
        return jsonify({'error': f'Failed to send test update: {str(e)}'}), 500

