from flask import Blueprint, jsonify, request, send_file
import pandas as pd
import io
from datetime import datetime
from ..models.pothole import Pothole
from ..models.user import db
import numpy as np

reports_bp = Blueprint('reports', __name__)

@reports_bp.route('/api/potholes/report', methods=['GET'])
def download_analysis_report():
    """Generate and download analysis report in CSV or XLSX format"""
    try:
        format_type = request.args.get('format', 'csv').lower()
        
        if format_type not in ['csv', 'xlsx']:
            return jsonify({'error': 'Invalid format. Use csv or xlsx'}), 400
        
        # Get all potholes from database
        potholes = Pothole.query.all()
        
        if not potholes:
            return jsonify({'error': 'No pothole data available'}), 404
        
        # Convert to DataFrame
        data = []
        for pothole in potholes:
            data.append({
                'ID': pothole.id,
                'Timestamp': pothole.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                'Latitude': pothole.latitude,
                'Longitude': pothole.longitude,
                'Severity': pothole.severity,
                'Confidence': pothole.confidence,
                'Width': pothole.width,
                'Height': pothole.height,
                'Severity_Category': get_severity_category(pothole.severity),
                'Risk_Level': get_risk_level(pothole.severity, pothole.confidence)
            })
        
        df = pd.DataFrame(data)
        
        # Add summary statistics
        summary_stats = generate_summary_statistics(df)
        
        # Create output buffer
        output = io.BytesIO()
        
        if format_type == 'csv':
            # Create CSV with summary at the top
            csv_content = generate_csv_report(df, summary_stats)
            output.write(csv_content.encode('utf-8'))
            output.seek(0)
            
            return send_file(
                output,
                mimetype='text/csv',
                as_attachment=True,
                download_name=f'pothole_analysis_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
            )
        
        elif format_type == 'xlsx':
            # Create Excel file with multiple sheets
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                # Main data sheet
                df.to_excel(writer, sheet_name='Pothole Data', index=False)
                
                # Summary statistics sheet
                summary_df = pd.DataFrame(list(summary_stats.items()), columns=['Metric', 'Value'])
                summary_df.to_excel(writer, sheet_name='Summary Statistics', index=False)
                
                # Severity distribution sheet
                severity_dist = df['Severity_Category'].value_counts().reset_index()
                severity_dist.columns = ['Severity Category', 'Count']
                severity_dist.to_excel(writer, sheet_name='Severity Distribution', index=False)
                
                # Geographic analysis sheet
                geo_stats = generate_geographic_analysis(df)
                geo_df = pd.DataFrame(list(geo_stats.items()), columns=['Geographic Metric', 'Value'])
                geo_df.to_excel(writer, sheet_name='Geographic Analysis', index=False)
            
            output.seek(0)
            
            return send_file(
                output,
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                as_attachment=True,
                download_name=f'pothole_analysis_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
            )
    
    except Exception as e:
        return jsonify({'error': f'Failed to generate report: {str(e)}'}), 500

def get_severity_category(severity):
    """Categorize severity level"""
    if severity < 5000:
        return 'Low'
    elif severity < 15000:
        return 'Medium'
    else:
        return 'High'

def get_risk_level(severity, confidence):
    """Calculate risk level based on severity and confidence"""
    risk_score = (severity / 1000) * confidence
    
    if risk_score < 5:
        return 'Low Risk'
    elif risk_score < 15:
        return 'Medium Risk'
    else:
        return 'High Risk'

def generate_summary_statistics(df):
    """Generate comprehensive summary statistics"""
    stats = {
        'Total Potholes': len(df),
        'Average Severity': round(df['Severity'].mean(), 2),
        'Median Severity': round(df['Severity'].median(), 2),
        'Min Severity': round(df['Severity'].min(), 2),
        'Max Severity': round(df['Severity'].max(), 2),
        'Severity Standard Deviation': round(df['Severity'].std(), 2),
        'Average Confidence': round(df['Confidence'].mean() * 100, 2),
        'Min Confidence': round(df['Confidence'].min() * 100, 2),
        'Max Confidence': round(df['Confidence'].max() * 100, 2),
        'Low Severity Count': len(df[df['Severity_Category'] == 'Low']),
        'Medium Severity Count': len(df[df['Severity_Category'] == 'Medium']),
        'High Severity Count': len(df[df['Severity_Category'] == 'High']),
        'Low Risk Count': len(df[df['Risk_Level'] == 'Low Risk']),
        'Medium Risk Count': len(df[df['Risk_Level'] == 'Medium Risk']),
        'High Risk Count': len(df[df['Risk_Level'] == 'High Risk']),
        'Date Range Start': df['Timestamp'].min(),
        'Date Range End': df['Timestamp'].max(),
        'Average Width': round(df['Width'].mean(), 2),
        'Average Height': round(df['Height'].mean(), 2)
    }
    
    return stats

def generate_geographic_analysis(df):
    """Generate geographic analysis statistics"""
    geo_stats = {
        'Center Latitude': round(df['Latitude'].mean(), 6),
        'Center Longitude': round(df['Longitude'].mean(), 6),
        'Latitude Range': round(df['Latitude'].max() - df['Latitude'].min(), 6),
        'Longitude Range': round(df['Longitude'].max() - df['Longitude'].min(), 6),
        'Northernmost Point': round(df['Latitude'].max(), 6),
        'Southernmost Point': round(df['Latitude'].min(), 6),
        'Easternmost Point': round(df['Longitude'].max(), 6),
        'Westernmost Point': round(df['Longitude'].min(), 6),
        'Coverage Area (approx km²)': round(
            (df['Latitude'].max() - df['Latitude'].min()) * 111 * 
            (df['Longitude'].max() - df['Longitude'].min()) * 85, 2
        )
    }
    
    return geo_stats

def generate_csv_report(df, summary_stats):
    """Generate CSV content with summary statistics at the top"""
    csv_content = "POTHOLE ANALYSIS REPORT\n"
    csv_content += f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    
    csv_content += "SUMMARY STATISTICS\n"
    for key, value in summary_stats.items():
        csv_content += f"{key},{value}\n"
    
    csv_content += "\nDETAILED DATA\n"
    csv_content += df.to_csv(index=False)
    
    return csv_content

