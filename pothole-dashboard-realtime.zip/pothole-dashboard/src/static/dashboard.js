// Dashboard JavaScript for Pothole Detection
class PotholeDashboard {
    constructor() {
        this.map = null;
        this.markers = [];
        this.markerClusterGroup = null;
        this.clusteringEnabled = false;
        this.currentData = [];
        this.filteredData = [];
        this.hotspots = [];
        this.hotspotMarkers = [];
        this.showHotspots = false;
        this.socket = null;
        this.realtimeUpdateCount = 0;
        
        this.initializeMap();
        this.initializeWebSocket();
        this.loadInitialData();
        this.setupEventListeners();
    }

    initializeMap() {
        // Initialize Leaflet map centered on NYC (default location)
        this.map = L.map('map').setView([40.7128, -74.0060], 12);

        // Add OpenStreetMap tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(this.map);

        // Initialize marker cluster group
        this.markerClusterGroup = L.markerClusterGroup({
            chunkedLoading: true,
            maxClusterRadius: 50
        });
    }

    setupEventListeners() {
        // Set up any additional event listeners if needed
        window.addEventListener('resize', () => {
            this.map.invalidateSize();
        });
    }

    initializeWebSocket() {
        try {
            // Initialize Socket.IO connection
            this.socket = io();
            
            // Connection event handlers
            this.socket.on('connect', () => {
                console.log('Connected to real-time updates');
                this.updateConnectionStatus('connected', 'Connected');
                this.socket.emit('subscribe_updates', { types: ['pothole_updates'] });
            });
            
            this.socket.on('disconnect', () => {
                console.log('Disconnected from real-time updates');
                this.updateConnectionStatus('disconnected', 'Disconnected');
            });
            
            this.socket.on('connect_error', (error) => {
                console.error('Connection error:', error);
                this.updateConnectionStatus('disconnected', 'Connection Error');
            });
            
            // Real-time update handlers
            this.socket.on('pothole_update', (data) => {
                this.handleRealtimeUpdate(data);
            });
            
            this.socket.on('status', (data) => {
                console.log('Status update:', data.message);
            });
            
            this.socket.on('subscription_confirmed', (data) => {
                console.log('Subscription confirmed:', data);
            });
            
        } catch (error) {
            console.error('Failed to initialize WebSocket:', error);
            this.updateConnectionStatus('disconnected', 'WebSocket Error');
        }
    }

    updateConnectionStatus(status, message) {
        const statusDot = document.getElementById('statusDot');
        const statusText = document.getElementById('statusText');
        
        if (statusDot && statusText) {
            statusDot.className = `status-dot ${status}`;
            statusText.textContent = message;
        }
    }

    handleRealtimeUpdate(updateData) {
        console.log('Real-time update received:', updateData);
        
        try {
            const { type, data, timestamp } = updateData;
            
            // Update counter
            this.realtimeUpdateCount++;
            const updateCountElement = document.getElementById('updateCount');
            if (updateCountElement) {
                updateCountElement.textContent = this.realtimeUpdateCount;
            }
            
            // Show notification
            this.showRealtimeNotification(type, data);
            
            // Handle different update types
            switch (type) {
                case 'new_detection':
                    this.addNewPothole(data);
                    break;
                case 'batch_detection':
                    this.addBatchPotholes(data);
                    break;
                case 'test_detection':
                    this.addTestPothole(data);
                    break;
                default:
                    console.log('Unknown update type:', type);
            }
            
            // Refresh statistics
            this.loadStatistics();
            
        } catch (error) {
            console.error('Error handling real-time update:', error);
        }
    }

    showRealtimeNotification(type, data) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'realtime-notification';
        
        let message = '';
        if (type === 'new_detection') {
            message = `New pothole detected! Severity: ${Math.round(data.severity)}`;
        } else if (type === 'batch_detection') {
            message = `${data.length} new potholes detected!`;
        } else if (type === 'test_detection') {
            message = `Test detection: Severity ${Math.round(data.severity)}`;
        }
        
        notification.innerHTML = `
            <div style="display: flex; align-items: center;">
                <i class="fas fa-exclamation-triangle" style="margin-right: 10px;"></i>
                <span>${message}</span>
            </div>
        `;
        
        // Add to page
        document.body.appendChild(notification);
        
        // Show notification
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    addNewPothole(potholeData) {
        // Add to current data
        this.currentData.unshift(potholeData);
        this.filteredData.unshift(potholeData);
        
        // Add marker to map
        if (potholeData.latitude && potholeData.longitude) {
            const marker = this.createMarker(potholeData);
            this.markers.unshift(marker);
            
            if (this.clusteringEnabled) {
                this.markerClusterGroup.addLayer(marker);
            } else {
                marker.addTo(this.map);
            }
            
            // Animate marker
            setTimeout(() => {
                marker.openPopup();
            }, 500);
        }
        
        // Update data table
        this.updateDataTable();
    }

    addBatchPotholes(potholeDataArray) {
        // Add all potholes to current data
        this.currentData = [...potholeDataArray, ...this.currentData];
        this.filteredData = [...potholeDataArray, ...this.filteredData];
        
        // Add markers to map
        potholeDataArray.forEach(potholeData => {
            if (potholeData.latitude && potholeData.longitude) {
                const marker = this.createMarker(potholeData);
                this.markers.unshift(marker);
                
                if (this.clusteringEnabled) {
                    this.markerClusterGroup.addLayer(marker);
                } else {
                    marker.addTo(this.map);
                }
            }
        });
        
        // Update data table
        this.updateDataTable();
    }

    addTestPothole(potholeData) {
        // Handle test pothole (similar to new pothole but with different styling)
        this.addNewPothole(potholeData);
    }

    async loadInitialData() {
        try {
            this.showLoading(true);
            
            // Load statistics
            await this.loadStatistics();
            
            // Load pothole data
            await this.loadPotholeData();
            
            // Load hotspots
            await this.loadHotspots();
            
        } catch (error) {
            console.error('Error loading initial data:', error);
        } finally {
            this.showLoading(false);
        }
    }

    async loadStatistics() {
        try {
            const response = await fetch('/api/potholes/stats');
            const stats = await response.json();
            
            document.getElementById('total-count').textContent = stats.total_count || 0;
            document.getElementById('avg-severity').textContent = stats.avg_severity || 0;
            document.getElementById('max-severity').textContent = Math.round(stats.max_severity) || 0;
        } catch (error) {
            console.error('Error loading statistics:', error);
        }
    }

    async loadPotholeData(filters = {}) {
        try {
            this.showLoading(true);
            
            // Build query string from filters
            const queryParams = new URLSearchParams();
            if (filters.start_date) queryParams.append('start_date', filters.start_date);
            if (filters.end_date) queryParams.append('end_date', filters.end_date);
            if (filters.min_severity !== undefined) queryParams.append('min_severity', filters.min_severity);
            if (filters.max_severity !== undefined) queryParams.append('max_severity', filters.max_severity);
            
            const url = `/api/potholes${queryParams.toString() ? '?' + queryParams.toString() : ''}`;
            const response = await fetch(url);
            const data = await response.json();
            
            this.currentData = data;
            this.filteredData = data;
            
            this.updateMap();
            this.updateDataTable();
            
        } catch (error) {
            console.error('Error loading pothole data:', error);
        } finally {
            this.showLoading(false);
        }
    }

    async loadHotspots() {
        try {
            const response = await fetch('/api/potholes/hotspots?grid_size=0.005&min_density=5');
            const data = await response.json();
            this.hotspots = data.hotspots || [];
        } catch (error) {
            console.error('Error loading hotspots:', error);
        }
    }

    updateMap() {
        // Clear existing markers
        this.clearMarkers();
        
        // Add new markers
        this.filteredData.forEach(pothole => {
            if (pothole.latitude && pothole.longitude) {
                const marker = this.createMarker(pothole);
                this.markers.push(marker);
                
                if (this.clusteringEnabled) {
                    this.markerClusterGroup.addLayer(marker);
                } else {
                    marker.addTo(this.map);
                }
            }
        });
        
        // Add cluster group to map if clustering is enabled
        if (this.clusteringEnabled && !this.map.hasLayer(this.markerClusterGroup)) {
            this.map.addLayer(this.markerClusterGroup);
        }
        
        // Add hotspots if enabled
        if (this.showHotspots) {
            this.addHotspotsToMap();
        }
        
        // Fit map to show all markers if there are any
        if (this.markers.length > 0) {
            const group = new L.featureGroup(this.markers);
            this.map.fitBounds(group.getBounds().pad(0.1));
        }
    }

    addHotspotsToMap() {
        // Clear existing hotspot markers
        this.clearHotspotMarkers();
        
        this.hotspots.forEach(hotspot => {
            // Create a rectangle for the hotspot grid cell
            const bounds = [
                [hotspot.grid_bounds.south, hotspot.grid_bounds.west],
                [hotspot.grid_bounds.north, hotspot.grid_bounds.east]
            ];
            
            // Color based on risk score
            let color = '#28a745'; // Green for low risk
            if (hotspot.risk_score > 20) {
                color = '#dc3545'; // Red for high risk
            } else if (hotspot.risk_score > 10) {
                color = '#ffc107'; // Yellow for medium risk
            }
            
            const rectangle = L.rectangle(bounds, {
                color: color,
                weight: 2,
                opacity: 0.8,
                fillOpacity: 0.3
            });
            
            // Create popup content
            const popupContent = `
                <div style="min-width: 200px;">
                    <h4>Hotspot Area</h4>
                    <p><strong>Potholes:</strong> ${hotspot.pothole_count}</p>
                    <p><strong>Avg Severity:</strong> ${Math.round(hotspot.avg_severity)}</p>
                    <p><strong>Max Severity:</strong> ${Math.round(hotspot.max_severity)}</p>
                    <p><strong>Risk Score:</strong> ${hotspot.risk_score.toFixed(2)}</p>
                    <p><strong>Center:</strong> ${hotspot.center_lat.toFixed(6)}, ${hotspot.center_lng.toFixed(6)}</p>
                </div>
            `;
            
            rectangle.bindPopup(popupContent);
            rectangle.addTo(this.map);
            this.hotspotMarkers.push(rectangle);
        });
    }

    clearHotspotMarkers() {
        this.hotspotMarkers.forEach(marker => {
            if (this.map.hasLayer(marker)) {
                this.map.removeLayer(marker);
            }
        });
        this.hotspotMarkers = [];
    }

    createMarker(pothole) {
        const severity = pothole.severity;
        let color, size;
        
        // Determine marker color and size based on severity
        if (severity < 5000) {
            color = '#28a745'; // Green for low severity
            size = 8;
        } else if (severity < 15000) {
            color = '#ffc107'; // Yellow for medium severity
            size = 12;
        } else {
            color = '#dc3545'; // Red for high severity
            size = 16;
        }
        
        const marker = L.circleMarker([pothole.latitude, pothole.longitude], {
            radius: size,
            fillColor: color,
            color: '#fff',
            weight: 2,
            opacity: 1,
            fillOpacity: 0.8
        });
        
        // Create popup content
        const popupContent = `
            <div style="min-width: 200px;">
                <h4>Pothole #${pothole.id}</h4>
                <p><strong>Severity:</strong> ${Math.round(pothole.severity)}</p>
                <p><strong>Confidence:</strong> ${(pothole.confidence * 100).toFixed(1)}%</p>
                <p><strong>Location:</strong> ${pothole.latitude.toFixed(6)}, ${pothole.longitude.toFixed(6)}</p>
                <p><strong>Detected:</strong> ${new Date(pothole.timestamp).toLocaleString()}</p>
                <p><strong>Bounding Box:</strong> ${Math.round(pothole.width)}x${Math.round(pothole.height)}px</p>
            </div>
        `;
        
        marker.bindPopup(popupContent);
        
        return marker;
    }

    clearMarkers() {
        // Remove markers from map
        this.markers.forEach(marker => {
            if (this.map.hasLayer(marker)) {
                this.map.removeLayer(marker);
            }
        });
        
        // Clear cluster group
        if (this.markerClusterGroup) {
            this.markerClusterGroup.clearLayers();
            if (this.map.hasLayer(this.markerClusterGroup)) {
                this.map.removeLayer(this.markerClusterGroup);
            }
        }
        
        this.markers = [];
    }

    updateDataTable() {
        const tableBody = document.getElementById('data-table-body');
        tableBody.innerHTML = '';
        
        // Show only the most recent 20 records in the table
        const recentData = this.filteredData
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
            .slice(0, 20);
        
        recentData.forEach(pothole => {
            const row = document.createElement('tr');
            
            // Determine severity class
            let severityClass = 'severity-low';
            if (pothole.severity >= 15000) {
                severityClass = 'severity-high';
            } else if (pothole.severity >= 5000) {
                severityClass = 'severity-medium';
            }
            
            row.innerHTML = `
                <td>${pothole.id}</td>
                <td>${new Date(pothole.timestamp).toLocaleString()}</td>
                <td>${pothole.latitude ? pothole.latitude.toFixed(6) : 'N/A'}</td>
                <td>${pothole.longitude ? pothole.longitude.toFixed(6) : 'N/A'}</td>
                <td><span class="${severityClass}">${Math.round(pothole.severity)}</span></td>
                <td>${(pothole.confidence * 100).toFixed(1)}%</td>
            `;
            
            // Add click event to center map on this pothole
            row.addEventListener('click', () => {
                if (pothole.latitude && pothole.longitude) {
                    this.map.setView([pothole.latitude, pothole.longitude], 16);
                    
                    // Find and open the corresponding marker popup
                    const marker = this.markers.find(m => 
                        Math.abs(m.getLatLng().lat - pothole.latitude) < 0.0001 &&
                        Math.abs(m.getLatLng().lng - pothole.longitude) < 0.0001
                    );
                    if (marker) {
                        marker.openPopup();
                    }
                }
            });
            
            tableBody.appendChild(row);
        });
    }

    showLoading(show) {
        const loadingElement = document.getElementById('loading');
        if (show) {
            loadingElement.classList.add('show');
        } else {
            loadingElement.classList.remove('show');
        }
    }

    getSeverityRange(severityFilter) {
        switch (severityFilter) {
            case 'low':
                return { min: 0, max: 4999 };
            case 'medium':
                return { min: 5000, max: 14999 };
            case 'high':
                return { min: 15000, max: Infinity };
            default:
                return {};
        }
    }

    async showAnalysis() {
        try {
            this.showLoading(true);
            const response = await fetch("/api/potholes/cluster-analysis");
            const data = await response.json();
            
            this.displayAnalysisReport(data.analysis);
            document.getElementById("analysisModal").style.display = "block";
        } catch (error) {
            console.error("Error loading cluster analysis:", error);
            alert("Error loading cluster analysis. Please try again.");
        } finally {
            this.showLoading(false);
        }
    }

    displayAnalysisReport(analysis) {
        const contentDiv = document.getElementById("analysisReportContent");
        contentDiv.innerHTML = `
            <div style="margin-bottom: 20px;">
                <h3>Overview</h3>
                <p><strong>Total Potholes:</strong> ${analysis.total_potholes}</p>
                <p><strong>Average Severity:</strong> ${Math.round(analysis.severity_stats.mean)}</p>
                <p><strong>Severity Range:</strong> ${Math.round(analysis.severity_stats.min)} - ${Math.round(analysis.severity_stats.max)}</p>
            </div>
            
            <div style="margin-bottom: 20px;">
                <h3>Severity Distribution</h3>
                <p><strong>Low Severity:</strong> ${analysis.severity_distribution.low} (${((analysis.severity_distribution.low / analysis.total_potholes) * 100).toFixed(1)}%)</p>
                <p><strong>Medium Severity:</strong> ${analysis.severity_distribution.medium} (${((analysis.severity_distribution.medium / analysis.total_potholes) * 100).toFixed(1)}%)</p>
                <p><strong>High Severity:</strong> ${analysis.severity_distribution.high} (${((analysis.severity_distribution.high / analysis.total_potholes) * 100).toFixed(1)}%)</p>
            </div>
            
            <div style="margin-bottom: 20px;">
                <h3>Geographic Coverage</h3>
                <p><strong>Center Point:</strong> ${analysis.geographic_stats.center_lat.toFixed(6)}, ${analysis.geographic_stats.center_lng.toFixed(6)}</p>
                <p><strong>Coverage Area:</strong> ${(analysis.geographic_stats.latitude_range * 111).toFixed(2)} km × ${(analysis.geographic_stats.longitude_range * 85).toFixed(2)} km</p>
            </div>
            
            <div style="margin-bottom: 20px;">
                <h3>Detection Quality</h3>
                <p><strong>Average Confidence:</strong> ${(analysis.confidence_stats.mean * 100).toFixed(1)}%</p>
                <p><strong>Confidence Range:</strong> ${(analysis.confidence_stats.min * 100).toFixed(1)}% - ${(analysis.confidence_stats.max * 100).toFixed(1)}%</p>
            </div>
        `;
    }
}

function closeAnalysisModal() {
    document.getElementById("analysisModal").style.display = "none";
}

// Global functions for button interactions
let dashboard;

function applyFilters() {
    const severityFilter = document.getElementById('severity-filter').value;
    const startDate = document.getElementById('start-date').value;
    const endDate = document.getElementById('end-date').value;
    
    const filters = {};
    
    if (startDate) {
        filters.start_date = startDate + 'T00:00:00';
    }
    
    if (endDate) {
        filters.end_date = endDate + 'T23:59:59';
    }
    
    if (severityFilter) {
        const severityRange = dashboard.getSeverityRange(severityFilter);
        if (severityRange.min !== undefined) filters.min_severity = severityRange.min;
        if (severityRange.max !== undefined && severityRange.max !== Infinity) {
            filters.max_severity = severityRange.max;
        }
    }
    
    dashboard.loadPotholeData(filters);
}

function clearFilters() {
    document.getElementById('severity-filter').value = '';
    document.getElementById('start-date').value = '';
    document.getElementById('end-date').value = '';
    
    dashboard.loadPotholeData();
}

function toggleClustering() {
    dashboard.clusteringEnabled = !dashboard.clusteringEnabled;
    dashboard.updateMap();
    
    const button = event.target;
    if (dashboard.clusteringEnabled) {
        button.innerHTML = '<i class="fas fa-layer-group"></i> Disable Clustering';
    } else {
        button.innerHTML = '<i class="fas fa-layer-group"></i> Enable Clustering';
    }
}

function toggleHotspots() {
    dashboard.showHotspots = !dashboard.showHotspots;
    dashboard.updateMap();
    
    const button = event.target;
    if (dashboard.showHotspots) {
        button.innerHTML = '<i class="fas fa-fire"></i> Hide Hotspots';
    } else {
        button.innerHTML = '<i class="fas fa-fire"></i> Show Hotspots';
    }
}

function showAnalysis() {
    dashboard.showAnalysis();
}

function downloadReport(format) {
    dashboard.downloadReport(format);
}

function clearAllData() {
    if (confirm('Are you sure you want to clear all pothole data? This action cannot be undone.')) {
        try {
            dashboard.showLoading(true);
            
            const response = await fetch('/api/potholes/clear', {
                method: 'DELETE'
            });
            
            if (response.ok) {
                alert('All pothole data has been cleared.');
                dashboard.loadInitialData();
            } else {
                alert('Error clearing data. Please try again.');
            }
        } catch (error) {
            console.error('Error clearing data:', error);
            alert('Error clearing data. Please try again.');
        } finally {
            dashboard.showLoading(false);
        }
    }
}

// Initialize dashboard when page loads
document.addEventListener('DOMContentLoaded', function() {
    dashboard = new PotholeDashboard();
});



    async downloadReport(format) {
        try {
            this.showLoading(true);
            const response = await fetch(`/api/potholes/report?format=${format}`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `pothole_analysis_report.${format}`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
        } catch (error) {
            console.error("Error downloading report:", error);
            alert("Failed to download report. Please try again.");
        } finally {
            this.showLoading(false);
        }
    }


