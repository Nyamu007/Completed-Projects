#!/usr/bin/env python3
"""
YOLOv12 Pothole Detection Integration Example
============================================

This script demonstrates how to integrate YOLOv12 pothole detection with the
real-time dashboard client on a Raspberry Pi.

Requirements:
- ultralytics: pip install ultralytics
- opencv-python: pip install opencv-python
- requests: pip install requests
- Your trained YOLOv12 model file (.pt)

Usage:
    python yolo_integration_example.py --model path/to/your/model.pt --server-url http://dashboard-url:5000
"""

import cv2
import numpy as np
import argparse
import time
import logging
from datetime import datetime
from ultralytics import YOLO
from raspberry_pi_client import PotholeDetectionClient, MockGPSModule

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class YOLOPotholeDetector:
    def __init__(self, model_path, confidence_threshold=0.25):
        """
        Initialize YOLO pothole detector
        
        Args:
            model_path (str): Path to the trained YOLOv12 model file
            confidence_threshold (float): Minimum confidence for detections
        """
        self.model_path = model_path
        self.confidence_threshold = confidence_threshold
        
        try:
            logger.info(f"Loading YOLO model from {model_path}...")
            self.model = YOLO(model_path)
            logger.info("✅ YOLO model loaded successfully")
        except Exception as e:
            logger.error(f"❌ Failed to load YOLO model: {e}")
            raise
    
    def detect_potholes(self, image):
        """
        Detect potholes in an image using YOLOv12
        
        Args:
            image (numpy.ndarray): Input image
            
        Returns:
            list: List of detection results with severity calculations
        """
        try:
            # Run YOLO inference
            results = self.model(image, conf=self.confidence_threshold)
            
            detections = []
            
            for result in results:
                boxes = result.boxes
                if boxes is not None:
                    for box in boxes:
                        # Extract bounding box coordinates
                        x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                        confidence = box.conf[0].cpu().numpy()
                        
                        # Calculate dimensions
                        width = x2 - x1
                        height = y2 - y1
                        area = width * height
                        
                        # Calculate severity based on area and other factors
                        severity = self.calculate_severity(width, height, confidence, image.shape)
                        
                        detection = {
                            'bbox': {
                                'x1': float(x1),
                                'y1': float(y1),
                                'x2': float(x2),
                                'y2': float(y2)
                            },
                            'width': float(width),
                            'height': float(height),
                            'area': float(area),
                            'confidence': float(confidence),
                            'severity': float(severity)
                        }
                        
                        detections.append(detection)
                        
                        logger.info(f"🕳️ Pothole detected: {width:.1f}x{height:.1f}px, "
                                  f"confidence: {confidence:.3f}, severity: {severity:.1f}")
            
            return detections
            
        except Exception as e:
            logger.error(f"❌ Error during detection: {e}")
            return []
    
    def calculate_severity(self, width, height, confidence, image_shape):
        """
        Calculate pothole severity based on detection parameters
        
        Args:
            width (float): Bounding box width
            height (float): Bounding box height
            confidence (float): Detection confidence
            image_shape (tuple): Image dimensions (height, width, channels)
            
        Returns:
            float: Severity score
        """
        # Base severity on area relative to image size
        image_area = image_shape[0] * image_shape[1]
        pothole_area = width * height
        area_ratio = pothole_area / image_area
        
        # Calculate base severity (0-100000 scale)
        base_severity = area_ratio * 100000
        
        # Adjust based on aspect ratio (more circular = more severe)
        aspect_ratio = max(width, height) / min(width, height)
        aspect_factor = 2.0 - min(aspect_ratio / 3.0, 1.0)  # Favor square-ish shapes
        
        # Adjust based on confidence
        confidence_factor = confidence
        
        # Final severity calculation
        severity = base_severity * aspect_factor * confidence_factor
        
        # Ensure minimum and maximum bounds
        severity = max(500, min(severity, 100000))
        
        return severity

class RaspberryPiCamera:
    def __init__(self, camera_index=0, width=640, height=480):
        """
        Initialize Raspberry Pi camera
        
        Args:
            camera_index (int): Camera device index
            width (int): Frame width
            height (int): Frame height
        """
        self.camera_index = camera_index
        self.width = width
        self.height = height
        self.cap = None
        
        self.initialize_camera()
    
    def initialize_camera(self):
        """Initialize the camera capture"""
        try:
            logger.info(f"Initializing camera {self.camera_index}...")
            self.cap = cv2.VideoCapture(self.camera_index)
            
            if not self.cap.isOpened():
                raise RuntimeError(f"Failed to open camera {self.camera_index}")
            
            # Set camera properties
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
            self.cap.set(cv2.CAP_PROP_FPS, 30)
            
            logger.info("✅ Camera initialized successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize camera: {e}")
            raise
    
    def capture_frame(self):
        """
        Capture a single frame from the camera
        
        Returns:
            numpy.ndarray: Captured frame, or None if failed
        """
        if self.cap is None:
            return None
        
        ret, frame = self.cap.read()
        if ret:
            return frame
        else:
            logger.warning("⚠️ Failed to capture frame")
            return None
    
    def release(self):
        """Release the camera"""
        if self.cap is not None:
            self.cap.release()
            logger.info("📷 Camera released")

def run_real_time_detection(model_path, server_url, device_id=None, camera_index=0):
    """
    Run real-time pothole detection and send results to dashboard
    
    Args:
        model_path (str): Path to YOLO model
        server_url (str): Dashboard server URL
        device_id (str): Device identifier
        camera_index (int): Camera device index
    """
    try:
        # Initialize components
        detector = YOLOPotholeDetector(model_path)
        client = PotholeDetectionClient(server_url, device_id)
        camera = RaspberryPiCamera(camera_index)
        gps = MockGPSModule()  # Replace with real GPS module
        
        logger.info("🚀 Starting real-time pothole detection...")
        logger.info("Press Ctrl+C to stop")
        
        frame_count = 0
        detection_count = 0
        
        while True:
            # Capture frame
            frame = camera.capture_frame()
            if frame is None:
                time.sleep(0.1)
                continue
            
            frame_count += 1
            
            # Process every 5th frame to reduce computational load
            if frame_count % 5 != 0:
                continue
            
            # Detect potholes
            detections = detector.detect_potholes(frame)
            
            if detections:
                # Get current GPS coordinates
                latitude, longitude = gps.get_coordinates()
                
                # Send each detection to dashboard
                for detection in detections:
                    success = client.send_detection(
                        latitude=latitude,
                        longitude=longitude,
                        severity=detection['severity'],
                        confidence=detection['confidence'],
                        width=detection['width'],
                        height=detection['height']
                    )
                    
                    if success:
                        detection_count += 1
                        logger.info(f"📡 Detection #{detection_count} sent to dashboard")
            
            # Small delay to prevent overwhelming the system
            time.sleep(0.1)
            
    except KeyboardInterrupt:
        logger.info("🛑 Detection stopped by user")
    except Exception as e:
        logger.error(f"💥 Fatal error: {e}")
    finally:
        # Cleanup
        if 'camera' in locals():
            camera.release()
        cv2.destroyAllWindows()
        
        logger.info(f"✅ Session completed. Total detections: {detection_count}")

def test_model_on_image(model_path, image_path, server_url=None):
    """
    Test the YOLO model on a single image
    
    Args:
        model_path (str): Path to YOLO model
        image_path (str): Path to test image
        server_url (str, optional): Dashboard server URL for sending results
    """
    try:
        # Load image
        image = cv2.imread(image_path)
        if image is None:
            logger.error(f"❌ Failed to load image: {image_path}")
            return
        
        logger.info(f"🖼️ Testing model on image: {image_path}")
        
        # Initialize detector
        detector = YOLOPotholeDetector(model_path)
        
        # Detect potholes
        detections = detector.detect_potholes(image)
        
        logger.info(f"🔍 Found {len(detections)} pothole(s)")
        
        # Draw detections on image
        for i, detection in enumerate(detections):
            bbox = detection['bbox']
            x1, y1, x2, y2 = int(bbox['x1']), int(bbox['y1']), int(bbox['x2']), int(bbox['y2'])
            
            # Draw bounding box
            cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)
            
            # Add label
            label = f"Pothole {i+1}: {detection['confidence']:.2f}"
            cv2.putText(image, label, (x1, y1-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            
            logger.info(f"  Pothole {i+1}: severity={detection['severity']:.1f}, "
                       f"confidence={detection['confidence']:.3f}")
        
        # Save result image
        output_path = image_path.replace('.', '_detected.')
        cv2.imwrite(output_path, image)
        logger.info(f"💾 Result saved to: {output_path}")
        
        # Optionally send to dashboard
        if server_url and detections:
            client = PotholeDetectionClient(server_url)
            gps = MockGPSModule()
            latitude, longitude = gps.get_coordinates()
            
            for detection in detections:
                client.send_detection(
                    latitude=latitude,
                    longitude=longitude,
                    severity=detection['severity'],
                    confidence=detection['confidence'],
                    width=detection['width'],
                    height=detection['height']
                )
            
            logger.info(f"📡 Sent {len(detections)} detection(s) to dashboard")
        
    except Exception as e:
        logger.error(f"❌ Error testing model: {e}")

def main():
    parser = argparse.ArgumentParser(description='YOLOv12 Pothole Detection Integration')
    parser.add_argument('--model', required=True, help='Path to YOLOv12 model file (.pt)')
    parser.add_argument('--server-url', help='Dashboard server URL')
    parser.add_argument('--device-id', help='Unique device identifier')
    parser.add_argument('--camera', type=int, default=0, help='Camera device index')
    parser.add_argument('--test-image', help='Test model on a single image')
    parser.add_argument('--real-time', action='store_true', help='Run real-time detection')
    
    args = parser.parse_args()
    
    if args.test_image:
        # Test mode
        test_model_on_image(args.model, args.test_image, args.server_url)
    elif args.real_time:
        # Real-time mode
        if not args.server_url:
            logger.error("❌ --server-url is required for real-time mode")
            return 1
        
        run_real_time_detection(args.model, args.server_url, args.device_id, args.camera)
    else:
        logger.info("ℹ️ Use --test-image or --real-time to run detection")
        logger.info("ℹ️ Example: python yolo_integration_example.py --model model.pt --real-time --server-url http://localhost:5000")
    
    return 0

if __name__ == "__main__":
    exit(main())

